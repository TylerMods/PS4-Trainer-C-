﻿namespace PS4_Trainer_by_TylerMods.Game_Trainers
{
    partial class Mafia3
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mafia3));
            this.btnAttach = new theme.FlatButton();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnFAQ = new theme.FlatButton();
            this.label4 = new System.Windows.Forms.Label();
            this.flatLabel6 = new theme.FlatLabel();
            this.tglHealth = new theme.FlatToggle();
            this.pnlHealth = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pnlReload = new System.Windows.Forms.Panel();
            this.flatLabel2 = new theme.FlatLabel();
            this.tglReload = new theme.FlatToggle();
            this.cmbVersion = new theme.FlatComboBox();
            this.pnlMoney = new System.Windows.Forms.Panel();
            this.flatLabel3 = new theme.FlatLabel();
            this.tglMoney = new theme.FlatToggle();
            this.tglAmmo = new theme.FlatToggle();
            this.flatLabel1 = new theme.FlatLabel();
            this.pnlAmmo = new System.Windows.Forms.Panel();
            this.pnlMed = new System.Windows.Forms.Panel();
            this.flatLabel4 = new theme.FlatLabel();
            this.tglMed = new theme.FlatToggle();
            this.pnlThrowables = new System.Windows.Forms.Panel();
            this.flatLabel5 = new theme.FlatLabel();
            this.tglThrowables = new theme.FlatToggle();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlHealth.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel5.SuspendLayout();
            this.pnlReload.SuspendLayout();
            this.pnlMoney.SuspendLayout();
            this.pnlAmmo.SuspendLayout();
            this.pnlMed.SuspendLayout();
            this.pnlThrowables.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAttach
            // 
            this.btnAttach.BackColor = System.Drawing.Color.Transparent;
            this.btnAttach.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAttach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAttach.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAttach.Location = new System.Drawing.Point(394, 4);
            this.btnAttach.Name = "btnAttach";
            this.btnAttach.Rounded = false;
            this.btnAttach.Size = new System.Drawing.Size(118, 44);
            this.btnAttach.TabIndex = 94;
            this.btnAttach.Text = "Attach";
            this.btnAttach.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAttach.Click += new System.EventHandler(this.btnAttach_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label3.Location = new System.Drawing.Point(389, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 28);
            this.label3.TabIndex = 98;
            this.label3.Text = "CUSA03617";
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(518, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 102);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 96;
            this.pictureBox1.TabStop = false;
            // 
            // btnFAQ
            // 
            this.btnFAQ.BackColor = System.Drawing.Color.Transparent;
            this.btnFAQ.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnFAQ.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFAQ.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnFAQ.Location = new System.Drawing.Point(357, 4);
            this.btnFAQ.Name = "btnFAQ";
            this.btnFAQ.Rounded = false;
            this.btnFAQ.Size = new System.Drawing.Size(21, 25);
            this.btnFAQ.TabIndex = 95;
            this.btnFAQ.Text = "?";
            this.btnFAQ.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnFAQ.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label4.Location = new System.Drawing.Point(6, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(300, 28);
            this.label4.TabIndex = 100;
            this.label4.Text = "Cheater : Talixme + TylerMods";
            // 
            // flatLabel6
            // 
            this.flatLabel6.AutoSize = true;
            this.flatLabel6.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel6.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel6.ForeColor = System.Drawing.Color.White;
            this.flatLabel6.Location = new System.Drawing.Point(26, 25);
            this.flatLabel6.Name = "flatLabel6";
            this.flatLabel6.Size = new System.Drawing.Size(103, 20);
            this.flatLabel6.TabIndex = 2;
            this.flatLabel6.Text = "Infinite Health";
            // 
            // tglHealth
            // 
            this.tglHealth.BackColor = System.Drawing.Color.Transparent;
            this.tglHealth.Checked = false;
            this.tglHealth.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglHealth.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglHealth.Location = new System.Drawing.Point(295, 18);
            this.tglHealth.Name = "tglHealth";
            this.tglHealth.Options = theme.FlatToggle._Options.Style3;
            this.tglHealth.Size = new System.Drawing.Size(76, 33);
            this.tglHealth.TabIndex = 1;
            this.tglHealth.Text = "flatToggle1";
            this.tglHealth.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglHealth_CheckedChanged);
            // 
            // pnlHealth
            // 
            this.pnlHealth.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlHealth.Controls.Add(this.flatLabel6);
            this.pnlHealth.Controls.Add(this.tglHealth);
            this.pnlHealth.Location = new System.Drawing.Point(3, 3);
            this.pnlHealth.Name = "pnlHealth";
            this.pnlHealth.Size = new System.Drawing.Size(378, 73);
            this.pnlHealth.TabIndex = 45;
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(351, 72);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 101;
            this.pictureBox2.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.AutoScroll = true;
            this.panel5.Controls.Add(this.pnlThrowables);
            this.panel5.Controls.Add(this.pnlMed);
            this.panel5.Controls.Add(this.pnlMoney);
            this.panel5.Controls.Add(this.pnlReload);
            this.panel5.Controls.Add(this.pnlAmmo);
            this.panel5.Controls.Add(this.pnlHealth);
            this.panel5.Location = new System.Drawing.Point(0, 109);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(758, 344);
            this.panel5.TabIndex = 99;
            // 
            // pnlReload
            // 
            this.pnlReload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlReload.Controls.Add(this.flatLabel2);
            this.pnlReload.Controls.Add(this.tglReload);
            this.pnlReload.Location = new System.Drawing.Point(382, 3);
            this.pnlReload.Name = "pnlReload";
            this.pnlReload.Size = new System.Drawing.Size(373, 73);
            this.pnlReload.TabIndex = 48;
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(26, 25);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(80, 20);
            this.flatLabel2.TabIndex = 2;
            this.flatLabel2.Text = "No Reload";
            // 
            // tglReload
            // 
            this.tglReload.BackColor = System.Drawing.Color.Transparent;
            this.tglReload.Checked = false;
            this.tglReload.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglReload.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglReload.Location = new System.Drawing.Point(294, 21);
            this.tglReload.Name = "tglReload";
            this.tglReload.Options = theme.FlatToggle._Options.Style3;
            this.tglReload.Size = new System.Drawing.Size(76, 33);
            this.tglReload.TabIndex = 1;
            this.tglReload.Text = "flatToggle1";
            this.tglReload.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglReload_CheckedChanged);
            // 
            // cmbVersion
            // 
            this.cmbVersion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.cmbVersion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbVersion.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVersion.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cmbVersion.ForeColor = System.Drawing.Color.White;
            this.cmbVersion.FormattingEnabled = true;
            this.cmbVersion.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.cmbVersion.ItemHeight = 18;
            this.cmbVersion.Items.AddRange(new object[] {
            "v1.00",
            "v1.09"});
            this.cmbVersion.Location = new System.Drawing.Point(380, 82);
            this.cmbVersion.Name = "cmbVersion";
            this.cmbVersion.Size = new System.Drawing.Size(132, 24);
            this.cmbVersion.TabIndex = 102;
            this.cmbVersion.SelectedIndexChanged += new System.EventHandler(this.cmbVersion_SelectedIndexChanged);
            // 
            // pnlMoney
            // 
            this.pnlMoney.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlMoney.Controls.Add(this.flatLabel3);
            this.pnlMoney.Controls.Add(this.tglMoney);
            this.pnlMoney.Location = new System.Drawing.Point(382, 82);
            this.pnlMoney.Name = "pnlMoney";
            this.pnlMoney.Size = new System.Drawing.Size(373, 73);
            this.pnlMoney.TabIndex = 49;
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(26, 25);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(104, 20);
            this.flatLabel3.TabIndex = 2;
            this.flatLabel3.Text = "Infinite Money";
            // 
            // tglMoney
            // 
            this.tglMoney.BackColor = System.Drawing.Color.Transparent;
            this.tglMoney.Checked = false;
            this.tglMoney.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglMoney.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglMoney.Location = new System.Drawing.Point(294, 21);
            this.tglMoney.Name = "tglMoney";
            this.tglMoney.Options = theme.FlatToggle._Options.Style3;
            this.tglMoney.Size = new System.Drawing.Size(76, 33);
            this.tglMoney.TabIndex = 1;
            this.tglMoney.Text = "flatToggle1";
            this.tglMoney.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglMoney_CheckedChanged);
            // 
            // tglAmmo
            // 
            this.tglAmmo.BackColor = System.Drawing.Color.Transparent;
            this.tglAmmo.Checked = false;
            this.tglAmmo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglAmmo.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglAmmo.Location = new System.Drawing.Point(295, 21);
            this.tglAmmo.Name = "tglAmmo";
            this.tglAmmo.Options = theme.FlatToggle._Options.Style3;
            this.tglAmmo.Size = new System.Drawing.Size(76, 33);
            this.tglAmmo.TabIndex = 1;
            this.tglAmmo.Text = "flatToggle1";
            this.tglAmmo.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglAmmo_CheckedChanged);
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(26, 25);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(104, 20);
            this.flatLabel1.TabIndex = 2;
            this.flatLabel1.Text = "Infinite Ammo";
            // 
            // pnlAmmo
            // 
            this.pnlAmmo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlAmmo.Controls.Add(this.flatLabel1);
            this.pnlAmmo.Controls.Add(this.tglAmmo);
            this.pnlAmmo.Location = new System.Drawing.Point(3, 82);
            this.pnlAmmo.Name = "pnlAmmo";
            this.pnlAmmo.Size = new System.Drawing.Size(378, 73);
            this.pnlAmmo.TabIndex = 46;
            // 
            // pnlMed
            // 
            this.pnlMed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlMed.Controls.Add(this.flatLabel4);
            this.pnlMed.Controls.Add(this.tglMed);
            this.pnlMed.Location = new System.Drawing.Point(3, 161);
            this.pnlMed.Name = "pnlMed";
            this.pnlMed.Size = new System.Drawing.Size(378, 73);
            this.pnlMed.TabIndex = 47;
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(26, 25);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(111, 20);
            this.flatLabel4.TabIndex = 2;
            this.flatLabel4.Text = "Infinite Medkits";
            // 
            // tglMed
            // 
            this.tglMed.BackColor = System.Drawing.Color.Transparent;
            this.tglMed.Checked = false;
            this.tglMed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglMed.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglMed.Location = new System.Drawing.Point(295, 21);
            this.tglMed.Name = "tglMed";
            this.tglMed.Options = theme.FlatToggle._Options.Style3;
            this.tglMed.Size = new System.Drawing.Size(76, 33);
            this.tglMed.TabIndex = 1;
            this.tglMed.Text = "flatToggle1";
            this.tglMed.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglMed_CheckedChanged);
            // 
            // pnlThrowables
            // 
            this.pnlThrowables.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlThrowables.Controls.Add(this.flatLabel5);
            this.pnlThrowables.Controls.Add(this.tglThrowables);
            this.pnlThrowables.Location = new System.Drawing.Point(382, 161);
            this.pnlThrowables.Name = "pnlThrowables";
            this.pnlThrowables.Size = new System.Drawing.Size(373, 73);
            this.pnlThrowables.TabIndex = 50;
            // 
            // flatLabel5
            // 
            this.flatLabel5.AutoSize = true;
            this.flatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel5.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel5.ForeColor = System.Drawing.Color.White;
            this.flatLabel5.Location = new System.Drawing.Point(26, 25);
            this.flatLabel5.Name = "flatLabel5";
            this.flatLabel5.Size = new System.Drawing.Size(135, 20);
            this.flatLabel5.TabIndex = 2;
            this.flatLabel5.Text = "Infinite Throwables";
            // 
            // tglThrowables
            // 
            this.tglThrowables.BackColor = System.Drawing.Color.Transparent;
            this.tglThrowables.Checked = false;
            this.tglThrowables.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglThrowables.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglThrowables.Location = new System.Drawing.Point(294, 21);
            this.tglThrowables.Name = "tglThrowables";
            this.tglThrowables.Options = theme.FlatToggle._Options.Style3;
            this.tglThrowables.Size = new System.Drawing.Size(76, 33);
            this.tglThrowables.TabIndex = 1;
            this.tglThrowables.Text = "flatToggle1";
            this.tglThrowables.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglThrowables_CheckedChanged);
            // 
            // Mafia3
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.cmbVersion);
            this.Controls.Add(this.btnAttach);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnFAQ);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel5);
            this.Name = "Mafia3";
            this.Size = new System.Drawing.Size(758, 455);
            this.Load += new System.EventHandler(this.Mafia3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlHealth.ResumeLayout(false);
            this.pnlHealth.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.pnlReload.ResumeLayout(false);
            this.pnlReload.PerformLayout();
            this.pnlMoney.ResumeLayout(false);
            this.pnlMoney.PerformLayout();
            this.pnlAmmo.ResumeLayout(false);
            this.pnlAmmo.PerformLayout();
            this.pnlMed.ResumeLayout(false);
            this.pnlMed.PerformLayout();
            this.pnlThrowables.ResumeLayout(false);
            this.pnlThrowables.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private theme.FlatButton btnAttach;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private theme.FlatButton btnFAQ;
        private System.Windows.Forms.Label label4;
        private theme.FlatLabel flatLabel6;
        private theme.FlatToggle tglHealth;
        private System.Windows.Forms.Panel pnlHealth;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel pnlReload;
        private theme.FlatLabel flatLabel2;
        private theme.FlatToggle tglReload;
        private theme.FlatComboBox cmbVersion;
        private System.Windows.Forms.Panel pnlMoney;
        private theme.FlatLabel flatLabel3;
        private theme.FlatToggle tglMoney;
        private System.Windows.Forms.Panel pnlAmmo;
        private theme.FlatLabel flatLabel1;
        private theme.FlatToggle tglAmmo;
        private System.Windows.Forms.Panel pnlMed;
        private theme.FlatLabel flatLabel4;
        private theme.FlatToggle tglMed;
        private System.Windows.Forms.Panel pnlThrowables;
        private theme.FlatLabel flatLabel5;
        private theme.FlatToggle tglThrowables;
    }
}

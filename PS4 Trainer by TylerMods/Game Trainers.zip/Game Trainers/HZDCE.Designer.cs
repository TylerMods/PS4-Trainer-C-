﻿namespace PS4_Trainer_by_TylerMods.Game_Trainers
{
    partial class HZDCE
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HZDCE));
            this.numSP = new theme.FlatNumeric();
            this.flatLabel2 = new theme.FlatLabel();
            this.btnSP = new theme.FlatButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.flatLabel6 = new theme.FlatLabel();
            this.tglHealth = new theme.FlatToggle();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnAttach = new theme.FlatButton();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnFAQ = new theme.FlatButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.flatLabel10 = new theme.FlatLabel();
            this.tglNormalHealth = new theme.FlatToggle();
            this.panel10 = new System.Windows.Forms.Panel();
            this.pnlHit = new System.Windows.Forms.Panel();
            this.flatLabel9 = new theme.FlatLabel();
            this.tglHit = new theme.FlatToggle();
            this.panel9 = new System.Windows.Forms.Panel();
            this.tglDuplicateSkillPoints = new theme.FlatToggle();
            this.flatLabel8 = new theme.FlatLabel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.tglTime = new theme.FlatToggle();
            this.flatLabel5 = new theme.FlatLabel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.flatToggle1 = new theme.FlatToggle();
            this.flatLabel4 = new theme.FlatLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tglSkillPoints = new theme.FlatToggle();
            this.flatLabel1 = new theme.FlatLabel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tglArrows = new theme.FlatToggle();
            this.flatLabel3 = new theme.FlatLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCheaters = new theme.FlatButton();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.pnlHit.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // numSP
            // 
            this.numSP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numSP.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numSP.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numSP.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numSP.ForeColor = System.Drawing.Color.White;
            this.numSP.Location = new System.Drawing.Point(104, 21);
            this.numSP.Maximum = ((long)(99999999));
            this.numSP.Minimum = ((long)(0));
            this.numSP.Name = "numSP";
            this.numSP.Size = new System.Drawing.Size(145, 30);
            this.numSP.TabIndex = 3;
            this.numSP.Text = "flatNumeric1";
            this.numSP.Value = ((long)(0));
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(14, 26);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(79, 20);
            this.flatLabel2.TabIndex = 2;
            this.flatLabel2.Text = "Skill Points";
            // 
            // btnSP
            // 
            this.btnSP.BackColor = System.Drawing.Color.Transparent;
            this.btnSP.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnSP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSP.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnSP.Location = new System.Drawing.Point(255, 14);
            this.btnSP.Name = "btnSP";
            this.btnSP.Rounded = false;
            this.btnSP.Size = new System.Drawing.Size(97, 44);
            this.btnSP.TabIndex = 0;
            this.btnSP.Text = "Set";
            this.btnSP.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnSP.Click += new System.EventHandler(this.btnSP_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel2.Controls.Add(this.numSP);
            this.panel2.Controls.Add(this.flatLabel2);
            this.panel2.Controls.Add(this.btnSP);
            this.panel2.Location = new System.Drawing.Point(381, 321);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(359, 73);
            this.panel2.TabIndex = 46;
            // 
            // flatLabel6
            // 
            this.flatLabel6.AutoSize = true;
            this.flatLabel6.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel6.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel6.ForeColor = System.Drawing.Color.White;
            this.flatLabel6.Location = new System.Drawing.Point(14, 26);
            this.flatLabel6.Name = "flatLabel6";
            this.flatLabel6.Size = new System.Drawing.Size(103, 20);
            this.flatLabel6.TabIndex = 2;
            this.flatLabel6.Text = "Infinite Health";
            // 
            // tglHealth
            // 
            this.tglHealth.BackColor = System.Drawing.Color.Transparent;
            this.tglHealth.Checked = false;
            this.tglHealth.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglHealth.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglHealth.Location = new System.Drawing.Point(276, 21);
            this.tglHealth.Name = "tglHealth";
            this.tglHealth.Options = theme.FlatToggle._Options.Style3;
            this.tglHealth.Size = new System.Drawing.Size(76, 33);
            this.tglHealth.TabIndex = 1;
            this.tglHealth.Text = "flatToggle1";
            this.tglHealth.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglHealth_CheckedChanged);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel7.Controls.Add(this.flatLabel6);
            this.panel7.Controls.Add(this.tglHealth);
            this.panel7.Location = new System.Drawing.Point(381, 6);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(359, 73);
            this.panel7.TabIndex = 45;
            // 
            // btnAttach
            // 
            this.btnAttach.BackColor = System.Drawing.Color.Transparent;
            this.btnAttach.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAttach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAttach.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAttach.Location = new System.Drawing.Point(394, 4);
            this.btnAttach.Name = "btnAttach";
            this.btnAttach.Rounded = false;
            this.btnAttach.Size = new System.Drawing.Size(118, 44);
            this.btnAttach.TabIndex = 86;
            this.btnAttach.Text = "Attach";
            this.btnAttach.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAttach.Click += new System.EventHandler(this.btnAttach_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label3.Location = new System.Drawing.Point(389, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 28);
            this.label3.TabIndex = 90;
            this.label3.Text = "CUSA10211";
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(518, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 102);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 88;
            this.pictureBox1.TabStop = false;
            // 
            // btnFAQ
            // 
            this.btnFAQ.BackColor = System.Drawing.Color.Transparent;
            this.btnFAQ.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnFAQ.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFAQ.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnFAQ.Location = new System.Drawing.Point(357, 4);
            this.btnFAQ.Name = "btnFAQ";
            this.btnFAQ.Rounded = false;
            this.btnFAQ.Size = new System.Drawing.Size(21, 25);
            this.btnFAQ.TabIndex = 87;
            this.btnFAQ.Text = "?";
            this.btnFAQ.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnFAQ.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(351, 72);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 93;
            this.pictureBox2.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.AutoScroll = true;
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Controls.Add(this.panel11);
            this.panel5.Controls.Add(this.panel10);
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.panel4);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Controls.Add(this.panel3);
            this.panel5.Controls.Add(this.panel2);
            this.panel5.Location = new System.Drawing.Point(0, 109);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(758, 344);
            this.panel5.TabIndex = 91;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel11.Controls.Add(this.flatLabel10);
            this.panel11.Controls.Add(this.tglNormalHealth);
            this.panel11.Location = new System.Drawing.Point(381, 85);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(359, 73);
            this.panel11.TabIndex = 47;
            // 
            // flatLabel10
            // 
            this.flatLabel10.AutoSize = true;
            this.flatLabel10.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel10.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel10.ForeColor = System.Drawing.Color.White;
            this.flatLabel10.Location = new System.Drawing.Point(14, 26);
            this.flatLabel10.Name = "flatLabel10";
            this.flatLabel10.Size = new System.Drawing.Size(178, 20);
            this.flatLabel10.TabIndex = 2;
            this.flatLabel10.Text = "Infinite Health + 1 Hit Kill";
            // 
            // tglNormalHealth
            // 
            this.tglNormalHealth.BackColor = System.Drawing.Color.Transparent;
            this.tglNormalHealth.Checked = false;
            this.tglNormalHealth.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglNormalHealth.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglNormalHealth.Location = new System.Drawing.Point(276, 22);
            this.tglNormalHealth.Name = "tglNormalHealth";
            this.tglNormalHealth.Options = theme.FlatToggle._Options.Style3;
            this.tglNormalHealth.Size = new System.Drawing.Size(76, 33);
            this.tglNormalHealth.TabIndex = 1;
            this.tglNormalHealth.Text = "flatToggle1";
            this.tglNormalHealth.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglNormalHealth_CheckedChanged);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.panel10.Controls.Add(this.pnlHit);
            this.panel10.Location = new System.Drawing.Point(381, 6);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(359, 231);
            this.panel10.TabIndex = 50;
            // 
            // pnlHit
            // 
            this.pnlHit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlHit.Controls.Add(this.flatLabel9);
            this.pnlHit.Controls.Add(this.tglHit);
            this.pnlHit.Location = new System.Drawing.Point(0, 158);
            this.pnlHit.Name = "pnlHit";
            this.pnlHit.Size = new System.Drawing.Size(359, 73);
            this.pnlHit.TabIndex = 46;
            // 
            // flatLabel9
            // 
            this.flatLabel9.AutoSize = true;
            this.flatLabel9.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel9.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel9.ForeColor = System.Drawing.Color.White;
            this.flatLabel9.Location = new System.Drawing.Point(14, 26);
            this.flatLabel9.Name = "flatLabel9";
            this.flatLabel9.Size = new System.Drawing.Size(66, 20);
            this.flatLabel9.TabIndex = 2;
            this.flatLabel9.Text = "1 Hit Kill";
            // 
            // tglHit
            // 
            this.tglHit.BackColor = System.Drawing.Color.Transparent;
            this.tglHit.Checked = false;
            this.tglHit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglHit.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglHit.Location = new System.Drawing.Point(276, 22);
            this.tglHit.Name = "tglHit";
            this.tglHit.Options = theme.FlatToggle._Options.Style3;
            this.tglHit.Size = new System.Drawing.Size(76, 33);
            this.tglHit.TabIndex = 1;
            this.tglHit.Text = "flatToggle1";
            this.tglHit.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglHit_CheckedChanged);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel9.Controls.Add(this.tglDuplicateSkillPoints);
            this.panel9.Controls.Add(this.flatLabel8);
            this.panel9.Location = new System.Drawing.Point(3, 164);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(375, 73);
            this.panel9.TabIndex = 49;
            // 
            // tglDuplicateSkillPoints
            // 
            this.tglDuplicateSkillPoints.BackColor = System.Drawing.Color.Transparent;
            this.tglDuplicateSkillPoints.Checked = false;
            this.tglDuplicateSkillPoints.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglDuplicateSkillPoints.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglDuplicateSkillPoints.Location = new System.Drawing.Point(296, 22);
            this.tglDuplicateSkillPoints.Name = "tglDuplicateSkillPoints";
            this.tglDuplicateSkillPoints.Options = theme.FlatToggle._Options.Style3;
            this.tglDuplicateSkillPoints.Size = new System.Drawing.Size(76, 33);
            this.tglDuplicateSkillPoints.TabIndex = 3;
            this.tglDuplicateSkillPoints.Text = "flatToggle1";
            this.tglDuplicateSkillPoints.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglDuplicateSkillPoints_CheckedChanged);
            // 
            // flatLabel8
            // 
            this.flatLabel8.AutoSize = true;
            this.flatLabel8.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel8.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel8.ForeColor = System.Drawing.Color.White;
            this.flatLabel8.Location = new System.Drawing.Point(14, 26);
            this.flatLabel8.Name = "flatLabel8";
            this.flatLabel8.Size = new System.Drawing.Size(147, 20);
            this.flatLabel8.TabIndex = 2;
            this.flatLabel8.Text = "Duplicate Skill Points";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel6.Controls.Add(this.tglTime);
            this.panel6.Controls.Add(this.flatLabel5);
            this.panel6.Location = new System.Drawing.Point(3, 243);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(375, 73);
            this.panel6.TabIndex = 49;
            // 
            // tglTime
            // 
            this.tglTime.BackColor = System.Drawing.Color.Transparent;
            this.tglTime.Checked = false;
            this.tglTime.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglTime.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglTime.Location = new System.Drawing.Point(296, 19);
            this.tglTime.Name = "tglTime";
            this.tglTime.Options = theme.FlatToggle._Options.Style3;
            this.tglTime.Size = new System.Drawing.Size(76, 33);
            this.tglTime.TabIndex = 3;
            this.tglTime.Text = "flatToggle2";
            this.tglTime.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglTime_CheckedChanged);
            // 
            // flatLabel5
            // 
            this.flatLabel5.AutoSize = true;
            this.flatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel5.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel5.ForeColor = System.Drawing.Color.White;
            this.flatLabel5.Location = new System.Drawing.Point(14, 26);
            this.flatLabel5.Name = "flatLabel5";
            this.flatLabel5.Size = new System.Drawing.Size(89, 20);
            this.flatLabel5.TabIndex = 2;
            this.flatLabel5.Text = "Freeze Time";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel4.Controls.Add(this.flatToggle1);
            this.panel4.Controls.Add(this.flatLabel4);
            this.panel4.Location = new System.Drawing.Point(3, 85);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(375, 73);
            this.panel4.TabIndex = 48;
            // 
            // flatToggle1
            // 
            this.flatToggle1.BackColor = System.Drawing.Color.Transparent;
            this.flatToggle1.Checked = false;
            this.flatToggle1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatToggle1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.flatToggle1.Location = new System.Drawing.Point(296, 22);
            this.flatToggle1.Name = "flatToggle1";
            this.flatToggle1.Options = theme.FlatToggle._Options.Style3;
            this.flatToggle1.Size = new System.Drawing.Size(76, 33);
            this.flatToggle1.TabIndex = 3;
            this.flatToggle1.Text = "flatToggle1";
            this.flatToggle1.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.flatToggle1_CheckedChanged);
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(14, 26);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(187, 20);
            this.flatLabel4.TabIndex = 2;
            this.flatLabel4.Text = "Infinite Resources + Shards";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel1.Controls.Add(this.tglSkillPoints);
            this.panel1.Controls.Add(this.flatLabel1);
            this.panel1.Location = new System.Drawing.Point(381, 243);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(359, 73);
            this.panel1.TabIndex = 48;
            // 
            // tglSkillPoints
            // 
            this.tglSkillPoints.BackColor = System.Drawing.Color.Transparent;
            this.tglSkillPoints.Checked = false;
            this.tglSkillPoints.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglSkillPoints.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglSkillPoints.Location = new System.Drawing.Point(276, 22);
            this.tglSkillPoints.Name = "tglSkillPoints";
            this.tglSkillPoints.Options = theme.FlatToggle._Options.Style3;
            this.tglSkillPoints.Size = new System.Drawing.Size(76, 33);
            this.tglSkillPoints.TabIndex = 3;
            this.tglSkillPoints.Text = "flatToggle1";
            this.tglSkillPoints.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglSkillPoints_CheckedChanged);
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(14, 26);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(130, 20);
            this.flatLabel1.TabIndex = 2;
            this.flatLabel1.Text = "No Skill Point Cost";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel3.Controls.Add(this.tglArrows);
            this.panel3.Controls.Add(this.flatLabel3);
            this.panel3.Location = new System.Drawing.Point(3, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(375, 73);
            this.panel3.TabIndex = 47;
            // 
            // tglArrows
            // 
            this.tglArrows.BackColor = System.Drawing.Color.Transparent;
            this.tglArrows.Checked = false;
            this.tglArrows.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglArrows.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglArrows.Location = new System.Drawing.Point(296, 22);
            this.tglArrows.Name = "tglArrows";
            this.tglArrows.Options = theme.FlatToggle._Options.Style3;
            this.tglArrows.Size = new System.Drawing.Size(76, 33);
            this.tglArrows.TabIndex = 3;
            this.tglArrows.Text = "flatToggle1";
            this.tglArrows.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglArrows_CheckedChanged);
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(14, 26);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(105, 20);
            this.flatLabel3.TabIndex = 2;
            this.flatLabel3.Text = "Infinite Arrows";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label1.Location = new System.Drawing.Point(161, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 28);
            this.label1.TabIndex = 89;
            this.label1.Text = "Game Version : 1.52";
            // 
            // btnCheaters
            // 
            this.btnCheaters.BackColor = System.Drawing.Color.Transparent;
            this.btnCheaters.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnCheaters.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCheaters.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnCheaters.Location = new System.Drawing.Point(3, 78);
            this.btnCheaters.Name = "btnCheaters";
            this.btnCheaters.Rounded = false;
            this.btnCheaters.Size = new System.Drawing.Size(131, 28);
            this.btnCheaters.TabIndex = 94;
            this.btnCheaters.Text = "Cheaters";
            this.btnCheaters.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnCheaters.Click += new System.EventHandler(this.btnCheaters_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label2.Location = new System.Drawing.Point(389, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 28);
            this.label2.TabIndex = 95;
            this.label2.Text = "CUSA10237 ";
            // 
            // HZDCE
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnCheaters);
            this.Controls.Add(this.btnAttach);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnFAQ);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.label1);
            this.Name = "HZDCE";
            this.Size = new System.Drawing.Size(758, 455);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.pnlHit.ResumeLayout(false);
            this.pnlHit.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private theme.FlatNumeric numSP;
        private theme.FlatLabel flatLabel2;
        private theme.FlatButton btnSP;
        private System.Windows.Forms.Panel panel2;
        private theme.FlatLabel flatLabel6;
        private theme.FlatToggle tglHealth;
        private System.Windows.Forms.Panel panel7;
        private theme.FlatButton btnAttach;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private theme.FlatButton btnFAQ;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private theme.FlatLabel flatLabel3;
        private theme.FlatToggle tglArrows;
        private System.Windows.Forms.Panel panel1;
        private theme.FlatToggle tglSkillPoints;
        private theme.FlatLabel flatLabel1;
        private System.Windows.Forms.Panel panel4;
        private theme.FlatToggle flatToggle1;
        private theme.FlatLabel flatLabel4;
        private System.Windows.Forms.Panel panel6;
        private theme.FlatToggle tglTime;
        private theme.FlatLabel flatLabel5;
        private System.Windows.Forms.Panel panel9;
        private theme.FlatToggle tglDuplicateSkillPoints;
        private theme.FlatLabel flatLabel8;
        private theme.FlatButton btnCheaters;
        private System.Windows.Forms.Panel pnlHit;
        private theme.FlatLabel flatLabel9;
        private theme.FlatToggle tglHit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel11;
        private theme.FlatLabel flatLabel10;
        private theme.FlatToggle tglNormalHealth;
        private System.Windows.Forms.Panel panel10;
    }
}

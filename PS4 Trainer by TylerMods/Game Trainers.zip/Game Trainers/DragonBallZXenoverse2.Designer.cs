﻿namespace PS4_Trainer_by_TylerMods
{
    partial class DragonBallZXenoverse2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DragonBallZXenoverse2));
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.numZeni = new theme.FlatNumeric();
            this.flatLabel3 = new theme.FlatLabel();
            this.btnZeni = new theme.FlatButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.numEXP = new theme.FlatNumeric();
            this.flatLabel4 = new theme.FlatLabel();
            this.btnEXP = new theme.FlatButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.numSkillPoints = new theme.FlatNumeric();
            this.flatLabel2 = new theme.FlatLabel();
            this.btnSkillPoints = new theme.FlatButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.numTPZP = new theme.FlatNumeric();
            this.flatLabel1 = new theme.FlatLabel();
            this.btnTPZP = new theme.FlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnAttach = new theme.FlatButton();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label4.Location = new System.Drawing.Point(6, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(203, 28);
            this.label4.TabIndex = 74;
            this.label4.Text = "Cheater : Weysincha";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label3.Location = new System.Drawing.Point(389, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 28);
            this.label3.TabIndex = 73;
            this.label3.Text = "CUSA05088";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label1.Location = new System.Drawing.Point(312, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 28);
            this.label1.TabIndex = 71;
            this.label1.Text = "Game Version : 1.00";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel2.Controls.Add(this.numZeni);
            this.panel2.Controls.Add(this.flatLabel3);
            this.panel2.Controls.Add(this.btnZeni);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(374, 73);
            this.panel2.TabIndex = 45;
            // 
            // numZeni
            // 
            this.numZeni.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numZeni.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numZeni.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numZeni.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numZeni.ForeColor = System.Drawing.Color.White;
            this.numZeni.Location = new System.Drawing.Point(76, 19);
            this.numZeni.Maximum = ((long)(9999999));
            this.numZeni.Minimum = ((long)(0));
            this.numZeni.Name = "numZeni";
            this.numZeni.Size = new System.Drawing.Size(154, 30);
            this.numZeni.TabIndex = 3;
            this.numZeni.Text = "flatNumeric1";
            this.numZeni.Value = ((long)(0));
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(22, 23);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(38, 20);
            this.flatLabel3.TabIndex = 2;
            this.flatLabel3.Text = "Zeni";
            // 
            // btnZeni
            // 
            this.btnZeni.BackColor = System.Drawing.Color.Transparent;
            this.btnZeni.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnZeni.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnZeni.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnZeni.Location = new System.Drawing.Point(248, 12);
            this.btnZeni.Name = "btnZeni";
            this.btnZeni.Rounded = false;
            this.btnZeni.Size = new System.Drawing.Size(117, 44);
            this.btnZeni.TabIndex = 0;
            this.btnZeni.Text = "Set";
            this.btnZeni.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnZeni.Click += new System.EventHandler(this.btnZeni_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 106);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(758, 349);
            this.panel1.TabIndex = 75;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel5.Controls.Add(this.numEXP);
            this.panel5.Controls.Add(this.flatLabel4);
            this.panel5.Controls.Add(this.btnEXP);
            this.panel5.Location = new System.Drawing.Point(383, 82);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(372, 73);
            this.panel5.TabIndex = 47;
            // 
            // numEXP
            // 
            this.numEXP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numEXP.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numEXP.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numEXP.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numEXP.ForeColor = System.Drawing.Color.White;
            this.numEXP.Location = new System.Drawing.Point(76, 19);
            this.numEXP.Maximum = ((long)(9999999));
            this.numEXP.Minimum = ((long)(0));
            this.numEXP.Name = "numEXP";
            this.numEXP.Size = new System.Drawing.Size(154, 30);
            this.numEXP.TabIndex = 3;
            this.numEXP.Text = "flatNumeric1";
            this.numEXP.Value = ((long)(0));
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(22, 23);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(34, 20);
            this.flatLabel4.TabIndex = 2;
            this.flatLabel4.Text = "EXP";
            // 
            // btnEXP
            // 
            this.btnEXP.BackColor = System.Drawing.Color.Transparent;
            this.btnEXP.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnEXP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEXP.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnEXP.Location = new System.Drawing.Point(247, 12);
            this.btnEXP.Name = "btnEXP";
            this.btnEXP.Rounded = false;
            this.btnEXP.Size = new System.Drawing.Size(117, 44);
            this.btnEXP.TabIndex = 0;
            this.btnEXP.Text = "Set";
            this.btnEXP.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnEXP.Click += new System.EventHandler(this.btnEXP_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel4.Controls.Add(this.numSkillPoints);
            this.panel4.Controls.Add(this.flatLabel2);
            this.panel4.Controls.Add(this.btnSkillPoints);
            this.panel4.Location = new System.Drawing.Point(3, 82);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(374, 73);
            this.panel4.TabIndex = 46;
            // 
            // numSkillPoints
            // 
            this.numSkillPoints.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numSkillPoints.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numSkillPoints.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numSkillPoints.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numSkillPoints.ForeColor = System.Drawing.Color.White;
            this.numSkillPoints.Location = new System.Drawing.Point(88, 19);
            this.numSkillPoints.Maximum = ((long)(9999999));
            this.numSkillPoints.Minimum = ((long)(0));
            this.numSkillPoints.Name = "numSkillPoints";
            this.numSkillPoints.Size = new System.Drawing.Size(142, 30);
            this.numSkillPoints.TabIndex = 3;
            this.numSkillPoints.Text = "flatNumeric1";
            this.numSkillPoints.Value = ((long)(0));
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(3, 23);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(79, 20);
            this.flatLabel2.TabIndex = 2;
            this.flatLabel2.Text = "Skill Points";
            // 
            // btnSkillPoints
            // 
            this.btnSkillPoints.BackColor = System.Drawing.Color.Transparent;
            this.btnSkillPoints.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnSkillPoints.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSkillPoints.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnSkillPoints.Location = new System.Drawing.Point(248, 12);
            this.btnSkillPoints.Name = "btnSkillPoints";
            this.btnSkillPoints.Rounded = false;
            this.btnSkillPoints.Size = new System.Drawing.Size(117, 44);
            this.btnSkillPoints.TabIndex = 0;
            this.btnSkillPoints.Text = "Set";
            this.btnSkillPoints.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnSkillPoints.Click += new System.EventHandler(this.btnSkillPoints_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel3.Controls.Add(this.numTPZP);
            this.panel3.Controls.Add(this.flatLabel1);
            this.panel3.Controls.Add(this.btnTPZP);
            this.panel3.Location = new System.Drawing.Point(383, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(372, 73);
            this.panel3.TabIndex = 46;
            // 
            // numTPZP
            // 
            this.numTPZP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numTPZP.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numTPZP.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numTPZP.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numTPZP.ForeColor = System.Drawing.Color.White;
            this.numTPZP.Location = new System.Drawing.Point(78, 19);
            this.numTPZP.Maximum = ((long)(9999999));
            this.numTPZP.Minimum = ((long)(0));
            this.numTPZP.Name = "numTPZP";
            this.numTPZP.Size = new System.Drawing.Size(154, 30);
            this.numTPZP.TabIndex = 4;
            this.numTPZP.Text = "flatNumeric1";
            this.numTPZP.Value = ((long)(0));
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(22, 23);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(48, 20);
            this.flatLabel1.TabIndex = 2;
            this.flatLabel1.Text = "TP/ZP";
            // 
            // btnTPZP
            // 
            this.btnTPZP.BackColor = System.Drawing.Color.Transparent;
            this.btnTPZP.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnTPZP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTPZP.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnTPZP.Location = new System.Drawing.Point(247, 12);
            this.btnTPZP.Name = "btnTPZP";
            this.btnTPZP.Rounded = false;
            this.btnTPZP.Size = new System.Drawing.Size(117, 44);
            this.btnTPZP.TabIndex = 0;
            this.btnTPZP.Text = "Set";
            this.btnTPZP.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnTPZP.Click += new System.EventHandler(this.btnTPZP_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(518, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 99);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 70;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(355, 72);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 76;
            this.pictureBox2.TabStop = false;
            // 
            // btnAttach
            // 
            this.btnAttach.BackColor = System.Drawing.Color.Transparent;
            this.btnAttach.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAttach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAttach.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAttach.Location = new System.Drawing.Point(394, 3);
            this.btnAttach.Name = "btnAttach";
            this.btnAttach.Rounded = false;
            this.btnAttach.Size = new System.Drawing.Size(118, 44);
            this.btnAttach.TabIndex = 84;
            this.btnAttach.Text = "Attach";
            this.btnAttach.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAttach.Click += new System.EventHandler(this.btnAttach_Click);
            // 
            // DragonBallZXenoverse2
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.btnAttach);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "DragonBallZXenoverse2";
            this.Size = new System.Drawing.Size(758, 455);
            this.Load += new System.EventHandler(this.DragonBallZXenoverse2_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private theme.FlatLabel flatLabel3;
        private theme.FlatButton btnZeni;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private theme.FlatNumeric numZeni;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel5;
        private theme.FlatNumeric numEXP;
        private theme.FlatLabel flatLabel4;
        private theme.FlatButton btnEXP;
        private System.Windows.Forms.Panel panel4;
        private theme.FlatNumeric numSkillPoints;
        private theme.FlatLabel flatLabel2;
        private theme.FlatButton btnSkillPoints;
        private System.Windows.Forms.Panel panel3;
        private theme.FlatLabel flatLabel1;
        private theme.FlatButton btnTPZP;
        private theme.FlatNumeric numTPZP;
        private theme.FlatButton btnAttach;
    }
}

﻿namespace PS4_Trainer_by_TylerMods.Game_Trainers
{
    partial class GodofWar4
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GodofWar4));
            this.btnAttach = new theme.FlatButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.flatLabel33 = new theme.FlatLabel();
            this.tglResourceDecrease = new theme.FlatToggle();
            this.panel7 = new System.Windows.Forms.Panel();
            this.flatLabel10 = new theme.FlatLabel();
            this.tglResources = new theme.FlatToggle();
            this.panel4 = new System.Windows.Forms.Panel();
            this.numAOF = new theme.FlatNumeric();
            this.flatLabel4 = new theme.FlatLabel();
            this.btnAOF = new theme.FlatButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.flatLabel5 = new theme.FlatLabel();
            this.tglArrows = new theme.FlatToggle();
            this.panel9 = new System.Windows.Forms.Panel();
            this.numDragonTear = new theme.FlatNumeric();
            this.flatLabel8 = new theme.FlatLabel();
            this.btnDragonTear = new theme.FlatButton();
            this.panel28 = new System.Windows.Forms.Panel();
            this.numNielRec = new theme.FlatNumeric();
            this.flatLabel27 = new theme.FlatLabel();
            this.btnNielRec = new theme.FlatButton();
            this.panel30 = new System.Windows.Forms.Panel();
            this.numPrisOre = new theme.FlatNumeric();
            this.flatLabel29 = new theme.FlatLabel();
            this.btnPrisOre = new theme.FlatButton();
            this.panel29 = new System.Windows.Forms.Panel();
            this.numRustyArmor = new theme.FlatNumeric();
            this.flatLabel28 = new theme.FlatLabel();
            this.btnRustyArmor = new theme.FlatButton();
            this.panel31 = new System.Windows.Forms.Panel();
            this.numPrisScales = new theme.FlatNumeric();
            this.flatLabel30 = new theme.FlatLabel();
            this.btnPrisScales = new theme.FlatButton();
            this.panel26 = new System.Windows.Forms.Panel();
            this.numAsenfluch = new theme.FlatNumeric();
            this.flatLabel25 = new theme.FlatLabel();
            this.btnAsenfluch = new theme.FlatButton();
            this.panel32 = new System.Windows.Forms.Panel();
            this.numPerfectAsgardianSteel = new theme.FlatNumeric();
            this.flatLabel31 = new theme.FlatLabel();
            this.btnPerfectAsgardianSteel = new theme.FlatButton();
            this.panel27 = new System.Windows.Forms.Panel();
            this.numChaosFlame = new theme.FlatNumeric();
            this.flatLabel26 = new theme.FlatLabel();
            this.btnChaosFlame = new theme.FlatButton();
            this.panel33 = new System.Windows.Forms.Panel();
            this.numSurtr = new theme.FlatNumeric();
            this.flatLabel32 = new theme.FlatLabel();
            this.btnSurtr = new theme.FlatButton();
            this.panel25 = new System.Windows.Forms.Panel();
            this.flatLabel6 = new theme.FlatLabel();
            this.numRage = new theme.FlatNumeric();
            this.flatLabel24 = new theme.FlatLabel();
            this.tglRage = new theme.FlatToggle();
            this.btnRage = new theme.FlatButton();
            this.panel22 = new System.Windows.Forms.Panel();
            this.numAncientHeart = new theme.FlatNumeric();
            this.flatLabel21 = new theme.FlatLabel();
            this.btnAncientHeart = new theme.FlatButton();
            this.panel18 = new System.Windows.Forms.Panel();
            this.numCrest = new theme.FlatNumeric();
            this.flatLabel17 = new theme.FlatLabel();
            this.btnCrest = new theme.FlatButton();
            this.panel16 = new System.Windows.Forms.Panel();
            this.numHacksilver = new theme.FlatNumeric();
            this.flatLabel15 = new theme.FlatLabel();
            this.btnHacksilver = new theme.FlatButton();
            this.panel17 = new System.Windows.Forms.Panel();
            this.numSmoulderEmber = new theme.FlatNumeric();
            this.flatLabel16 = new theme.FlatLabel();
            this.btnSmoulderEmber = new theme.FlatButton();
            this.panel23 = new System.Windows.Forms.Panel();
            this.numAncientRubble = new theme.FlatNumeric();
            this.flatLabel22 = new theme.FlatLabel();
            this.btnAncientRubble = new theme.FlatButton();
            this.panel12 = new System.Windows.Forms.Panel();
            this.numMistEcho = new theme.FlatNumeric();
            this.flatLabel11 = new theme.FlatLabel();
            this.btnMistEcho = new theme.FlatButton();
            this.panel24 = new System.Windows.Forms.Panel();
            this.numDustRealms = new theme.FlatNumeric();
            this.flatLabel23 = new theme.FlatLabel();
            this.btnDustRealms = new theme.FlatButton();
            this.panel19 = new System.Windows.Forms.Panel();
            this.numGreaterCrest = new theme.FlatNumeric();
            this.flatLabel18 = new theme.FlatLabel();
            this.btnGreaterCrest = new theme.FlatButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.numAegirGold = new theme.FlatNumeric();
            this.flatLabel7 = new theme.FlatLabel();
            this.btnAegirGold = new theme.FlatButton();
            this.panel21 = new System.Windows.Forms.Panel();
            this.numNiflheimAlloy = new theme.FlatNumeric();
            this.flatLabel20 = new theme.FlatLabel();
            this.btnNiflheimAlloy = new theme.FlatButton();
            this.panel20 = new System.Windows.Forms.Panel();
            this.numAesirbane = new theme.FlatNumeric();
            this.flatLabel19 = new theme.FlatLabel();
            this.btnAesirbane = new theme.FlatButton();
            this.panel13 = new System.Windows.Forms.Panel();
            this.numApples = new theme.FlatNumeric();
            this.flatLabel12 = new theme.FlatLabel();
            this.btnApples = new theme.FlatButton();
            this.panel14 = new System.Windows.Forms.Panel();
            this.numHeatWave = new theme.FlatNumeric();
            this.flatLabel13 = new theme.FlatLabel();
            this.btnHeatWave = new theme.FlatButton();
            this.panel15 = new System.Windows.Forms.Panel();
            this.numFrozenFlame = new theme.FlatNumeric();
            this.flatLabel14 = new theme.FlatLabel();
            this.btnFrozenFlame = new theme.FlatButton();
            this.panel10 = new System.Windows.Forms.Panel();
            this.numCorruptRemnant = new theme.FlatNumeric();
            this.flatLabel9 = new theme.FlatLabel();
            this.btnCorruptRemnant = new theme.FlatButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.numXP = new theme.FlatNumeric();
            this.flatLabel1 = new theme.FlatLabel();
            this.btnXP = new theme.FlatButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.numVita = new theme.FlatNumeric();
            this.flatLabel2 = new theme.FlatLabel();
            this.btnVita = new theme.FlatButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.flatLabel3 = new theme.FlatLabel();
            this.tglGodMode = new theme.FlatToggle();
            this.btnMaxHealth = new theme.FlatButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnFAQ = new theme.FlatButton();
            this.label4 = new System.Windows.Forms.Label();
            this.tmrHealth = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tmrArrows = new System.Windows.Forms.Timer(this.components);
            this.tmrRage = new System.Windows.Forms.Timer(this.components);
            this.panel5.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAttach
            // 
            this.btnAttach.BackColor = System.Drawing.Color.Transparent;
            this.btnAttach.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAttach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAttach.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAttach.Location = new System.Drawing.Point(394, 4);
            this.btnAttach.Name = "btnAttach";
            this.btnAttach.Rounded = false;
            this.btnAttach.Size = new System.Drawing.Size(118, 44);
            this.btnAttach.TabIndex = 54;
            this.btnAttach.Text = "Attach";
            this.btnAttach.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAttach.Click += new System.EventHandler(this.btnAttach_Click);
            // 
            // panel5
            // 
            this.panel5.AutoScroll = true;
            this.panel5.Controls.Add(this.panel11);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Controls.Add(this.panel4);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel28);
            this.panel5.Controls.Add(this.panel30);
            this.panel5.Controls.Add(this.panel29);
            this.panel5.Controls.Add(this.panel31);
            this.panel5.Controls.Add(this.panel26);
            this.panel5.Controls.Add(this.panel32);
            this.panel5.Controls.Add(this.panel27);
            this.panel5.Controls.Add(this.panel33);
            this.panel5.Controls.Add(this.panel25);
            this.panel5.Controls.Add(this.panel22);
            this.panel5.Controls.Add(this.panel18);
            this.panel5.Controls.Add(this.panel16);
            this.panel5.Controls.Add(this.panel17);
            this.panel5.Controls.Add(this.panel23);
            this.panel5.Controls.Add(this.panel12);
            this.panel5.Controls.Add(this.panel24);
            this.panel5.Controls.Add(this.panel19);
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Controls.Add(this.panel21);
            this.panel5.Controls.Add(this.panel20);
            this.panel5.Controls.Add(this.panel13);
            this.panel5.Controls.Add(this.panel14);
            this.panel5.Controls.Add(this.panel15);
            this.panel5.Controls.Add(this.panel10);
            this.panel5.Controls.Add(this.panel3);
            this.panel5.Controls.Add(this.panel2);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Location = new System.Drawing.Point(0, 109);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(758, 344);
            this.panel5.TabIndex = 59;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel11.Controls.Add(this.flatLabel33);
            this.panel11.Controls.Add(this.tglResourceDecrease);
            this.panel11.Location = new System.Drawing.Point(3, 82);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(374, 73);
            this.panel11.TabIndex = 46;
            // 
            // flatLabel33
            // 
            this.flatLabel33.AutoSize = true;
            this.flatLabel33.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel33.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel33.ForeColor = System.Drawing.Color.White;
            this.flatLabel33.Location = new System.Drawing.Point(25, 25);
            this.flatLabel33.Name = "flatLabel33";
            this.flatLabel33.Size = new System.Drawing.Size(180, 20);
            this.flatLabel33.TabIndex = 2;
            this.flatLabel33.Text = "Resources Don\'t Decrease";
            // 
            // tglResourceDecrease
            // 
            this.tglResourceDecrease.BackColor = System.Drawing.Color.Transparent;
            this.tglResourceDecrease.Checked = false;
            this.tglResourceDecrease.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglResourceDecrease.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglResourceDecrease.Location = new System.Drawing.Point(279, 19);
            this.tglResourceDecrease.Name = "tglResourceDecrease";
            this.tglResourceDecrease.Options = theme.FlatToggle._Options.Style3;
            this.tglResourceDecrease.Size = new System.Drawing.Size(76, 33);
            this.tglResourceDecrease.TabIndex = 1;
            this.tglResourceDecrease.Text = "flatToggle1";
            this.tglResourceDecrease.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglResourceDecrease_CheckedChanged);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel7.Controls.Add(this.flatLabel10);
            this.panel7.Controls.Add(this.tglResources);
            this.panel7.Location = new System.Drawing.Point(383, 82);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(355, 73);
            this.panel7.TabIndex = 46;
            // 
            // flatLabel10
            // 
            this.flatLabel10.AutoSize = true;
            this.flatLabel10.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel10.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel10.ForeColor = System.Drawing.Color.White;
            this.flatLabel10.Location = new System.Drawing.Point(25, 25);
            this.flatLabel10.Name = "flatLabel10";
            this.flatLabel10.Size = new System.Drawing.Size(187, 20);
            this.flatLabel10.TabIndex = 2;
            this.flatLabel10.Text = "Use/Sell To Gain Resources";
            // 
            // tglResources
            // 
            this.tglResources.BackColor = System.Drawing.Color.Transparent;
            this.tglResources.Checked = false;
            this.tglResources.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglResources.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglResources.Location = new System.Drawing.Point(271, 19);
            this.tglResources.Name = "tglResources";
            this.tglResources.Options = theme.FlatToggle._Options.Style3;
            this.tglResources.Size = new System.Drawing.Size(76, 33);
            this.tglResources.TabIndex = 1;
            this.tglResources.Text = "flatToggle1";
            this.tglResources.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglResources_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel4.Controls.Add(this.numAOF);
            this.panel4.Controls.Add(this.flatLabel4);
            this.panel4.Controls.Add(this.btnAOF);
            this.panel4.Location = new System.Drawing.Point(383, 1188);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(355, 73);
            this.panel4.TabIndex = 71;
            // 
            // numAOF
            // 
            this.numAOF.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numAOF.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numAOF.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numAOF.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numAOF.ForeColor = System.Drawing.Color.White;
            this.numAOF.Location = new System.Drawing.Point(104, 38);
            this.numAOF.Maximum = ((long)(99999999));
            this.numAOF.Minimum = ((long)(0));
            this.numAOF.Name = "numAOF";
            this.numAOF.Size = new System.Drawing.Size(129, 30);
            this.numAOF.TabIndex = 3;
            this.numAOF.Text = "flatNumeric1";
            this.numAOF.Value = ((long)(0));
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(25, 15);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(103, 20);
            this.flatLabel4.TabIndex = 2;
            this.flatLabel4.Text = "Anchor of Fog";
            // 
            // btnAOF
            // 
            this.btnAOF.BackColor = System.Drawing.Color.Transparent;
            this.btnAOF.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAOF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAOF.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAOF.Location = new System.Drawing.Point(253, 15);
            this.btnAOF.Name = "btnAOF";
            this.btnAOF.Rounded = false;
            this.btnAOF.Size = new System.Drawing.Size(94, 44);
            this.btnAOF.TabIndex = 0;
            this.btnAOF.Text = "Set";
            this.btnAOF.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAOF.Click += new System.EventHandler(this.btnAOF_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel6.Controls.Add(this.flatLabel5);
            this.panel6.Controls.Add(this.tglArrows);
            this.panel6.Location = new System.Drawing.Point(383, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(355, 73);
            this.panel6.TabIndex = 45;
            // 
            // flatLabel5
            // 
            this.flatLabel5.AutoSize = true;
            this.flatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel5.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel5.ForeColor = System.Drawing.Color.White;
            this.flatLabel5.Location = new System.Drawing.Point(25, 25);
            this.flatLabel5.Name = "flatLabel5";
            this.flatLabel5.Size = new System.Drawing.Size(124, 20);
            this.flatLabel5.TabIndex = 2;
            this.flatLabel5.Text = "Unlimited Arrows";
            // 
            // tglArrows
            // 
            this.tglArrows.BackColor = System.Drawing.Color.Transparent;
            this.tglArrows.Checked = false;
            this.tglArrows.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglArrows.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglArrows.Location = new System.Drawing.Point(271, 19);
            this.tglArrows.Name = "tglArrows";
            this.tglArrows.Options = theme.FlatToggle._Options.Style3;
            this.tglArrows.Size = new System.Drawing.Size(76, 33);
            this.tglArrows.TabIndex = 1;
            this.tglArrows.Text = "flatToggle1";
            this.tglArrows.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglArrows_CheckedChanged);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel9.Controls.Add(this.numDragonTear);
            this.panel9.Controls.Add(this.flatLabel8);
            this.panel9.Controls.Add(this.btnDragonTear);
            this.panel9.Location = new System.Drawing.Point(3, 1188);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(374, 73);
            this.panel9.TabIndex = 72;
            // 
            // numDragonTear
            // 
            this.numDragonTear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numDragonTear.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numDragonTear.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numDragonTear.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numDragonTear.ForeColor = System.Drawing.Color.White;
            this.numDragonTear.Location = new System.Drawing.Point(104, 38);
            this.numDragonTear.Maximum = ((long)(99999999));
            this.numDragonTear.Minimum = ((long)(0));
            this.numDragonTear.Name = "numDragonTear";
            this.numDragonTear.Size = new System.Drawing.Size(129, 30);
            this.numDragonTear.TabIndex = 3;
            this.numDragonTear.Text = "flatNumeric1";
            this.numDragonTear.Value = ((long)(0));
            // 
            // flatLabel8
            // 
            this.flatLabel8.AutoSize = true;
            this.flatLabel8.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel8.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel8.ForeColor = System.Drawing.Color.White;
            this.flatLabel8.Location = new System.Drawing.Point(27, 15);
            this.flatLabel8.Name = "flatLabel8";
            this.flatLabel8.Size = new System.Drawing.Size(91, 20);
            this.flatLabel8.TabIndex = 2;
            this.flatLabel8.Text = "Dragon Tear";
            // 
            // btnDragonTear
            // 
            this.btnDragonTear.BackColor = System.Drawing.Color.Transparent;
            this.btnDragonTear.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnDragonTear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDragonTear.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnDragonTear.Location = new System.Drawing.Point(253, 15);
            this.btnDragonTear.Name = "btnDragonTear";
            this.btnDragonTear.Rounded = false;
            this.btnDragonTear.Size = new System.Drawing.Size(102, 44);
            this.btnDragonTear.TabIndex = 0;
            this.btnDragonTear.Text = "Set";
            this.btnDragonTear.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnDragonTear.Click += new System.EventHandler(this.btnDragonTear_Click);
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel28.Controls.Add(this.numNielRec);
            this.panel28.Controls.Add(this.flatLabel27);
            this.panel28.Controls.Add(this.btnNielRec);
            this.panel28.Location = new System.Drawing.Point(383, 951);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(355, 73);
            this.panel28.TabIndex = 66;
            // 
            // numNielRec
            // 
            this.numNielRec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numNielRec.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numNielRec.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numNielRec.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numNielRec.ForeColor = System.Drawing.Color.White;
            this.numNielRec.Location = new System.Drawing.Point(104, 38);
            this.numNielRec.Maximum = ((long)(99999999));
            this.numNielRec.Minimum = ((long)(0));
            this.numNielRec.Name = "numNielRec";
            this.numNielRec.Size = new System.Drawing.Size(129, 30);
            this.numNielRec.TabIndex = 3;
            this.numNielRec.Text = "flatNumeric1";
            this.numNielRec.Value = ((long)(0));
            // 
            // flatLabel27
            // 
            this.flatLabel27.AutoSize = true;
            this.flatLabel27.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel27.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel27.ForeColor = System.Drawing.Color.White;
            this.flatLabel27.Location = new System.Drawing.Point(27, 15);
            this.flatLabel27.Name = "flatLabel27";
            this.flatLabel27.Size = new System.Drawing.Size(153, 20);
            this.flatLabel27.TabIndex = 2;
            this.flatLabel27.Text = "Nielfhelm Recumbent";
            // 
            // btnNielRec
            // 
            this.btnNielRec.BackColor = System.Drawing.Color.Transparent;
            this.btnNielRec.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnNielRec.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNielRec.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnNielRec.Location = new System.Drawing.Point(253, 15);
            this.btnNielRec.Name = "btnNielRec";
            this.btnNielRec.Rounded = false;
            this.btnNielRec.Size = new System.Drawing.Size(94, 44);
            this.btnNielRec.TabIndex = 0;
            this.btnNielRec.Text = "Set";
            this.btnNielRec.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnNielRec.Click += new System.EventHandler(this.btnNielRec_Click);
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel30.Controls.Add(this.numPrisOre);
            this.panel30.Controls.Add(this.flatLabel29);
            this.panel30.Controls.Add(this.btnPrisOre);
            this.panel30.Location = new System.Drawing.Point(383, 1109);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(355, 73);
            this.panel30.TabIndex = 70;
            // 
            // numPrisOre
            // 
            this.numPrisOre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numPrisOre.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numPrisOre.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numPrisOre.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numPrisOre.ForeColor = System.Drawing.Color.White;
            this.numPrisOre.Location = new System.Drawing.Point(104, 38);
            this.numPrisOre.Maximum = ((long)(99999999));
            this.numPrisOre.Minimum = ((long)(0));
            this.numPrisOre.Name = "numPrisOre";
            this.numPrisOre.Size = new System.Drawing.Size(129, 30);
            this.numPrisOre.TabIndex = 3;
            this.numPrisOre.Text = "flatNumeric1";
            this.numPrisOre.Value = ((long)(0));
            // 
            // flatLabel29
            // 
            this.flatLabel29.AutoSize = true;
            this.flatLabel29.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel29.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel29.ForeColor = System.Drawing.Color.White;
            this.flatLabel29.Location = new System.Drawing.Point(25, 15);
            this.flatLabel29.Name = "flatLabel29";
            this.flatLabel29.Size = new System.Drawing.Size(177, 20);
            this.flatLabel29.TabIndex = 2;
            this.flatLabel29.Text = "Pristine Ore of The Realm";
            // 
            // btnPrisOre
            // 
            this.btnPrisOre.BackColor = System.Drawing.Color.Transparent;
            this.btnPrisOre.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnPrisOre.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrisOre.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnPrisOre.Location = new System.Drawing.Point(253, 15);
            this.btnPrisOre.Name = "btnPrisOre";
            this.btnPrisOre.Rounded = false;
            this.btnPrisOre.Size = new System.Drawing.Size(94, 44);
            this.btnPrisOre.TabIndex = 0;
            this.btnPrisOre.Text = "Set";
            this.btnPrisOre.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnPrisOre.Click += new System.EventHandler(this.btnPrisOre_Click);
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel29.Controls.Add(this.numRustyArmor);
            this.panel29.Controls.Add(this.flatLabel28);
            this.panel29.Controls.Add(this.btnRustyArmor);
            this.panel29.Location = new System.Drawing.Point(3, 951);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(374, 73);
            this.panel29.TabIndex = 67;
            // 
            // numRustyArmor
            // 
            this.numRustyArmor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numRustyArmor.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numRustyArmor.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numRustyArmor.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numRustyArmor.ForeColor = System.Drawing.Color.White;
            this.numRustyArmor.Location = new System.Drawing.Point(104, 38);
            this.numRustyArmor.Maximum = ((long)(99999999));
            this.numRustyArmor.Minimum = ((long)(0));
            this.numRustyArmor.Name = "numRustyArmor";
            this.numRustyArmor.Size = new System.Drawing.Size(129, 30);
            this.numRustyArmor.TabIndex = 3;
            this.numRustyArmor.Text = "flatNumeric20";
            this.numRustyArmor.Value = ((long)(0));
            // 
            // flatLabel28
            // 
            this.flatLabel28.AutoSize = true;
            this.flatLabel28.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel28.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel28.ForeColor = System.Drawing.Color.White;
            this.flatLabel28.Location = new System.Drawing.Point(24, 15);
            this.flatLabel28.Name = "flatLabel28";
            this.flatLabel28.Size = new System.Drawing.Size(90, 20);
            this.flatLabel28.TabIndex = 2;
            this.flatLabel28.Text = "Rusty Armor";
            // 
            // btnRustyArmor
            // 
            this.btnRustyArmor.BackColor = System.Drawing.Color.Transparent;
            this.btnRustyArmor.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnRustyArmor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRustyArmor.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnRustyArmor.Location = new System.Drawing.Point(253, 15);
            this.btnRustyArmor.Name = "btnRustyArmor";
            this.btnRustyArmor.Rounded = false;
            this.btnRustyArmor.Size = new System.Drawing.Size(102, 44);
            this.btnRustyArmor.TabIndex = 0;
            this.btnRustyArmor.Text = "Set";
            this.btnRustyArmor.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnRustyArmor.Click += new System.EventHandler(this.btnRustyArmor_Click);
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel31.Controls.Add(this.numPrisScales);
            this.panel31.Controls.Add(this.flatLabel30);
            this.panel31.Controls.Add(this.btnPrisScales);
            this.panel31.Location = new System.Drawing.Point(3, 1109);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(374, 73);
            this.panel31.TabIndex = 71;
            // 
            // numPrisScales
            // 
            this.numPrisScales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numPrisScales.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numPrisScales.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numPrisScales.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numPrisScales.ForeColor = System.Drawing.Color.White;
            this.numPrisScales.Location = new System.Drawing.Point(104, 38);
            this.numPrisScales.Maximum = ((long)(99999999));
            this.numPrisScales.Minimum = ((long)(0));
            this.numPrisScales.Name = "numPrisScales";
            this.numPrisScales.Size = new System.Drawing.Size(129, 30);
            this.numPrisScales.TabIndex = 3;
            this.numPrisScales.Text = "flatNumeric20";
            this.numPrisScales.Value = ((long)(0));
            // 
            // flatLabel30
            // 
            this.flatLabel30.AutoSize = true;
            this.flatLabel30.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel30.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel30.ForeColor = System.Drawing.Color.White;
            this.flatLabel30.Location = new System.Drawing.Point(24, 15);
            this.flatLabel30.Name = "flatLabel30";
            this.flatLabel30.Size = new System.Drawing.Size(194, 20);
            this.flatLabel30.TabIndex = 2;
            this.flatLabel30.Text = "Pristine Scales of The Realm";
            // 
            // btnPrisScales
            // 
            this.btnPrisScales.BackColor = System.Drawing.Color.Transparent;
            this.btnPrisScales.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnPrisScales.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrisScales.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnPrisScales.Location = new System.Drawing.Point(253, 15);
            this.btnPrisScales.Name = "btnPrisScales";
            this.btnPrisScales.Rounded = false;
            this.btnPrisScales.Size = new System.Drawing.Size(102, 44);
            this.btnPrisScales.TabIndex = 0;
            this.btnPrisScales.Text = "Set";
            this.btnPrisScales.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnPrisScales.Click += new System.EventHandler(this.btnPrisScales_Click);
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel26.Controls.Add(this.numAsenfluch);
            this.panel26.Controls.Add(this.flatLabel25);
            this.panel26.Controls.Add(this.btnAsenfluch);
            this.panel26.Location = new System.Drawing.Point(383, 872);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(355, 73);
            this.panel26.TabIndex = 64;
            // 
            // numAsenfluch
            // 
            this.numAsenfluch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numAsenfluch.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numAsenfluch.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numAsenfluch.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numAsenfluch.ForeColor = System.Drawing.Color.White;
            this.numAsenfluch.Location = new System.Drawing.Point(104, 23);
            this.numAsenfluch.Maximum = ((long)(99999999));
            this.numAsenfluch.Minimum = ((long)(0));
            this.numAsenfluch.Name = "numAsenfluch";
            this.numAsenfluch.Size = new System.Drawing.Size(129, 30);
            this.numAsenfluch.TabIndex = 3;
            this.numAsenfluch.Text = "flatNumeric1";
            this.numAsenfluch.Value = ((long)(0));
            // 
            // flatLabel25
            // 
            this.flatLabel25.AutoSize = true;
            this.flatLabel25.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel25.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel25.ForeColor = System.Drawing.Color.White;
            this.flatLabel25.Location = new System.Drawing.Point(25, 28);
            this.flatLabel25.Name = "flatLabel25";
            this.flatLabel25.Size = new System.Drawing.Size(73, 20);
            this.flatLabel25.TabIndex = 2;
            this.flatLabel25.Text = "Asenfluch";
            // 
            // btnAsenfluch
            // 
            this.btnAsenfluch.BackColor = System.Drawing.Color.Transparent;
            this.btnAsenfluch.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAsenfluch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAsenfluch.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAsenfluch.Location = new System.Drawing.Point(253, 15);
            this.btnAsenfluch.Name = "btnAsenfluch";
            this.btnAsenfluch.Rounded = false;
            this.btnAsenfluch.Size = new System.Drawing.Size(94, 44);
            this.btnAsenfluch.TabIndex = 0;
            this.btnAsenfluch.Text = "Set";
            this.btnAsenfluch.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAsenfluch.Click += new System.EventHandler(this.btnAsenfluch_Click);
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel32.Controls.Add(this.numPerfectAsgardianSteel);
            this.panel32.Controls.Add(this.flatLabel31);
            this.panel32.Controls.Add(this.btnPerfectAsgardianSteel);
            this.panel32.Location = new System.Drawing.Point(383, 1030);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(355, 73);
            this.panel32.TabIndex = 68;
            // 
            // numPerfectAsgardianSteel
            // 
            this.numPerfectAsgardianSteel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numPerfectAsgardianSteel.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numPerfectAsgardianSteel.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numPerfectAsgardianSteel.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numPerfectAsgardianSteel.ForeColor = System.Drawing.Color.White;
            this.numPerfectAsgardianSteel.Location = new System.Drawing.Point(104, 38);
            this.numPerfectAsgardianSteel.Maximum = ((long)(99999999));
            this.numPerfectAsgardianSteel.Minimum = ((long)(0));
            this.numPerfectAsgardianSteel.Name = "numPerfectAsgardianSteel";
            this.numPerfectAsgardianSteel.Size = new System.Drawing.Size(129, 30);
            this.numPerfectAsgardianSteel.TabIndex = 3;
            this.numPerfectAsgardianSteel.Text = "flatNumeric1";
            this.numPerfectAsgardianSteel.Value = ((long)(0));
            // 
            // flatLabel31
            // 
            this.flatLabel31.AutoSize = true;
            this.flatLabel31.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel31.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel31.ForeColor = System.Drawing.Color.White;
            this.flatLabel31.Location = new System.Drawing.Point(25, 15);
            this.flatLabel31.Name = "flatLabel31";
            this.flatLabel31.Size = new System.Drawing.Size(162, 20);
            this.flatLabel31.TabIndex = 2;
            this.flatLabel31.Text = "Perfect Asgardian Steel";
            // 
            // btnPerfectAsgardianSteel
            // 
            this.btnPerfectAsgardianSteel.BackColor = System.Drawing.Color.Transparent;
            this.btnPerfectAsgardianSteel.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnPerfectAsgardianSteel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPerfectAsgardianSteel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnPerfectAsgardianSteel.Location = new System.Drawing.Point(253, 15);
            this.btnPerfectAsgardianSteel.Name = "btnPerfectAsgardianSteel";
            this.btnPerfectAsgardianSteel.Rounded = false;
            this.btnPerfectAsgardianSteel.Size = new System.Drawing.Size(94, 44);
            this.btnPerfectAsgardianSteel.TabIndex = 0;
            this.btnPerfectAsgardianSteel.Text = "Set";
            this.btnPerfectAsgardianSteel.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnPerfectAsgardianSteel.Click += new System.EventHandler(this.btnPerfectAsgardianSteel_Click);
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel27.Controls.Add(this.numChaosFlame);
            this.panel27.Controls.Add(this.flatLabel26);
            this.panel27.Controls.Add(this.btnChaosFlame);
            this.panel27.Location = new System.Drawing.Point(3, 872);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(374, 73);
            this.panel27.TabIndex = 65;
            // 
            // numChaosFlame
            // 
            this.numChaosFlame.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numChaosFlame.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numChaosFlame.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numChaosFlame.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numChaosFlame.ForeColor = System.Drawing.Color.White;
            this.numChaosFlame.Location = new System.Drawing.Point(104, 38);
            this.numChaosFlame.Maximum = ((long)(99999999));
            this.numChaosFlame.Minimum = ((long)(0));
            this.numChaosFlame.Name = "numChaosFlame";
            this.numChaosFlame.Size = new System.Drawing.Size(129, 30);
            this.numChaosFlame.TabIndex = 3;
            this.numChaosFlame.Text = "flatNumeric20";
            this.numChaosFlame.Value = ((long)(0));
            // 
            // flatLabel26
            // 
            this.flatLabel26.AutoSize = true;
            this.flatLabel26.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel26.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel26.ForeColor = System.Drawing.Color.White;
            this.flatLabel26.Location = new System.Drawing.Point(24, 15);
            this.flatLabel26.Name = "flatLabel26";
            this.flatLabel26.Size = new System.Drawing.Size(93, 20);
            this.flatLabel26.TabIndex = 2;
            this.flatLabel26.Text = "Chaos Flame";
            // 
            // btnChaosFlame
            // 
            this.btnChaosFlame.BackColor = System.Drawing.Color.Transparent;
            this.btnChaosFlame.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnChaosFlame.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChaosFlame.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnChaosFlame.Location = new System.Drawing.Point(253, 15);
            this.btnChaosFlame.Name = "btnChaosFlame";
            this.btnChaosFlame.Rounded = false;
            this.btnChaosFlame.Size = new System.Drawing.Size(102, 44);
            this.btnChaosFlame.TabIndex = 0;
            this.btnChaosFlame.Text = "Set";
            this.btnChaosFlame.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnChaosFlame.Click += new System.EventHandler(this.btnChaosFlame_Click);
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel33.Controls.Add(this.numSurtr);
            this.panel33.Controls.Add(this.flatLabel32);
            this.panel33.Controls.Add(this.btnSurtr);
            this.panel33.Location = new System.Drawing.Point(3, 1030);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(374, 73);
            this.panel33.TabIndex = 69;
            // 
            // numSurtr
            // 
            this.numSurtr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numSurtr.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numSurtr.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numSurtr.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numSurtr.ForeColor = System.Drawing.Color.White;
            this.numSurtr.Location = new System.Drawing.Point(104, 38);
            this.numSurtr.Maximum = ((long)(99999999));
            this.numSurtr.Minimum = ((long)(0));
            this.numSurtr.Name = "numSurtr";
            this.numSurtr.Size = new System.Drawing.Size(129, 30);
            this.numSurtr.TabIndex = 3;
            this.numSurtr.Text = "flatNumeric20";
            this.numSurtr.Value = ((long)(0));
            // 
            // flatLabel32
            // 
            this.flatLabel32.AutoSize = true;
            this.flatLabel32.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel32.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel32.ForeColor = System.Drawing.Color.White;
            this.flatLabel32.Location = new System.Drawing.Point(24, 15);
            this.flatLabel32.Name = "flatLabel32";
            this.flatLabel32.Size = new System.Drawing.Size(95, 20);
            this.flatLabel32.TabIndex = 2;
            this.flatLabel32.Text = "Crest of Surtr";
            // 
            // btnSurtr
            // 
            this.btnSurtr.BackColor = System.Drawing.Color.Transparent;
            this.btnSurtr.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnSurtr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSurtr.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnSurtr.Location = new System.Drawing.Point(253, 15);
            this.btnSurtr.Name = "btnSurtr";
            this.btnSurtr.Rounded = false;
            this.btnSurtr.Size = new System.Drawing.Size(102, 44);
            this.btnSurtr.TabIndex = 0;
            this.btnSurtr.Text = "Set";
            this.btnSurtr.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnSurtr.Click += new System.EventHandler(this.btnSurtr_Click);
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel25.Controls.Add(this.flatLabel6);
            this.panel25.Controls.Add(this.numRage);
            this.panel25.Controls.Add(this.flatLabel24);
            this.panel25.Controls.Add(this.tglRage);
            this.panel25.Controls.Add(this.btnRage);
            this.panel25.Location = new System.Drawing.Point(383, 240);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(355, 73);
            this.panel25.TabIndex = 48;
            // 
            // flatLabel6
            // 
            this.flatLabel6.AutoSize = true;
            this.flatLabel6.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel6.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel6.ForeColor = System.Drawing.Color.White;
            this.flatLabel6.Location = new System.Drawing.Point(183, 3);
            this.flatLabel6.Name = "flatLabel6";
            this.flatLabel6.Size = new System.Drawing.Size(55, 20);
            this.flatLabel6.TabIndex = 4;
            this.flatLabel6.Text = "Infinite";
            // 
            // numRage
            // 
            this.numRage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numRage.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numRage.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numRage.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numRage.ForeColor = System.Drawing.Color.White;
            this.numRage.Location = new System.Drawing.Point(75, 21);
            this.numRage.Maximum = ((long)(99999999));
            this.numRage.Minimum = ((long)(0));
            this.numRage.Name = "numRage";
            this.numRage.Size = new System.Drawing.Size(93, 30);
            this.numRage.TabIndex = 3;
            this.numRage.Text = "flatNumeric1";
            this.numRage.Value = ((long)(0));
            // 
            // flatLabel24
            // 
            this.flatLabel24.AutoSize = true;
            this.flatLabel24.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel24.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel24.ForeColor = System.Drawing.Color.White;
            this.flatLabel24.Location = new System.Drawing.Point(27, 25);
            this.flatLabel24.Name = "flatLabel24";
            this.flatLabel24.Size = new System.Drawing.Size(43, 20);
            this.flatLabel24.TabIndex = 2;
            this.flatLabel24.Text = "Rage";
            // 
            // tglRage
            // 
            this.tglRage.BackColor = System.Drawing.Color.Transparent;
            this.tglRage.Checked = false;
            this.tglRage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglRage.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglRage.Location = new System.Drawing.Point(174, 26);
            this.tglRage.Name = "tglRage";
            this.tglRage.Options = theme.FlatToggle._Options.Style3;
            this.tglRage.Size = new System.Drawing.Size(76, 33);
            this.tglRage.TabIndex = 3;
            this.tglRage.Text = "flatToggle1";
            this.tglRage.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglRage_CheckedChanged);
            // 
            // btnRage
            // 
            this.btnRage.BackColor = System.Drawing.Color.Transparent;
            this.btnRage.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnRage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRage.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnRage.Location = new System.Drawing.Point(253, 15);
            this.btnRage.Name = "btnRage";
            this.btnRage.Rounded = false;
            this.btnRage.Size = new System.Drawing.Size(94, 44);
            this.btnRage.TabIndex = 0;
            this.btnRage.Text = "Set Rage";
            this.btnRage.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnRage.Click += new System.EventHandler(this.btnRage_Click);
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel22.Controls.Add(this.numAncientHeart);
            this.panel22.Controls.Add(this.flatLabel21);
            this.panel22.Controls.Add(this.btnAncientHeart);
            this.panel22.Location = new System.Drawing.Point(383, 793);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(355, 73);
            this.panel22.TabIndex = 62;
            // 
            // numAncientHeart
            // 
            this.numAncientHeart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numAncientHeart.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numAncientHeart.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numAncientHeart.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numAncientHeart.ForeColor = System.Drawing.Color.White;
            this.numAncientHeart.Location = new System.Drawing.Point(104, 38);
            this.numAncientHeart.Maximum = ((long)(99999999));
            this.numAncientHeart.Minimum = ((long)(0));
            this.numAncientHeart.Name = "numAncientHeart";
            this.numAncientHeart.Size = new System.Drawing.Size(129, 30);
            this.numAncientHeart.TabIndex = 3;
            this.numAncientHeart.Text = "flatNumeric1";
            this.numAncientHeart.Value = ((long)(0));
            // 
            // flatLabel21
            // 
            this.flatLabel21.AutoSize = true;
            this.flatLabel21.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel21.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel21.ForeColor = System.Drawing.Color.White;
            this.flatLabel21.Location = new System.Drawing.Point(25, 15);
            this.flatLabel21.Name = "flatLabel21";
            this.flatLabel21.Size = new System.Drawing.Size(100, 20);
            this.flatLabel21.TabIndex = 2;
            this.flatLabel21.Text = "Ancient Heart";
            // 
            // btnAncientHeart
            // 
            this.btnAncientHeart.BackColor = System.Drawing.Color.Transparent;
            this.btnAncientHeart.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAncientHeart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAncientHeart.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAncientHeart.Location = new System.Drawing.Point(253, 15);
            this.btnAncientHeart.Name = "btnAncientHeart";
            this.btnAncientHeart.Rounded = false;
            this.btnAncientHeart.Size = new System.Drawing.Size(94, 44);
            this.btnAncientHeart.TabIndex = 0;
            this.btnAncientHeart.Text = "Set";
            this.btnAncientHeart.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAncientHeart.Click += new System.EventHandler(this.btnAncientHeart_Click);
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel18.Controls.Add(this.numCrest);
            this.panel18.Controls.Add(this.flatLabel17);
            this.panel18.Controls.Add(this.btnCrest);
            this.panel18.Location = new System.Drawing.Point(383, 714);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(355, 73);
            this.panel18.TabIndex = 59;
            // 
            // numCrest
            // 
            this.numCrest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numCrest.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numCrest.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numCrest.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numCrest.ForeColor = System.Drawing.Color.White;
            this.numCrest.Location = new System.Drawing.Point(104, 38);
            this.numCrest.Maximum = ((long)(99999999));
            this.numCrest.Minimum = ((long)(0));
            this.numCrest.Name = "numCrest";
            this.numCrest.Size = new System.Drawing.Size(129, 30);
            this.numCrest.TabIndex = 3;
            this.numCrest.Text = "flatNumeric1";
            this.numCrest.Value = ((long)(0));
            // 
            // flatLabel17
            // 
            this.flatLabel17.AutoSize = true;
            this.flatLabel17.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel17.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel17.ForeColor = System.Drawing.Color.White;
            this.flatLabel17.Location = new System.Drawing.Point(27, 15);
            this.flatLabel17.Name = "flatLabel17";
            this.flatLabel17.Size = new System.Drawing.Size(104, 20);
            this.flatLabel17.TabIndex = 2;
            this.flatLabel17.Text = "Crest of Flame";
            // 
            // btnCrest
            // 
            this.btnCrest.BackColor = System.Drawing.Color.Transparent;
            this.btnCrest.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnCrest.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCrest.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnCrest.Location = new System.Drawing.Point(253, 15);
            this.btnCrest.Name = "btnCrest";
            this.btnCrest.Rounded = false;
            this.btnCrest.Size = new System.Drawing.Size(94, 44);
            this.btnCrest.TabIndex = 0;
            this.btnCrest.Text = "Set";
            this.btnCrest.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnCrest.Click += new System.EventHandler(this.btnCrest_Click);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel16.Controls.Add(this.numHacksilver);
            this.panel16.Controls.Add(this.flatLabel15);
            this.panel16.Controls.Add(this.btnHacksilver);
            this.panel16.Location = new System.Drawing.Point(3, 240);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(374, 73);
            this.panel16.TabIndex = 50;
            // 
            // numHacksilver
            // 
            this.numHacksilver.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numHacksilver.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numHacksilver.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numHacksilver.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numHacksilver.ForeColor = System.Drawing.Color.White;
            this.numHacksilver.Location = new System.Drawing.Point(104, 21);
            this.numHacksilver.Maximum = ((long)(99999999));
            this.numHacksilver.Minimum = ((long)(0));
            this.numHacksilver.Name = "numHacksilver";
            this.numHacksilver.Size = new System.Drawing.Size(129, 30);
            this.numHacksilver.TabIndex = 3;
            this.numHacksilver.Text = "flatNumeric1";
            this.numHacksilver.Value = ((long)(0));
            // 
            // flatLabel15
            // 
            this.flatLabel15.AutoSize = true;
            this.flatLabel15.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel15.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel15.ForeColor = System.Drawing.Color.White;
            this.flatLabel15.Location = new System.Drawing.Point(27, 25);
            this.flatLabel15.Name = "flatLabel15";
            this.flatLabel15.Size = new System.Drawing.Size(76, 20);
            this.flatLabel15.TabIndex = 2;
            this.flatLabel15.Text = "Hacksilver";
            // 
            // btnHacksilver
            // 
            this.btnHacksilver.BackColor = System.Drawing.Color.Transparent;
            this.btnHacksilver.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnHacksilver.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHacksilver.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnHacksilver.Location = new System.Drawing.Point(253, 15);
            this.btnHacksilver.Name = "btnHacksilver";
            this.btnHacksilver.Rounded = false;
            this.btnHacksilver.Size = new System.Drawing.Size(102, 44);
            this.btnHacksilver.TabIndex = 0;
            this.btnHacksilver.Text = "Set";
            this.btnHacksilver.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnHacksilver.Click += new System.EventHandler(this.btnHacksilver_Click);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel17.Controls.Add(this.numSmoulderEmber);
            this.panel17.Controls.Add(this.flatLabel16);
            this.panel17.Controls.Add(this.btnSmoulderEmber);
            this.panel17.Location = new System.Drawing.Point(383, 556);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(355, 73);
            this.panel17.TabIndex = 55;
            // 
            // numSmoulderEmber
            // 
            this.numSmoulderEmber.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numSmoulderEmber.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numSmoulderEmber.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numSmoulderEmber.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numSmoulderEmber.ForeColor = System.Drawing.Color.White;
            this.numSmoulderEmber.Location = new System.Drawing.Point(104, 38);
            this.numSmoulderEmber.Maximum = ((long)(99999999));
            this.numSmoulderEmber.Minimum = ((long)(0));
            this.numSmoulderEmber.Name = "numSmoulderEmber";
            this.numSmoulderEmber.Size = new System.Drawing.Size(129, 30);
            this.numSmoulderEmber.TabIndex = 3;
            this.numSmoulderEmber.Text = "flatNumeric1";
            this.numSmoulderEmber.Value = ((long)(0));
            this.numSmoulderEmber.Click += new System.EventHandler(this.flatNumeric13_Click);
            // 
            // flatLabel16
            // 
            this.flatLabel16.AutoSize = true;
            this.flatLabel16.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel16.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel16.ForeColor = System.Drawing.Color.White;
            this.flatLabel16.Location = new System.Drawing.Point(27, 15);
            this.flatLabel16.Name = "flatLabel16";
            this.flatLabel16.Size = new System.Drawing.Size(141, 20);
            this.flatLabel16.TabIndex = 2;
            this.flatLabel16.Text = "Smouldering Ember";
            // 
            // btnSmoulderEmber
            // 
            this.btnSmoulderEmber.BackColor = System.Drawing.Color.Transparent;
            this.btnSmoulderEmber.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnSmoulderEmber.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSmoulderEmber.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnSmoulderEmber.Location = new System.Drawing.Point(253, 15);
            this.btnSmoulderEmber.Name = "btnSmoulderEmber";
            this.btnSmoulderEmber.Rounded = false;
            this.btnSmoulderEmber.Size = new System.Drawing.Size(94, 44);
            this.btnSmoulderEmber.TabIndex = 0;
            this.btnSmoulderEmber.Text = "Set";
            this.btnSmoulderEmber.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnSmoulderEmber.Click += new System.EventHandler(this.btnSmoulderEmber_Click);
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel23.Controls.Add(this.numAncientRubble);
            this.panel23.Controls.Add(this.flatLabel22);
            this.panel23.Controls.Add(this.btnAncientRubble);
            this.panel23.Location = new System.Drawing.Point(3, 714);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(374, 73);
            this.panel23.TabIndex = 61;
            // 
            // numAncientRubble
            // 
            this.numAncientRubble.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numAncientRubble.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numAncientRubble.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numAncientRubble.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numAncientRubble.ForeColor = System.Drawing.Color.White;
            this.numAncientRubble.Location = new System.Drawing.Point(104, 38);
            this.numAncientRubble.Maximum = ((long)(99999999));
            this.numAncientRubble.Minimum = ((long)(0));
            this.numAncientRubble.Name = "numAncientRubble";
            this.numAncientRubble.Size = new System.Drawing.Size(129, 30);
            this.numAncientRubble.TabIndex = 3;
            this.numAncientRubble.Text = "flatNumeric1";
            this.numAncientRubble.Value = ((long)(0));
            // 
            // flatLabel22
            // 
            this.flatLabel22.AutoSize = true;
            this.flatLabel22.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel22.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel22.ForeColor = System.Drawing.Color.White;
            this.flatLabel22.Location = new System.Drawing.Point(27, 15);
            this.flatLabel22.Name = "flatLabel22";
            this.flatLabel22.Size = new System.Drawing.Size(110, 20);
            this.flatLabel22.TabIndex = 2;
            this.flatLabel22.Text = "Ancient Rubble";
            // 
            // btnAncientRubble
            // 
            this.btnAncientRubble.BackColor = System.Drawing.Color.Transparent;
            this.btnAncientRubble.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAncientRubble.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAncientRubble.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAncientRubble.Location = new System.Drawing.Point(253, 15);
            this.btnAncientRubble.Name = "btnAncientRubble";
            this.btnAncientRubble.Rounded = false;
            this.btnAncientRubble.Size = new System.Drawing.Size(102, 44);
            this.btnAncientRubble.TabIndex = 0;
            this.btnAncientRubble.Text = "Set";
            this.btnAncientRubble.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAncientRubble.Click += new System.EventHandler(this.btnAncientRubble_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel12.Controls.Add(this.numMistEcho);
            this.panel12.Controls.Add(this.flatLabel11);
            this.panel12.Controls.Add(this.btnMistEcho);
            this.panel12.Location = new System.Drawing.Point(383, 477);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(355, 73);
            this.panel12.TabIndex = 54;
            // 
            // numMistEcho
            // 
            this.numMistEcho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numMistEcho.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numMistEcho.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numMistEcho.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numMistEcho.ForeColor = System.Drawing.Color.White;
            this.numMistEcho.Location = new System.Drawing.Point(104, 21);
            this.numMistEcho.Maximum = ((long)(99999999));
            this.numMistEcho.Minimum = ((long)(0));
            this.numMistEcho.Name = "numMistEcho";
            this.numMistEcho.Size = new System.Drawing.Size(129, 30);
            this.numMistEcho.TabIndex = 3;
            this.numMistEcho.Text = "flatNumeric1";
            this.numMistEcho.Value = ((long)(0));
            // 
            // flatLabel11
            // 
            this.flatLabel11.AutoSize = true;
            this.flatLabel11.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel11.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel11.ForeColor = System.Drawing.Color.White;
            this.flatLabel11.Location = new System.Drawing.Point(25, 26);
            this.flatLabel11.Name = "flatLabel11";
            this.flatLabel11.Size = new System.Drawing.Size(73, 20);
            this.flatLabel11.TabIndex = 2;
            this.flatLabel11.Text = "Mist Echo";
            // 
            // btnMistEcho
            // 
            this.btnMistEcho.BackColor = System.Drawing.Color.Transparent;
            this.btnMistEcho.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnMistEcho.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMistEcho.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnMistEcho.Location = new System.Drawing.Point(253, 15);
            this.btnMistEcho.Name = "btnMistEcho";
            this.btnMistEcho.Rounded = false;
            this.btnMistEcho.Size = new System.Drawing.Size(94, 44);
            this.btnMistEcho.TabIndex = 0;
            this.btnMistEcho.Text = "Set";
            this.btnMistEcho.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnMistEcho.Click += new System.EventHandler(this.btnMistEcho_Click);
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel24.Controls.Add(this.numDustRealms);
            this.panel24.Controls.Add(this.flatLabel23);
            this.panel24.Controls.Add(this.btnDustRealms);
            this.panel24.Location = new System.Drawing.Point(3, 793);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(374, 73);
            this.panel24.TabIndex = 63;
            // 
            // numDustRealms
            // 
            this.numDustRealms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numDustRealms.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numDustRealms.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numDustRealms.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numDustRealms.ForeColor = System.Drawing.Color.White;
            this.numDustRealms.Location = new System.Drawing.Point(104, 38);
            this.numDustRealms.Maximum = ((long)(99999999));
            this.numDustRealms.Minimum = ((long)(0));
            this.numDustRealms.Name = "numDustRealms";
            this.numDustRealms.Size = new System.Drawing.Size(129, 30);
            this.numDustRealms.TabIndex = 3;
            this.numDustRealms.Text = "flatNumeric20";
            this.numDustRealms.Value = ((long)(0));
            // 
            // flatLabel23
            // 
            this.flatLabel23.AutoSize = true;
            this.flatLabel23.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel23.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel23.ForeColor = System.Drawing.Color.White;
            this.flatLabel23.Location = new System.Drawing.Point(24, 15);
            this.flatLabel23.Name = "flatLabel23";
            this.flatLabel23.Size = new System.Drawing.Size(109, 20);
            this.flatLabel23.TabIndex = 2;
            this.flatLabel23.Text = "Dust of Realms";
            // 
            // btnDustRealms
            // 
            this.btnDustRealms.BackColor = System.Drawing.Color.Transparent;
            this.btnDustRealms.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnDustRealms.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDustRealms.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnDustRealms.Location = new System.Drawing.Point(253, 15);
            this.btnDustRealms.Name = "btnDustRealms";
            this.btnDustRealms.Rounded = false;
            this.btnDustRealms.Size = new System.Drawing.Size(102, 44);
            this.btnDustRealms.TabIndex = 0;
            this.btnDustRealms.Text = "Set";
            this.btnDustRealms.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnDustRealms.Click += new System.EventHandler(this.btnDustRealms_Click);
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel19.Controls.Add(this.numGreaterCrest);
            this.panel19.Controls.Add(this.flatLabel18);
            this.panel19.Controls.Add(this.btnGreaterCrest);
            this.panel19.Location = new System.Drawing.Point(383, 635);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(355, 73);
            this.panel19.TabIndex = 58;
            // 
            // numGreaterCrest
            // 
            this.numGreaterCrest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numGreaterCrest.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numGreaterCrest.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numGreaterCrest.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numGreaterCrest.ForeColor = System.Drawing.Color.White;
            this.numGreaterCrest.Location = new System.Drawing.Point(104, 38);
            this.numGreaterCrest.Maximum = ((long)(99999999));
            this.numGreaterCrest.Minimum = ((long)(0));
            this.numGreaterCrest.Name = "numGreaterCrest";
            this.numGreaterCrest.Size = new System.Drawing.Size(129, 30);
            this.numGreaterCrest.TabIndex = 3;
            this.numGreaterCrest.Text = "flatNumeric1";
            this.numGreaterCrest.Value = ((long)(0));
            // 
            // flatLabel18
            // 
            this.flatLabel18.AutoSize = true;
            this.flatLabel18.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel18.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel18.ForeColor = System.Drawing.Color.White;
            this.flatLabel18.Location = new System.Drawing.Point(25, 15);
            this.flatLabel18.Name = "flatLabel18";
            this.flatLabel18.Size = new System.Drawing.Size(157, 20);
            this.flatLabel18.TabIndex = 2;
            this.flatLabel18.Text = "Greater Crest of Flame";
            // 
            // btnGreaterCrest
            // 
            this.btnGreaterCrest.BackColor = System.Drawing.Color.Transparent;
            this.btnGreaterCrest.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnGreaterCrest.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGreaterCrest.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnGreaterCrest.Location = new System.Drawing.Point(253, 15);
            this.btnGreaterCrest.Name = "btnGreaterCrest";
            this.btnGreaterCrest.Rounded = false;
            this.btnGreaterCrest.Size = new System.Drawing.Size(94, 44);
            this.btnGreaterCrest.TabIndex = 0;
            this.btnGreaterCrest.Text = "Set";
            this.btnGreaterCrest.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnGreaterCrest.Click += new System.EventHandler(this.btnGreaterCrest_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel8.Controls.Add(this.numAegirGold);
            this.panel8.Controls.Add(this.flatLabel7);
            this.panel8.Controls.Add(this.btnAegirGold);
            this.panel8.Location = new System.Drawing.Point(383, 319);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(355, 73);
            this.panel8.TabIndex = 50;
            // 
            // numAegirGold
            // 
            this.numAegirGold.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numAegirGold.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numAegirGold.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numAegirGold.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numAegirGold.ForeColor = System.Drawing.Color.White;
            this.numAegirGold.Location = new System.Drawing.Point(104, 38);
            this.numAegirGold.Maximum = ((long)(99999999));
            this.numAegirGold.Minimum = ((long)(0));
            this.numAegirGold.Name = "numAegirGold";
            this.numAegirGold.Size = new System.Drawing.Size(129, 30);
            this.numAegirGold.TabIndex = 3;
            this.numAegirGold.Text = "flatNumeric1";
            this.numAegirGold.Value = ((long)(0));
            // 
            // flatLabel7
            // 
            this.flatLabel7.AutoSize = true;
            this.flatLabel7.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel7.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel7.ForeColor = System.Drawing.Color.White;
            this.flatLabel7.Location = new System.Drawing.Point(27, 15);
            this.flatLabel7.Name = "flatLabel7";
            this.flatLabel7.Size = new System.Drawing.Size(90, 20);
            this.flatLabel7.TabIndex = 2;
            this.flatLabel7.Text = "Aegir\'s Gold";
            // 
            // btnAegirGold
            // 
            this.btnAegirGold.BackColor = System.Drawing.Color.Transparent;
            this.btnAegirGold.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAegirGold.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAegirGold.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAegirGold.Location = new System.Drawing.Point(253, 15);
            this.btnAegirGold.Name = "btnAegirGold";
            this.btnAegirGold.Rounded = false;
            this.btnAegirGold.Size = new System.Drawing.Size(94, 44);
            this.btnAegirGold.TabIndex = 0;
            this.btnAegirGold.Text = "Set";
            this.btnAegirGold.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAegirGold.Click += new System.EventHandler(this.btnAegirGold_Click);
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel21.Controls.Add(this.numNiflheimAlloy);
            this.panel21.Controls.Add(this.flatLabel20);
            this.panel21.Controls.Add(this.btnNiflheimAlloy);
            this.panel21.Location = new System.Drawing.Point(3, 556);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(374, 73);
            this.panel21.TabIndex = 57;
            // 
            // numNiflheimAlloy
            // 
            this.numNiflheimAlloy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numNiflheimAlloy.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numNiflheimAlloy.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numNiflheimAlloy.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numNiflheimAlloy.ForeColor = System.Drawing.Color.White;
            this.numNiflheimAlloy.Location = new System.Drawing.Point(104, 38);
            this.numNiflheimAlloy.Maximum = ((long)(99999999));
            this.numNiflheimAlloy.Minimum = ((long)(0));
            this.numNiflheimAlloy.Name = "numNiflheimAlloy";
            this.numNiflheimAlloy.Size = new System.Drawing.Size(129, 30);
            this.numNiflheimAlloy.TabIndex = 3;
            this.numNiflheimAlloy.Text = "flatNumeric1";
            this.numNiflheimAlloy.Value = ((long)(0));
            // 
            // flatLabel20
            // 
            this.flatLabel20.AutoSize = true;
            this.flatLabel20.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel20.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel20.ForeColor = System.Drawing.Color.White;
            this.flatLabel20.Location = new System.Drawing.Point(27, 15);
            this.flatLabel20.Name = "flatLabel20";
            this.flatLabel20.Size = new System.Drawing.Size(104, 20);
            this.flatLabel20.TabIndex = 2;
            this.flatLabel20.Text = "Niflheim Alloy";
            // 
            // btnNiflheimAlloy
            // 
            this.btnNiflheimAlloy.BackColor = System.Drawing.Color.Transparent;
            this.btnNiflheimAlloy.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnNiflheimAlloy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNiflheimAlloy.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnNiflheimAlloy.Location = new System.Drawing.Point(253, 15);
            this.btnNiflheimAlloy.Name = "btnNiflheimAlloy";
            this.btnNiflheimAlloy.Rounded = false;
            this.btnNiflheimAlloy.Size = new System.Drawing.Size(102, 44);
            this.btnNiflheimAlloy.TabIndex = 0;
            this.btnNiflheimAlloy.Text = "Set";
            this.btnNiflheimAlloy.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnNiflheimAlloy.Click += new System.EventHandler(this.btnNiflheimAlloy_Click);
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel20.Controls.Add(this.numAesirbane);
            this.panel20.Controls.Add(this.flatLabel19);
            this.panel20.Controls.Add(this.btnAesirbane);
            this.panel20.Location = new System.Drawing.Point(3, 635);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(374, 73);
            this.panel20.TabIndex = 60;
            // 
            // numAesirbane
            // 
            this.numAesirbane.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numAesirbane.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numAesirbane.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numAesirbane.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numAesirbane.ForeColor = System.Drawing.Color.White;
            this.numAesirbane.Location = new System.Drawing.Point(104, 38);
            this.numAesirbane.Maximum = ((long)(99999999));
            this.numAesirbane.Minimum = ((long)(0));
            this.numAesirbane.Name = "numAesirbane";
            this.numAesirbane.Size = new System.Drawing.Size(129, 30);
            this.numAesirbane.TabIndex = 3;
            this.numAesirbane.Text = "flatNumeric16";
            this.numAesirbane.Value = ((long)(0));
            // 
            // flatLabel19
            // 
            this.flatLabel19.AutoSize = true;
            this.flatLabel19.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel19.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel19.ForeColor = System.Drawing.Color.White;
            this.flatLabel19.Location = new System.Drawing.Point(24, 15);
            this.flatLabel19.Name = "flatLabel19";
            this.flatLabel19.Size = new System.Drawing.Size(75, 20);
            this.flatLabel19.TabIndex = 2;
            this.flatLabel19.Text = "Aesirbane";
            // 
            // btnAesirbane
            // 
            this.btnAesirbane.BackColor = System.Drawing.Color.Transparent;
            this.btnAesirbane.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAesirbane.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAesirbane.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAesirbane.Location = new System.Drawing.Point(253, 15);
            this.btnAesirbane.Name = "btnAesirbane";
            this.btnAesirbane.Rounded = false;
            this.btnAesirbane.Size = new System.Drawing.Size(102, 44);
            this.btnAesirbane.TabIndex = 0;
            this.btnAesirbane.Text = "Set";
            this.btnAesirbane.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAesirbane.Click += new System.EventHandler(this.btnAesirbane_Click);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel13.Controls.Add(this.numApples);
            this.panel13.Controls.Add(this.flatLabel12);
            this.panel13.Controls.Add(this.btnApples);
            this.panel13.Location = new System.Drawing.Point(383, 398);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(355, 73);
            this.panel13.TabIndex = 55;
            // 
            // numApples
            // 
            this.numApples.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numApples.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numApples.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numApples.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numApples.ForeColor = System.Drawing.Color.White;
            this.numApples.Location = new System.Drawing.Point(104, 21);
            this.numApples.Maximum = ((long)(99999999));
            this.numApples.Minimum = ((long)(0));
            this.numApples.Name = "numApples";
            this.numApples.Size = new System.Drawing.Size(129, 30);
            this.numApples.TabIndex = 3;
            this.numApples.Text = "flatNumeric1";
            this.numApples.Value = ((long)(0));
            // 
            // flatLabel12
            // 
            this.flatLabel12.AutoSize = true;
            this.flatLabel12.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel12.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel12.ForeColor = System.Drawing.Color.White;
            this.flatLabel12.Location = new System.Drawing.Point(27, 25);
            this.flatLabel12.Name = "flatLabel12";
            this.flatLabel12.Size = new System.Drawing.Size(55, 20);
            this.flatLabel12.TabIndex = 2;
            this.flatLabel12.Text = "Apples";
            // 
            // btnApples
            // 
            this.btnApples.BackColor = System.Drawing.Color.Transparent;
            this.btnApples.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnApples.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnApples.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnApples.Location = new System.Drawing.Point(253, 15);
            this.btnApples.Name = "btnApples";
            this.btnApples.Rounded = false;
            this.btnApples.Size = new System.Drawing.Size(94, 44);
            this.btnApples.TabIndex = 0;
            this.btnApples.Text = "Set";
            this.btnApples.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnApples.Click += new System.EventHandler(this.btnApples_Click);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel14.Controls.Add(this.numHeatWave);
            this.panel14.Controls.Add(this.flatLabel13);
            this.panel14.Controls.Add(this.btnHeatWave);
            this.panel14.Location = new System.Drawing.Point(3, 477);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(374, 73);
            this.panel14.TabIndex = 56;
            // 
            // numHeatWave
            // 
            this.numHeatWave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numHeatWave.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numHeatWave.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numHeatWave.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numHeatWave.ForeColor = System.Drawing.Color.White;
            this.numHeatWave.Location = new System.Drawing.Point(104, 38);
            this.numHeatWave.Maximum = ((long)(99999999));
            this.numHeatWave.Minimum = ((long)(0));
            this.numHeatWave.Name = "numHeatWave";
            this.numHeatWave.Size = new System.Drawing.Size(129, 30);
            this.numHeatWave.TabIndex = 3;
            this.numHeatWave.Text = "flatNumeric10";
            this.numHeatWave.Value = ((long)(0));
            // 
            // flatLabel13
            // 
            this.flatLabel13.AutoSize = true;
            this.flatLabel13.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel13.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel13.ForeColor = System.Drawing.Color.White;
            this.flatLabel13.Location = new System.Drawing.Point(24, 15);
            this.flatLabel13.Name = "flatLabel13";
            this.flatLabel13.Size = new System.Drawing.Size(83, 20);
            this.flatLabel13.TabIndex = 2;
            this.flatLabel13.Text = "Haze Wave";
            // 
            // btnHeatWave
            // 
            this.btnHeatWave.BackColor = System.Drawing.Color.Transparent;
            this.btnHeatWave.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnHeatWave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHeatWave.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnHeatWave.Location = new System.Drawing.Point(253, 15);
            this.btnHeatWave.Name = "btnHeatWave";
            this.btnHeatWave.Rounded = false;
            this.btnHeatWave.Size = new System.Drawing.Size(102, 44);
            this.btnHeatWave.TabIndex = 0;
            this.btnHeatWave.Text = "Set";
            this.btnHeatWave.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnHeatWave.Click += new System.EventHandler(this.btnHeatWave_Click);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel15.Controls.Add(this.numFrozenFlame);
            this.panel15.Controls.Add(this.flatLabel14);
            this.panel15.Controls.Add(this.btnFrozenFlame);
            this.panel15.Location = new System.Drawing.Point(3, 398);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(374, 73);
            this.panel15.TabIndex = 53;
            // 
            // numFrozenFlame
            // 
            this.numFrozenFlame.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numFrozenFlame.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numFrozenFlame.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numFrozenFlame.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numFrozenFlame.ForeColor = System.Drawing.Color.White;
            this.numFrozenFlame.Location = new System.Drawing.Point(104, 38);
            this.numFrozenFlame.Maximum = ((long)(99999999));
            this.numFrozenFlame.Minimum = ((long)(0));
            this.numFrozenFlame.Name = "numFrozenFlame";
            this.numFrozenFlame.Size = new System.Drawing.Size(129, 30);
            this.numFrozenFlame.TabIndex = 3;
            this.numFrozenFlame.Text = "flatNumeric1";
            this.numFrozenFlame.Value = ((long)(0));
            // 
            // flatLabel14
            // 
            this.flatLabel14.AutoSize = true;
            this.flatLabel14.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel14.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel14.ForeColor = System.Drawing.Color.White;
            this.flatLabel14.Location = new System.Drawing.Point(27, 15);
            this.flatLabel14.Name = "flatLabel14";
            this.flatLabel14.Size = new System.Drawing.Size(97, 20);
            this.flatLabel14.TabIndex = 2;
            this.flatLabel14.Text = "Frozen Flame";
            // 
            // btnFrozenFlame
            // 
            this.btnFrozenFlame.BackColor = System.Drawing.Color.Transparent;
            this.btnFrozenFlame.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnFrozenFlame.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFrozenFlame.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnFrozenFlame.Location = new System.Drawing.Point(253, 15);
            this.btnFrozenFlame.Name = "btnFrozenFlame";
            this.btnFrozenFlame.Rounded = false;
            this.btnFrozenFlame.Size = new System.Drawing.Size(102, 44);
            this.btnFrozenFlame.TabIndex = 0;
            this.btnFrozenFlame.Text = "Set";
            this.btnFrozenFlame.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnFrozenFlame.Click += new System.EventHandler(this.btnFrozenFlame_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel10.Controls.Add(this.numCorruptRemnant);
            this.panel10.Controls.Add(this.flatLabel9);
            this.panel10.Controls.Add(this.btnCorruptRemnant);
            this.panel10.Location = new System.Drawing.Point(3, 319);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(374, 73);
            this.panel10.TabIndex = 52;
            // 
            // numCorruptRemnant
            // 
            this.numCorruptRemnant.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numCorruptRemnant.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numCorruptRemnant.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numCorruptRemnant.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numCorruptRemnant.ForeColor = System.Drawing.Color.White;
            this.numCorruptRemnant.Location = new System.Drawing.Point(104, 38);
            this.numCorruptRemnant.Maximum = ((long)(99999999));
            this.numCorruptRemnant.Minimum = ((long)(0));
            this.numCorruptRemnant.Name = "numCorruptRemnant";
            this.numCorruptRemnant.Size = new System.Drawing.Size(129, 30);
            this.numCorruptRemnant.TabIndex = 3;
            this.numCorruptRemnant.Text = "flatNumeric6";
            this.numCorruptRemnant.Value = ((long)(0));
            // 
            // flatLabel9
            // 
            this.flatLabel9.AutoSize = true;
            this.flatLabel9.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel9.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel9.ForeColor = System.Drawing.Color.White;
            this.flatLabel9.Location = new System.Drawing.Point(24, 15);
            this.flatLabel9.Name = "flatLabel9";
            this.flatLabel9.Size = new System.Drawing.Size(139, 20);
            this.flatLabel9.TabIndex = 2;
            this.flatLabel9.Text = "Corrupted Remnant";
            // 
            // btnCorruptRemnant
            // 
            this.btnCorruptRemnant.BackColor = System.Drawing.Color.Transparent;
            this.btnCorruptRemnant.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnCorruptRemnant.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCorruptRemnant.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnCorruptRemnant.Location = new System.Drawing.Point(253, 15);
            this.btnCorruptRemnant.Name = "btnCorruptRemnant";
            this.btnCorruptRemnant.Rounded = false;
            this.btnCorruptRemnant.Size = new System.Drawing.Size(102, 44);
            this.btnCorruptRemnant.TabIndex = 0;
            this.btnCorruptRemnant.Text = "Set";
            this.btnCorruptRemnant.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnCorruptRemnant.Click += new System.EventHandler(this.btnCorruptRemnant_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel3.Controls.Add(this.numXP);
            this.panel3.Controls.Add(this.flatLabel1);
            this.panel3.Controls.Add(this.btnXP);
            this.panel3.Location = new System.Drawing.Point(3, 161);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(374, 73);
            this.panel3.TabIndex = 47;
            // 
            // numXP
            // 
            this.numXP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numXP.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numXP.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numXP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numXP.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numXP.ForeColor = System.Drawing.Color.White;
            this.numXP.Location = new System.Drawing.Point(104, 21);
            this.numXP.Maximum = ((long)(99999999));
            this.numXP.Minimum = ((long)(0));
            this.numXP.Name = "numXP";
            this.numXP.Size = new System.Drawing.Size(129, 30);
            this.numXP.TabIndex = 3;
            this.numXP.Text = "flatNumeric1";
            this.numXP.Value = ((long)(0));
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(27, 25);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(26, 20);
            this.flatLabel1.TabIndex = 2;
            this.flatLabel1.Text = "XP";
            // 
            // btnXP
            // 
            this.btnXP.BackColor = System.Drawing.Color.Transparent;
            this.btnXP.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnXP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnXP.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnXP.Location = new System.Drawing.Point(253, 15);
            this.btnXP.Name = "btnXP";
            this.btnXP.Rounded = false;
            this.btnXP.Size = new System.Drawing.Size(102, 44);
            this.btnXP.TabIndex = 0;
            this.btnXP.Text = "Set XP";
            this.btnXP.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnXP.Click += new System.EventHandler(this.btnXP_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel2.Controls.Add(this.numVita);
            this.panel2.Controls.Add(this.flatLabel2);
            this.panel2.Controls.Add(this.btnVita);
            this.panel2.Location = new System.Drawing.Point(383, 161);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(355, 73);
            this.panel2.TabIndex = 46;
            // 
            // numVita
            // 
            this.numVita.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numVita.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numVita.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numVita.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numVita.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numVita.ForeColor = System.Drawing.Color.White;
            this.numVita.Location = new System.Drawing.Point(104, 21);
            this.numVita.Maximum = ((long)(99999999));
            this.numVita.Minimum = ((long)(0));
            this.numVita.Name = "numVita";
            this.numVita.Size = new System.Drawing.Size(129, 30);
            this.numVita.TabIndex = 3;
            this.numVita.Text = "flatNumeric1";
            this.numVita.Value = ((long)(0));
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(27, 25);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(35, 20);
            this.flatLabel2.TabIndex = 2;
            this.flatLabel2.Text = "Vita";
            // 
            // btnVita
            // 
            this.btnVita.BackColor = System.Drawing.Color.Transparent;
            this.btnVita.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnVita.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVita.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnVita.Location = new System.Drawing.Point(253, 14);
            this.btnVita.Name = "btnVita";
            this.btnVita.Rounded = false;
            this.btnVita.Size = new System.Drawing.Size(94, 44);
            this.btnVita.TabIndex = 0;
            this.btnVita.Text = "Set Vita";
            this.btnVita.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnVita.Click += new System.EventHandler(this.btnVita_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel1.Controls.Add(this.flatLabel3);
            this.panel1.Controls.Add(this.tglGodMode);
            this.panel1.Controls.Add(this.btnMaxHealth);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(374, 73);
            this.panel1.TabIndex = 44;
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(24, 6);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(122, 20);
            this.flatLabel3.TabIndex = 2;
            this.flatLabel3.Text = "Unlimited Health";
            // 
            // tglGodMode
            // 
            this.tglGodMode.BackColor = System.Drawing.Color.Transparent;
            this.tglGodMode.Checked = false;
            this.tglGodMode.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglGodMode.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglGodMode.Location = new System.Drawing.Point(40, 30);
            this.tglGodMode.Name = "tglGodMode";
            this.tglGodMode.Options = theme.FlatToggle._Options.Style3;
            this.tglGodMode.Size = new System.Drawing.Size(76, 33);
            this.tglGodMode.TabIndex = 1;
            this.tglGodMode.Text = "flatToggle1";
            this.tglGodMode.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglGodMode_CheckedChanged);
            // 
            // btnMaxHealth
            // 
            this.btnMaxHealth.BackColor = System.Drawing.Color.Transparent;
            this.btnMaxHealth.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnMaxHealth.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMaxHealth.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnMaxHealth.Location = new System.Drawing.Point(233, 14);
            this.btnMaxHealth.Name = "btnMaxHealth";
            this.btnMaxHealth.Rounded = false;
            this.btnMaxHealth.Size = new System.Drawing.Size(122, 44);
            this.btnMaxHealth.TabIndex = 0;
            this.btnMaxHealth.Text = "Max Health";
            this.btnMaxHealth.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnMaxHealth.Click += new System.EventHandler(this.btnMaxHealth_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label3.Location = new System.Drawing.Point(389, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 28);
            this.label3.TabIndex = 58;
            this.label3.Text = "CUSA07410";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label1.Location = new System.Drawing.Point(312, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 28);
            this.label1.TabIndex = 57;
            this.label1.Text = "Game Version : 1.00";
            // 
            // btnFAQ
            // 
            this.btnFAQ.BackColor = System.Drawing.Color.Transparent;
            this.btnFAQ.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnFAQ.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFAQ.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnFAQ.Location = new System.Drawing.Point(356, 3);
            this.btnFAQ.Name = "btnFAQ";
            this.btnFAQ.Rounded = false;
            this.btnFAQ.Size = new System.Drawing.Size(21, 25);
            this.btnFAQ.TabIndex = 55;
            this.btnFAQ.Text = "?";
            this.btnFAQ.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnFAQ.Click += new System.EventHandler(this.btnFAQ_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label4.Location = new System.Drawing.Point(6, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(289, 28);
            this.label4.TabIndex = 60;
            this.label4.Text = "Cheater : Kraken + Vicodin10";
            // 
            // tmrHealth
            // 
            this.tmrHealth.Interval = 750;
            this.tmrHealth.Tick += new System.EventHandler(this.tmrHealth_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(518, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 102);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 62;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(350, 74);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 63;
            this.pictureBox2.TabStop = false;
            // 
            // tmrArrows
            // 
            this.tmrArrows.Interval = 750;
            this.tmrArrows.Tick += new System.EventHandler(this.tmrArrows_Tick);
            // 
            // tmrRage
            // 
            this.tmrRage.Interval = 750;
            this.tmrRage.Tick += new System.EventHandler(this.tmrRage_Tick);
            // 
            // GodofWar4
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnAttach);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnFAQ);
            this.Controls.Add(this.label4);
            this.Name = "GodofWar4";
            this.Size = new System.Drawing.Size(758, 455);
            this.panel5.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private theme.FlatButton btnAttach;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel2;
        private theme.FlatNumeric numVita;
        private theme.FlatLabel flatLabel2;
        private theme.FlatButton btnVita;
        private System.Windows.Forms.Panel panel1;
        private theme.FlatLabel flatLabel3;
        private theme.FlatToggle tglGodMode;
        private theme.FlatButton btnMaxHealth;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private theme.FlatButton btnFAQ;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Timer tmrHealth;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel3;
        private theme.FlatNumeric numXP;
        private theme.FlatLabel flatLabel1;
        private theme.FlatButton btnXP;
        private System.Windows.Forms.Panel panel8;
        private theme.FlatNumeric numAegirGold;
        private theme.FlatLabel flatLabel7;
        private theme.FlatButton btnAegirGold;
        private System.Windows.Forms.Panel panel10;
        private theme.FlatNumeric numCorruptRemnant;
        private theme.FlatLabel flatLabel9;
        private theme.FlatButton btnCorruptRemnant;
        private System.Windows.Forms.Panel panel12;
        private theme.FlatNumeric numMistEcho;
        private theme.FlatLabel flatLabel11;
        private theme.FlatButton btnMistEcho;
        private System.Windows.Forms.Panel panel13;
        private theme.FlatNumeric numApples;
        private theme.FlatLabel flatLabel12;
        private theme.FlatButton btnApples;
        private System.Windows.Forms.Panel panel14;
        private theme.FlatNumeric numHeatWave;
        private theme.FlatLabel flatLabel13;
        private theme.FlatButton btnHeatWave;
        private System.Windows.Forms.Panel panel15;
        private theme.FlatNumeric numFrozenFlame;
        private theme.FlatLabel flatLabel14;
        private theme.FlatButton btnFrozenFlame;
        private System.Windows.Forms.Panel panel17;
        private theme.FlatNumeric numSmoulderEmber;
        private theme.FlatLabel flatLabel16;
        private theme.FlatButton btnSmoulderEmber;
        private System.Windows.Forms.Panel panel16;
        private theme.FlatNumeric numHacksilver;
        private theme.FlatLabel flatLabel15;
        private theme.FlatButton btnHacksilver;
        private System.Windows.Forms.Panel panel18;
        private theme.FlatNumeric numCrest;
        private theme.FlatLabel flatLabel17;
        private theme.FlatButton btnCrest;
        private System.Windows.Forms.Panel panel19;
        private theme.FlatNumeric numGreaterCrest;
        private theme.FlatLabel flatLabel18;
        private theme.FlatButton btnGreaterCrest;
        private System.Windows.Forms.Panel panel21;
        private theme.FlatNumeric numNiflheimAlloy;
        private theme.FlatLabel flatLabel20;
        private theme.FlatButton btnNiflheimAlloy;
        private System.Windows.Forms.Panel panel20;
        private theme.FlatNumeric numAesirbane;
        private theme.FlatLabel flatLabel19;
        private theme.FlatButton btnAesirbane;
        private System.Windows.Forms.Panel panel22;
        private theme.FlatNumeric numAncientHeart;
        private theme.FlatLabel flatLabel21;
        private theme.FlatButton btnAncientHeart;
        private System.Windows.Forms.Panel panel23;
        private theme.FlatNumeric numAncientRubble;
        private theme.FlatLabel flatLabel22;
        private theme.FlatButton btnAncientRubble;
        private System.Windows.Forms.Panel panel24;
        private theme.FlatNumeric numDustRealms;
        private theme.FlatLabel flatLabel23;
        private theme.FlatButton btnDustRealms;
        private System.Windows.Forms.Panel panel25;
        private theme.FlatButton btnRage;
        private System.Windows.Forms.Panel panel26;
        private theme.FlatNumeric numAsenfluch;
        private theme.FlatLabel flatLabel25;
        private theme.FlatButton btnAsenfluch;
        private System.Windows.Forms.Panel panel27;
        private theme.FlatNumeric numChaosFlame;
        private theme.FlatLabel flatLabel26;
        private theme.FlatButton btnChaosFlame;
        private System.Windows.Forms.Panel panel28;
        private theme.FlatNumeric numNielRec;
        private theme.FlatLabel flatLabel27;
        private theme.FlatButton btnNielRec;
        private System.Windows.Forms.Panel panel29;
        private theme.FlatNumeric numRustyArmor;
        private theme.FlatLabel flatLabel28;
        private theme.FlatButton btnRustyArmor;
        private theme.FlatNumeric numRage;
        private System.Windows.Forms.Panel panel6;
        private theme.FlatLabel flatLabel5;
        private theme.FlatToggle tglArrows;
        private System.Windows.Forms.Timer tmrArrows;
        private System.Windows.Forms.Panel panel9;
        private theme.FlatNumeric numDragonTear;
        private theme.FlatLabel flatLabel8;
        private theme.FlatButton btnDragonTear;
        private System.Windows.Forms.Panel panel30;
        private theme.FlatNumeric numPrisOre;
        private theme.FlatLabel flatLabel29;
        private theme.FlatButton btnPrisOre;
        private System.Windows.Forms.Panel panel31;
        private theme.FlatNumeric numPrisScales;
        private theme.FlatLabel flatLabel30;
        private theme.FlatButton btnPrisScales;
        private System.Windows.Forms.Panel panel32;
        private theme.FlatNumeric numPerfectAsgardianSteel;
        private theme.FlatLabel flatLabel31;
        private theme.FlatButton btnPerfectAsgardianSteel;
        private System.Windows.Forms.Panel panel33;
        private theme.FlatNumeric numSurtr;
        private theme.FlatLabel flatLabel32;
        private theme.FlatButton btnSurtr;
        private System.Windows.Forms.Panel panel4;
        private theme.FlatNumeric numAOF;
        private theme.FlatLabel flatLabel4;
        private theme.FlatButton btnAOF;
        private theme.FlatLabel flatLabel6;
        private theme.FlatToggle tglRage;
        private theme.FlatLabel flatLabel24;
        private System.Windows.Forms.Timer tmrRage;
        private System.Windows.Forms.Panel panel7;
        private theme.FlatLabel flatLabel10;
        private theme.FlatToggle tglResources;
        private System.Windows.Forms.Panel panel11;
        private theme.FlatLabel flatLabel33;
        private theme.FlatToggle tglResourceDecrease;
    }
}

﻿namespace PS4_Trainer_by_TylerMods.Game_Trainers
{
    partial class D2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(D2));
            this.btnAttach = new theme.FlatButton();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnFAQ = new theme.FlatButton();
            this.label4 = new System.Windows.Forms.Label();
            this.flatLabel6 = new theme.FlatLabel();
            this.tglHealth = new theme.FlatToggle();
            this.panel8 = new System.Windows.Forms.Panel();
            this.flatLabel7 = new theme.FlatLabel();
            this.tglHorseStamina = new theme.FlatToggle();
            this.flatLabel1 = new theme.FlatLabel();
            this.tglReaper = new theme.FlatToggle();
            this.panel6 = new System.Windows.Forms.Panel();
            this.flatLabel5 = new theme.FlatLabel();
            this.tglGold = new theme.FlatToggle();
            this.flatLabel4 = new theme.FlatLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.flatLabel2 = new theme.FlatLabel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.flatLabel3 = new theme.FlatLabel();
            this.tglSkillPoints = new theme.FlatToggle();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.numGold = new theme.FlatNumeric();
            this.btnGold = new theme.FlatButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.flatLabel8 = new theme.FlatLabel();
            this.tglPotion = new theme.FlatToggle();
            this.panel10 = new System.Windows.Forms.Panel();
            this.flatLabel9 = new theme.FlatLabel();
            this.tglWrath = new theme.FlatToggle();
            this.flatToggle3 = new theme.FlatToggle();
            this.tmrHealth = new System.Windows.Forms.Timer(this.components);
            this.btnEXP = new theme.FlatButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAttach
            // 
            this.btnAttach.BackColor = System.Drawing.Color.Transparent;
            this.btnAttach.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAttach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAttach.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAttach.Location = new System.Drawing.Point(394, 4);
            this.btnAttach.Name = "btnAttach";
            this.btnAttach.Rounded = false;
            this.btnAttach.Size = new System.Drawing.Size(118, 44);
            this.btnAttach.TabIndex = 94;
            this.btnAttach.Text = "Attach";
            this.btnAttach.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAttach.Click += new System.EventHandler(this.btnAttach_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label3.Location = new System.Drawing.Point(389, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 28);
            this.label3.TabIndex = 98;
            this.label3.Text = "CUSA02420";
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(518, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 102);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 96;
            this.pictureBox1.TabStop = false;
            // 
            // btnFAQ
            // 
            this.btnFAQ.BackColor = System.Drawing.Color.Transparent;
            this.btnFAQ.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnFAQ.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFAQ.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnFAQ.Location = new System.Drawing.Point(357, 4);
            this.btnFAQ.Name = "btnFAQ";
            this.btnFAQ.Rounded = false;
            this.btnFAQ.Size = new System.Drawing.Size(21, 25);
            this.btnFAQ.TabIndex = 95;
            this.btnFAQ.Text = "?";
            this.btnFAQ.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnFAQ.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label4.Location = new System.Drawing.Point(6, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(166, 28);
            this.label4.TabIndex = 100;
            this.label4.Text = "Cheater : JgDuff";
            // 
            // flatLabel6
            // 
            this.flatLabel6.AutoSize = true;
            this.flatLabel6.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel6.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel6.ForeColor = System.Drawing.Color.White;
            this.flatLabel6.Location = new System.Drawing.Point(26, 25);
            this.flatLabel6.Name = "flatLabel6";
            this.flatLabel6.Size = new System.Drawing.Size(103, 20);
            this.flatLabel6.TabIndex = 2;
            this.flatLabel6.Text = "Infinite Health";
            // 
            // tglHealth
            // 
            this.tglHealth.BackColor = System.Drawing.Color.Transparent;
            this.tglHealth.Checked = false;
            this.tglHealth.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglHealth.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglHealth.Location = new System.Drawing.Point(295, 18);
            this.tglHealth.Name = "tglHealth";
            this.tglHealth.Options = theme.FlatToggle._Options.Style3;
            this.tglHealth.Size = new System.Drawing.Size(76, 33);
            this.tglHealth.TabIndex = 1;
            this.tglHealth.Text = "flatToggle1";
            this.tglHealth.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglHealth_CheckedChanged);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel8.Controls.Add(this.flatLabel7);
            this.panel8.Controls.Add(this.tglHorseStamina);
            this.panel8.Location = new System.Drawing.Point(3, 240);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(378, 73);
            this.panel8.TabIndex = 48;
            // 
            // flatLabel7
            // 
            this.flatLabel7.AutoSize = true;
            this.flatLabel7.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel7.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel7.ForeColor = System.Drawing.Color.White;
            this.flatLabel7.Location = new System.Drawing.Point(26, 25);
            this.flatLabel7.Name = "flatLabel7";
            this.flatLabel7.Size = new System.Drawing.Size(156, 20);
            this.flatLabel7.TabIndex = 2;
            this.flatLabel7.Text = "Infinite Horse Stamina";
            // 
            // tglHorseStamina
            // 
            this.tglHorseStamina.BackColor = System.Drawing.Color.Transparent;
            this.tglHorseStamina.Checked = false;
            this.tglHorseStamina.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglHorseStamina.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglHorseStamina.Location = new System.Drawing.Point(295, 21);
            this.tglHorseStamina.Name = "tglHorseStamina";
            this.tglHorseStamina.Options = theme.FlatToggle._Options.Style3;
            this.tglHorseStamina.Size = new System.Drawing.Size(76, 33);
            this.tglHorseStamina.TabIndex = 1;
            this.tglHorseStamina.Text = "flatToggle3";
            this.tglHorseStamina.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglHorseStamina_CheckedChanged);
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(26, 25);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(41, 20);
            this.flatLabel1.TabIndex = 2;
            this.flatLabel1.Text = "Gold";
            // 
            // tglReaper
            // 
            this.tglReaper.BackColor = System.Drawing.Color.Transparent;
            this.tglReaper.Checked = false;
            this.tglReaper.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglReaper.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglReaper.Location = new System.Drawing.Point(295, 21);
            this.tglReaper.Name = "tglReaper";
            this.tglReaper.Options = theme.FlatToggle._Options.Style3;
            this.tglReaper.Size = new System.Drawing.Size(76, 33);
            this.tglReaper.TabIndex = 1;
            this.tglReaper.Text = "flatToggle1";
            this.tglReaper.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglReaper_CheckedChanged);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel6.Controls.Add(this.flatLabel5);
            this.panel6.Controls.Add(this.flatToggle3);
            this.panel6.Controls.Add(this.tglGold);
            this.panel6.Location = new System.Drawing.Point(382, 161);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(356, 73);
            this.panel6.TabIndex = 48;
            // 
            // flatLabel5
            // 
            this.flatLabel5.AutoSize = true;
            this.flatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel5.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel5.ForeColor = System.Drawing.Color.White;
            this.flatLabel5.Location = new System.Drawing.Point(26, 25);
            this.flatLabel5.Name = "flatLabel5";
            this.flatLabel5.Size = new System.Drawing.Size(91, 20);
            this.flatLabel5.TabIndex = 2;
            this.flatLabel5.Text = "Infinite Gold";
            // 
            // tglGold
            // 
            this.tglGold.BackColor = System.Drawing.Color.Transparent;
            this.tglGold.Checked = false;
            this.tglGold.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglGold.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglGold.Location = new System.Drawing.Point(273, 21);
            this.tglGold.Name = "tglGold";
            this.tglGold.Options = theme.FlatToggle._Options.Style3;
            this.tglGold.Size = new System.Drawing.Size(76, 33);
            this.tglGold.TabIndex = 1;
            this.tglGold.Text = "flatToggle1";
            this.tglGold.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglGold_CheckedChanged);
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(26, 25);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(150, 20);
            this.flatLabel4.TabIndex = 2;
            this.flatLabel4.Text = "Infinite Reaper Power";
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(351, 72);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 101;
            this.pictureBox2.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel4.Controls.Add(this.flatLabel4);
            this.panel4.Controls.Add(this.tglReaper);
            this.panel4.Location = new System.Drawing.Point(3, 161);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(378, 73);
            this.panel4.TabIndex = 47;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel1.Controls.Add(this.numGold);
            this.panel1.Controls.Add(this.btnGold);
            this.panel1.Controls.Add(this.flatLabel1);
            this.panel1.Location = new System.Drawing.Point(3, 82);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(378, 73);
            this.panel1.TabIndex = 46;
            // 
            // panel5
            // 
            this.panel5.AutoScroll = true;
            this.panel5.Controls.Add(this.panel10);
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.panel4);
            this.panel5.Controls.Add(this.panel2);
            this.panel5.Controls.Add(this.panel3);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Location = new System.Drawing.Point(0, 109);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(758, 344);
            this.panel5.TabIndex = 99;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel2.Controls.Add(this.btnEXP);
            this.panel2.Controls.Add(this.flatLabel2);
            this.panel2.Location = new System.Drawing.Point(382, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(356, 73);
            this.panel2.TabIndex = 48;
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(26, 25);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(123, 20);
            this.flatLabel2.TabIndex = 2;
            this.flatLabel2.Text = "Max EXP On Gain";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel3.Controls.Add(this.flatLabel3);
            this.panel3.Controls.Add(this.tglSkillPoints);
            this.panel3.Location = new System.Drawing.Point(382, 82);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(356, 73);
            this.panel3.TabIndex = 47;
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(26, 25);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(129, 20);
            this.flatLabel3.TabIndex = 2;
            this.flatLabel3.Text = "Infinite Skill Points";
            // 
            // tglSkillPoints
            // 
            this.tglSkillPoints.BackColor = System.Drawing.Color.Transparent;
            this.tglSkillPoints.Checked = false;
            this.tglSkillPoints.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglSkillPoints.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglSkillPoints.Location = new System.Drawing.Point(273, 21);
            this.tglSkillPoints.Name = "tglSkillPoints";
            this.tglSkillPoints.Options = theme.FlatToggle._Options.Style3;
            this.tglSkillPoints.Size = new System.Drawing.Size(76, 33);
            this.tglSkillPoints.TabIndex = 1;
            this.tglSkillPoints.Text = "flatToggle1";
            this.tglSkillPoints.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglSkillPoints_CheckedChanged);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel7.Controls.Add(this.flatLabel6);
            this.panel7.Controls.Add(this.tglHealth);
            this.panel7.Location = new System.Drawing.Point(3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(378, 73);
            this.panel7.TabIndex = 45;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label1.Location = new System.Drawing.Point(312, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 28);
            this.label1.TabIndex = 97;
            this.label1.Text = "Game Version : 1.02";
            // 
            // numGold
            // 
            this.numGold.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numGold.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numGold.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numGold.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numGold.ForeColor = System.Drawing.Color.White;
            this.numGold.Location = new System.Drawing.Point(108, 22);
            this.numGold.Maximum = ((long)(9999999));
            this.numGold.Minimum = ((long)(0));
            this.numGold.Name = "numGold";
            this.numGold.Size = new System.Drawing.Size(145, 30);
            this.numGold.TabIndex = 5;
            this.numGold.Text = "flatNumeric1";
            this.numGold.Value = ((long)(0));
            // 
            // btnGold
            // 
            this.btnGold.BackColor = System.Drawing.Color.Transparent;
            this.btnGold.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnGold.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGold.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnGold.Location = new System.Drawing.Point(259, 16);
            this.btnGold.Name = "btnGold";
            this.btnGold.Rounded = false;
            this.btnGold.Size = new System.Drawing.Size(112, 44);
            this.btnGold.TabIndex = 4;
            this.btnGold.Text = "Set";
            this.btnGold.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnGold.Click += new System.EventHandler(this.btnGold_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel9.Controls.Add(this.flatLabel8);
            this.panel9.Controls.Add(this.tglPotion);
            this.panel9.Location = new System.Drawing.Point(382, 240);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(356, 73);
            this.panel9.TabIndex = 49;
            // 
            // flatLabel8
            // 
            this.flatLabel8.AutoSize = true;
            this.flatLabel8.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel8.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel8.ForeColor = System.Drawing.Color.White;
            this.flatLabel8.Location = new System.Drawing.Point(26, 25);
            this.flatLabel8.Name = "flatLabel8";
            this.flatLabel8.Size = new System.Drawing.Size(195, 20);
            this.flatLabel8.TabIndex = 2;
            this.flatLabel8.Text = "Infinite Health/Wrath Potion";
            // 
            // tglPotion
            // 
            this.tglPotion.BackColor = System.Drawing.Color.Transparent;
            this.tglPotion.Checked = false;
            this.tglPotion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglPotion.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglPotion.Location = new System.Drawing.Point(273, 21);
            this.tglPotion.Name = "tglPotion";
            this.tglPotion.Options = theme.FlatToggle._Options.Style3;
            this.tglPotion.Size = new System.Drawing.Size(76, 33);
            this.tglPotion.TabIndex = 1;
            this.tglPotion.Text = "flatToggle1";
            this.tglPotion.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglPotion_CheckedChanged);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel10.Controls.Add(this.flatLabel9);
            this.panel10.Controls.Add(this.tglWrath);
            this.panel10.Location = new System.Drawing.Point(3, 319);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(378, 73);
            this.panel10.TabIndex = 49;
            // 
            // flatLabel9
            // 
            this.flatLabel9.AutoSize = true;
            this.flatLabel9.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel9.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel9.ForeColor = System.Drawing.Color.White;
            this.flatLabel9.Location = new System.Drawing.Point(26, 25);
            this.flatLabel9.Name = "flatLabel9";
            this.flatLabel9.Size = new System.Drawing.Size(99, 20);
            this.flatLabel9.TabIndex = 2;
            this.flatLabel9.Text = "Infinite Wrath";
            // 
            // tglWrath
            // 
            this.tglWrath.BackColor = System.Drawing.Color.Transparent;
            this.tglWrath.Checked = false;
            this.tglWrath.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglWrath.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglWrath.Location = new System.Drawing.Point(295, 21);
            this.tglWrath.Name = "tglWrath";
            this.tglWrath.Options = theme.FlatToggle._Options.Style3;
            this.tglWrath.Size = new System.Drawing.Size(76, 33);
            this.tglWrath.TabIndex = 1;
            this.tglWrath.Text = "flatToggle3";
            this.tglWrath.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglWrath_CheckedChanged);
            // 
            // flatToggle3
            // 
            this.flatToggle3.BackColor = System.Drawing.Color.Transparent;
            this.flatToggle3.Checked = false;
            this.flatToggle3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatToggle3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.flatToggle3.Location = new System.Drawing.Point(280, -79);
            this.flatToggle3.Name = "flatToggle3";
            this.flatToggle3.Options = theme.FlatToggle._Options.Style3;
            this.flatToggle3.Size = new System.Drawing.Size(76, 33);
            this.flatToggle3.TabIndex = 1;
            this.flatToggle3.Text = "flatToggle1";
            // 
            // tmrHealth
            // 
            this.tmrHealth.Interval = 650;
            this.tmrHealth.Tick += new System.EventHandler(this.tmrHealth_Tick);
            // 
            // btnEXP
            // 
            this.btnEXP.BackColor = System.Drawing.Color.Transparent;
            this.btnEXP.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnEXP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEXP.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnEXP.Location = new System.Drawing.Point(237, 16);
            this.btnEXP.Name = "btnEXP";
            this.btnEXP.Rounded = false;
            this.btnEXP.Size = new System.Drawing.Size(112, 44);
            this.btnEXP.TabIndex = 6;
            this.btnEXP.Text = "Set";
            this.btnEXP.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnEXP.Click += new System.EventHandler(this.btnEXP_Click);
            // 
            // D2
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.btnAttach);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnFAQ);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.label1);
            this.Name = "D2";
            this.Size = new System.Drawing.Size(758, 455);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private theme.FlatButton btnAttach;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private theme.FlatButton btnFAQ;
        private System.Windows.Forms.Label label4;
        private theme.FlatLabel flatLabel6;
        private theme.FlatToggle tglHealth;
        private System.Windows.Forms.Panel panel8;
        private theme.FlatLabel flatLabel7;
        private theme.FlatToggle tglHorseStamina;
        private theme.FlatLabel flatLabel1;
        private theme.FlatToggle tglReaper;
        private System.Windows.Forms.Panel panel6;
        private theme.FlatLabel flatLabel5;
        private theme.FlatToggle tglGold;
        private theme.FlatLabel flatLabel4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel2;
        private theme.FlatLabel flatLabel2;
        private System.Windows.Forms.Panel panel3;
        private theme.FlatLabel flatLabel3;
        private theme.FlatToggle tglSkillPoints;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label1;
        private theme.FlatToggle flatToggle3;
        private theme.FlatNumeric numGold;
        private theme.FlatButton btnGold;
        private System.Windows.Forms.Panel panel10;
        private theme.FlatLabel flatLabel9;
        private theme.FlatToggle tglWrath;
        private System.Windows.Forms.Panel panel9;
        private theme.FlatLabel flatLabel8;
        private theme.FlatToggle tglPotion;
        private System.Windows.Forms.Timer tmrHealth;
        private theme.FlatButton btnEXP;
    }
}

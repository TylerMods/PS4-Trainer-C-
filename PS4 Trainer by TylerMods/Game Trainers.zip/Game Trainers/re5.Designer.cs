﻿namespace PS4_Trainer_by_TylerMods.Game_Trainers
{
    partial class re5
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(re5));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.tglAmmo = new theme.FlatToggle();
            this.flatLabel8 = new theme.FlatLabel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.tglTime = new theme.FlatToggle();
            this.flatLabel7 = new theme.FlatLabel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.numPoints = new theme.FlatNumeric();
            this.flatLabel6 = new theme.FlatLabel();
            this.btnPoints = new theme.FlatButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnShevaRapidFireOn = new theme.FlatButton();
            this.cmbSheva9999 = new theme.FlatComboBox();
            this.cmbShevaRapidFire = new theme.FlatComboBox();
            this.btnShevaRapidFireOff = new theme.FlatButton();
            this.btnSheva9999 = new theme.FlatButton();
            this.flatLabel4 = new theme.FlatLabel();
            this.flatLabel5 = new theme.FlatLabel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnChrisRapidFireOn = new theme.FlatButton();
            this.cmbChris9999 = new theme.FlatComboBox();
            this.btnChrisRapidFireOff = new theme.FlatButton();
            this.flatLabel1 = new theme.FlatLabel();
            this.flatLabel2 = new theme.FlatLabel();
            this.btnChris9999 = new theme.FlatButton();
            this.cmbChrisRapidFire = new theme.FlatComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.numMoney = new theme.FlatNumeric();
            this.flatLabel3 = new theme.FlatLabel();
            this.btnMoney = new theme.FlatButton();
            this.btnAttach = new theme.FlatButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnFAQ = new theme.FlatButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.tglMoney = new theme.FlatToggle();
            this.flatLabel9 = new theme.FlatLabel();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 106);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(758, 349);
            this.panel1.TabIndex = 88;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel7.Controls.Add(this.tglAmmo);
            this.panel7.Controls.Add(this.flatLabel8);
            this.panel7.Location = new System.Drawing.Point(3, 239);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(386, 73);
            this.panel7.TabIndex = 48;
            // 
            // tglAmmo
            // 
            this.tglAmmo.BackColor = System.Drawing.Color.Transparent;
            this.tglAmmo.Checked = false;
            this.tglAmmo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglAmmo.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglAmmo.Location = new System.Drawing.Point(299, 19);
            this.tglAmmo.Name = "tglAmmo";
            this.tglAmmo.Options = theme.FlatToggle._Options.Style3;
            this.tglAmmo.Size = new System.Drawing.Size(76, 33);
            this.tglAmmo.TabIndex = 7;
            this.tglAmmo.Text = "flatToggle3";
            this.tglAmmo.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglAmmo_CheckedChanged);
            // 
            // flatLabel8
            // 
            this.flatLabel8.AutoSize = true;
            this.flatLabel8.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel8.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel8.ForeColor = System.Drawing.Color.White;
            this.flatLabel8.Location = new System.Drawing.Point(13, 24);
            this.flatLabel8.Name = "flatLabel8";
            this.flatLabel8.Size = new System.Drawing.Size(104, 20);
            this.flatLabel8.TabIndex = 2;
            this.flatLabel8.Text = "Infinite Ammo";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel6.Controls.Add(this.tglTime);
            this.panel6.Controls.Add(this.flatLabel7);
            this.panel6.Location = new System.Drawing.Point(3, 160);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(386, 73);
            this.panel6.TabIndex = 47;
            // 
            // tglTime
            // 
            this.tglTime.BackColor = System.Drawing.Color.Transparent;
            this.tglTime.Checked = false;
            this.tglTime.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglTime.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglTime.Location = new System.Drawing.Point(299, 19);
            this.tglTime.Name = "tglTime";
            this.tglTime.Options = theme.FlatToggle._Options.Style3;
            this.tglTime.Size = new System.Drawing.Size(76, 33);
            this.tglTime.TabIndex = 7;
            this.tglTime.Text = "flatToggle3";
            this.tglTime.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglTime_CheckedChanged);
            // 
            // flatLabel7
            // 
            this.flatLabel7.AutoSize = true;
            this.flatLabel7.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel7.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel7.ForeColor = System.Drawing.Color.White;
            this.flatLabel7.Location = new System.Drawing.Point(13, 24);
            this.flatLabel7.Name = "flatLabel7";
            this.flatLabel7.Size = new System.Drawing.Size(176, 20);
            this.flatLabel7.TabIndex = 2;
            this.flatLabel7.Text = "Infinite Mercenaries Time";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel5.Controls.Add(this.numPoints);
            this.panel5.Controls.Add(this.flatLabel6);
            this.panel5.Controls.Add(this.btnPoints);
            this.panel5.Location = new System.Drawing.Point(3, 81);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(386, 73);
            this.panel5.TabIndex = 46;
            // 
            // numPoints
            // 
            this.numPoints.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numPoints.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numPoints.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numPoints.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numPoints.ForeColor = System.Drawing.Color.White;
            this.numPoints.Location = new System.Drawing.Point(97, 19);
            this.numPoints.Maximum = ((long)(9999999));
            this.numPoints.Minimum = ((long)(0));
            this.numPoints.Name = "numPoints";
            this.numPoints.Size = new System.Drawing.Size(155, 30);
            this.numPoints.TabIndex = 3;
            this.numPoints.Text = "flatNumeric1";
            this.numPoints.Value = ((long)(0));
            // 
            // flatLabel6
            // 
            this.flatLabel6.AutoSize = true;
            this.flatLabel6.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel6.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel6.ForeColor = System.Drawing.Color.White;
            this.flatLabel6.Location = new System.Drawing.Point(13, 24);
            this.flatLabel6.Name = "flatLabel6";
            this.flatLabel6.Size = new System.Drawing.Size(48, 20);
            this.flatLabel6.TabIndex = 2;
            this.flatLabel6.Text = "Points";
            // 
            // btnPoints
            // 
            this.btnPoints.BackColor = System.Drawing.Color.Transparent;
            this.btnPoints.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnPoints.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPoints.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnPoints.Location = new System.Drawing.Point(258, 14);
            this.btnPoints.Name = "btnPoints";
            this.btnPoints.Rounded = false;
            this.btnPoints.Size = new System.Drawing.Size(114, 44);
            this.btnPoints.TabIndex = 0;
            this.btnPoints.Text = "Set";
            this.btnPoints.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnPoints.Click += new System.EventHandler(this.btnPoints_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel4.Controls.Add(this.btnShevaRapidFireOn);
            this.panel4.Controls.Add(this.cmbSheva9999);
            this.panel4.Controls.Add(this.cmbShevaRapidFire);
            this.panel4.Controls.Add(this.btnShevaRapidFireOff);
            this.panel4.Controls.Add(this.btnSheva9999);
            this.panel4.Controls.Add(this.flatLabel4);
            this.panel4.Controls.Add(this.flatLabel5);
            this.panel4.Location = new System.Drawing.Point(392, 160);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(345, 152);
            this.panel4.TabIndex = 47;
            // 
            // btnShevaRapidFireOn
            // 
            this.btnShevaRapidFireOn.BackColor = System.Drawing.Color.Transparent;
            this.btnShevaRapidFireOn.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnShevaRapidFireOn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnShevaRapidFireOn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnShevaRapidFireOn.Location = new System.Drawing.Point(230, 81);
            this.btnShevaRapidFireOn.Name = "btnShevaRapidFireOn";
            this.btnShevaRapidFireOn.Rounded = false;
            this.btnShevaRapidFireOn.Size = new System.Drawing.Size(56, 44);
            this.btnShevaRapidFireOn.TabIndex = 11;
            this.btnShevaRapidFireOn.Text = "On";
            this.btnShevaRapidFireOn.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnShevaRapidFireOn.Click += new System.EventHandler(this.btnShevaRapidFireOn_Click);
            // 
            // cmbSheva9999
            // 
            this.cmbSheva9999.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.cmbSheva9999.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbSheva9999.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbSheva9999.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSheva9999.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cmbSheva9999.ForeColor = System.Drawing.Color.White;
            this.cmbSheva9999.FormattingEnabled = true;
            this.cmbSheva9999.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.cmbSheva9999.ItemHeight = 18;
            this.cmbSheva9999.Items.AddRange(new object[] {
            "Slot 1",
            "Slot 2",
            "Slot 3",
            "Slot 4",
            "Slot 5",
            "Slot 6",
            "Slot 7",
            "Slot 8",
            "Slot 9",
            "All Slots"});
            this.cmbSheva9999.Location = new System.Drawing.Point(89, 27);
            this.cmbSheva9999.Name = "cmbSheva9999";
            this.cmbSheva9999.Size = new System.Drawing.Size(138, 24);
            this.cmbSheva9999.TabIndex = 10;
            // 
            // cmbShevaRapidFire
            // 
            this.cmbShevaRapidFire.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.cmbShevaRapidFire.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbShevaRapidFire.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbShevaRapidFire.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbShevaRapidFire.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cmbShevaRapidFire.ForeColor = System.Drawing.Color.White;
            this.cmbShevaRapidFire.FormattingEnabled = true;
            this.cmbShevaRapidFire.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.cmbShevaRapidFire.ItemHeight = 18;
            this.cmbShevaRapidFire.Items.AddRange(new object[] {
            "Slot 1",
            "Slot 2",
            "Slot 3",
            "Slot 4",
            "Slot 5",
            "Slot 6",
            "Slot 7",
            "Slot 8",
            "Slot 9",
            "All Slots"});
            this.cmbShevaRapidFire.Location = new System.Drawing.Point(89, 91);
            this.cmbShevaRapidFire.Name = "cmbShevaRapidFire";
            this.cmbShevaRapidFire.Size = new System.Drawing.Size(138, 24);
            this.cmbShevaRapidFire.TabIndex = 13;
            // 
            // btnShevaRapidFireOff
            // 
            this.btnShevaRapidFireOff.BackColor = System.Drawing.Color.Transparent;
            this.btnShevaRapidFireOff.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnShevaRapidFireOff.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnShevaRapidFireOff.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnShevaRapidFireOff.Location = new System.Drawing.Point(286, 81);
            this.btnShevaRapidFireOff.Name = "btnShevaRapidFireOff";
            this.btnShevaRapidFireOff.Rounded = false;
            this.btnShevaRapidFireOff.Size = new System.Drawing.Size(56, 44);
            this.btnShevaRapidFireOff.TabIndex = 14;
            this.btnShevaRapidFireOff.Text = "Off";
            this.btnShevaRapidFireOff.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnShevaRapidFireOff.Click += new System.EventHandler(this.btnShevaRapidFireOff_Click);
            // 
            // btnSheva9999
            // 
            this.btnSheva9999.BackColor = System.Drawing.Color.Transparent;
            this.btnSheva9999.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnSheva9999.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSheva9999.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnSheva9999.Location = new System.Drawing.Point(230, 17);
            this.btnSheva9999.Name = "btnSheva9999";
            this.btnSheva9999.Rounded = false;
            this.btnSheva9999.Size = new System.Drawing.Size(112, 44);
            this.btnSheva9999.TabIndex = 8;
            this.btnSheva9999.Text = "Set 9999";
            this.btnSheva9999.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnSheva9999.Click += new System.EventHandler(this.btnSheva9999_Click);
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(13, 28);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(48, 20);
            this.flatLabel4.TabIndex = 9;
            this.flatLabel4.Text = "Sheva";
            // 
            // flatLabel5
            // 
            this.flatLabel5.AutoSize = true;
            this.flatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel5.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel5.ForeColor = System.Drawing.Color.White;
            this.flatLabel5.Location = new System.Drawing.Point(13, 93);
            this.flatLabel5.Name = "flatLabel5";
            this.flatLabel5.Size = new System.Drawing.Size(76, 20);
            this.flatLabel5.TabIndex = 12;
            this.flatLabel5.Text = "Rapid Fire";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel3.Controls.Add(this.btnChrisRapidFireOn);
            this.panel3.Controls.Add(this.cmbChris9999);
            this.panel3.Controls.Add(this.btnChrisRapidFireOff);
            this.panel3.Controls.Add(this.flatLabel1);
            this.panel3.Controls.Add(this.flatLabel2);
            this.panel3.Controls.Add(this.btnChris9999);
            this.panel3.Controls.Add(this.cmbChrisRapidFire);
            this.panel3.Location = new System.Drawing.Point(392, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(345, 151);
            this.panel3.TabIndex = 46;
            // 
            // btnChrisRapidFireOn
            // 
            this.btnChrisRapidFireOn.BackColor = System.Drawing.Color.Transparent;
            this.btnChrisRapidFireOn.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnChrisRapidFireOn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChrisRapidFireOn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnChrisRapidFireOn.Location = new System.Drawing.Point(230, 78);
            this.btnChrisRapidFireOn.Name = "btnChrisRapidFireOn";
            this.btnChrisRapidFireOn.Rounded = false;
            this.btnChrisRapidFireOn.Size = new System.Drawing.Size(56, 44);
            this.btnChrisRapidFireOn.TabIndex = 4;
            this.btnChrisRapidFireOn.Text = "On";
            this.btnChrisRapidFireOn.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnChrisRapidFireOn.Click += new System.EventHandler(this.btnChrisRapidFireOn_Click);
            // 
            // cmbChris9999
            // 
            this.cmbChris9999.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.cmbChris9999.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbChris9999.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbChris9999.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChris9999.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cmbChris9999.ForeColor = System.Drawing.Color.White;
            this.cmbChris9999.FormattingEnabled = true;
            this.cmbChris9999.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.cmbChris9999.ItemHeight = 18;
            this.cmbChris9999.Items.AddRange(new object[] {
            "Slot 1",
            "Slot 2",
            "Slot 3",
            "Slot 4",
            "Slot 5",
            "Slot 6",
            "Slot 7",
            "Slot 8",
            "Slot 9",
            "All Slots"});
            this.cmbChris9999.Location = new System.Drawing.Point(89, 24);
            this.cmbChris9999.Name = "cmbChris9999";
            this.cmbChris9999.Size = new System.Drawing.Size(138, 24);
            this.cmbChris9999.TabIndex = 3;
            // 
            // btnChrisRapidFireOff
            // 
            this.btnChrisRapidFireOff.BackColor = System.Drawing.Color.Transparent;
            this.btnChrisRapidFireOff.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnChrisRapidFireOff.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChrisRapidFireOff.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnChrisRapidFireOff.Location = new System.Drawing.Point(286, 78);
            this.btnChrisRapidFireOff.Name = "btnChrisRapidFireOff";
            this.btnChrisRapidFireOff.Rounded = false;
            this.btnChrisRapidFireOff.Size = new System.Drawing.Size(56, 44);
            this.btnChrisRapidFireOff.TabIndex = 7;
            this.btnChrisRapidFireOff.Text = "Off";
            this.btnChrisRapidFireOff.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnChrisRapidFireOff.Click += new System.EventHandler(this.btnChrisRapidFireOff_Click);
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(13, 25);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(41, 20);
            this.flatLabel1.TabIndex = 2;
            this.flatLabel1.Text = "Chris";
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(13, 90);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(76, 20);
            this.flatLabel2.TabIndex = 5;
            this.flatLabel2.Text = "Rapid Fire";
            // 
            // btnChris9999
            // 
            this.btnChris9999.BackColor = System.Drawing.Color.Transparent;
            this.btnChris9999.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnChris9999.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChris9999.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnChris9999.Location = new System.Drawing.Point(230, 14);
            this.btnChris9999.Name = "btnChris9999";
            this.btnChris9999.Rounded = false;
            this.btnChris9999.Size = new System.Drawing.Size(112, 44);
            this.btnChris9999.TabIndex = 0;
            this.btnChris9999.Text = "Set 9999";
            this.btnChris9999.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnChris9999.Click += new System.EventHandler(this.btnChris9999_Click);
            // 
            // cmbChrisRapidFire
            // 
            this.cmbChrisRapidFire.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.cmbChrisRapidFire.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbChrisRapidFire.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbChrisRapidFire.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChrisRapidFire.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cmbChrisRapidFire.ForeColor = System.Drawing.Color.White;
            this.cmbChrisRapidFire.FormattingEnabled = true;
            this.cmbChrisRapidFire.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.cmbChrisRapidFire.ItemHeight = 18;
            this.cmbChrisRapidFire.Items.AddRange(new object[] {
            "Slot 1",
            "Slot 2",
            "Slot 3",
            "Slot 4",
            "Slot 5",
            "Slot 6",
            "Slot 7",
            "Slot 8",
            "Slot 9",
            "All Slots"});
            this.cmbChrisRapidFire.Location = new System.Drawing.Point(89, 88);
            this.cmbChrisRapidFire.Name = "cmbChrisRapidFire";
            this.cmbChrisRapidFire.Size = new System.Drawing.Size(138, 24);
            this.cmbChrisRapidFire.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel2.Controls.Add(this.numMoney);
            this.panel2.Controls.Add(this.flatLabel3);
            this.panel2.Controls.Add(this.btnMoney);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(386, 73);
            this.panel2.TabIndex = 45;
            // 
            // numMoney
            // 
            this.numMoney.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numMoney.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numMoney.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numMoney.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numMoney.ForeColor = System.Drawing.Color.White;
            this.numMoney.Location = new System.Drawing.Point(97, 21);
            this.numMoney.Maximum = ((long)(9999999));
            this.numMoney.Minimum = ((long)(0));
            this.numMoney.Name = "numMoney";
            this.numMoney.Size = new System.Drawing.Size(155, 30);
            this.numMoney.TabIndex = 3;
            this.numMoney.Text = "flatNumeric1";
            this.numMoney.Value = ((long)(0));
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(13, 24);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(54, 20);
            this.flatLabel3.TabIndex = 2;
            this.flatLabel3.Text = "Money";
            // 
            // btnMoney
            // 
            this.btnMoney.BackColor = System.Drawing.Color.Transparent;
            this.btnMoney.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnMoney.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMoney.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnMoney.Location = new System.Drawing.Point(258, 14);
            this.btnMoney.Name = "btnMoney";
            this.btnMoney.Rounded = false;
            this.btnMoney.Size = new System.Drawing.Size(114, 44);
            this.btnMoney.TabIndex = 0;
            this.btnMoney.Text = "Set";
            this.btnMoney.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnMoney.Click += new System.EventHandler(this.btnMoney_Click);
            // 
            // btnAttach
            // 
            this.btnAttach.BackColor = System.Drawing.Color.Transparent;
            this.btnAttach.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAttach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAttach.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAttach.Location = new System.Drawing.Point(394, 3);
            this.btnAttach.Name = "btnAttach";
            this.btnAttach.Rounded = false;
            this.btnAttach.Size = new System.Drawing.Size(118, 44);
            this.btnAttach.TabIndex = 90;
            this.btnAttach.Text = "Attach";
            this.btnAttach.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAttach.Click += new System.EventHandler(this.btnAttach_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(351, 72);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 89;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label4.Location = new System.Drawing.Point(3, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(201, 28);
            this.label4.TabIndex = 87;
            this.label4.Text = "Cheater : TylerMods";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label3.Location = new System.Drawing.Point(389, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 28);
            this.label3.TabIndex = 86;
            this.label3.Text = "CUSA04437";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label1.Location = new System.Drawing.Point(312, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 28);
            this.label1.TabIndex = 85;
            this.label1.Text = "Game Version : 1.00";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(518, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 99);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 84;
            this.pictureBox1.TabStop = false;
            // 
            // btnFAQ
            // 
            this.btnFAQ.BackColor = System.Drawing.Color.Transparent;
            this.btnFAQ.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnFAQ.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFAQ.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnFAQ.Location = new System.Drawing.Point(357, 3);
            this.btnFAQ.Name = "btnFAQ";
            this.btnFAQ.Rounded = false;
            this.btnFAQ.Size = new System.Drawing.Size(21, 25);
            this.btnFAQ.TabIndex = 47;
            this.btnFAQ.Text = "?";
            this.btnFAQ.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnFAQ.Click += new System.EventHandler(this.btnFAQ_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel8.Controls.Add(this.tglMoney);
            this.panel8.Controls.Add(this.flatLabel9);
            this.panel8.Location = new System.Drawing.Point(3, 318);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(386, 73);
            this.panel8.TabIndex = 49;
            // 
            // tglMoney
            // 
            this.tglMoney.BackColor = System.Drawing.Color.Transparent;
            this.tglMoney.Checked = false;
            this.tglMoney.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglMoney.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglMoney.Location = new System.Drawing.Point(299, 19);
            this.tglMoney.Name = "tglMoney";
            this.tglMoney.Options = theme.FlatToggle._Options.Style3;
            this.tglMoney.Size = new System.Drawing.Size(76, 33);
            this.tglMoney.TabIndex = 7;
            this.tglMoney.Text = "flatToggle3";
            this.tglMoney.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglMoney_CheckedChanged);
            // 
            // flatLabel9
            // 
            this.flatLabel9.AutoSize = true;
            this.flatLabel9.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel9.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel9.ForeColor = System.Drawing.Color.White;
            this.flatLabel9.Location = new System.Drawing.Point(13, 24);
            this.flatLabel9.Name = "flatLabel9";
            this.flatLabel9.Size = new System.Drawing.Size(104, 20);
            this.flatLabel9.TabIndex = 2;
            this.flatLabel9.Text = "Infinite Money";
            // 
            // re5
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.btnFAQ);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnAttach);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "re5";
            this.Size = new System.Drawing.Size(758, 455);
            this.panel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private theme.FlatNumeric numMoney;
        private theme.FlatLabel flatLabel3;
        private theme.FlatButton btnAttach;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private theme.FlatLabel flatLabel1;
        private theme.FlatButton btnChris9999;
        private theme.FlatComboBox cmbChris9999;
        private theme.FlatButton btnMoney;
        private theme.FlatButton btnFAQ;
        private theme.FlatComboBox cmbChrisRapidFire;
        private theme.FlatLabel flatLabel2;
        private theme.FlatButton btnChrisRapidFireOn;
        private theme.FlatButton btnChrisRapidFireOff;
        private System.Windows.Forms.Panel panel4;
        private theme.FlatButton btnShevaRapidFireOn;
        private theme.FlatComboBox cmbSheva9999;
        private theme.FlatComboBox cmbShevaRapidFire;
        private theme.FlatButton btnShevaRapidFireOff;
        private theme.FlatButton btnSheva9999;
        private theme.FlatLabel flatLabel4;
        private theme.FlatLabel flatLabel5;
        private System.Windows.Forms.Panel panel5;
        private theme.FlatNumeric numPoints;
        private theme.FlatLabel flatLabel6;
        private theme.FlatButton btnPoints;
        private System.Windows.Forms.Panel panel6;
        private theme.FlatLabel flatLabel7;
        private theme.FlatToggle tglTime;
        private System.Windows.Forms.Panel panel7;
        private theme.FlatToggle tglAmmo;
        private theme.FlatLabel flatLabel8;
        private System.Windows.Forms.Panel panel8;
        private theme.FlatToggle tglMoney;
        private theme.FlatLabel flatLabel9;
    }
}

﻿namespace PS4_Trainer_by_TylerMods.Game_Trainers
{
    partial class NFSPayback
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NFSPayback));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlEXP = new System.Windows.Forms.Panel();
            this.tglEXP = new theme.FlatToggle();
            this.flatLabel8 = new theme.FlatLabel();
            this.pnlTokens = new System.Windows.Forms.Panel();
            this.tglTokens = new theme.FlatToggle();
            this.flatLabel5 = new theme.FlatLabel();
            this.pnlMoney = new System.Windows.Forms.Panel();
            this.tglMoney = new theme.FlatToggle();
            this.flatLabel4 = new theme.FlatLabel();
            this.pnlSetTokens = new System.Windows.Forms.Panel();
            this.numTokens = new theme.FlatNumeric();
            this.flatLabel2 = new theme.FlatLabel();
            this.btnTokens = new theme.FlatButton();
            this.pnlSetEXP = new System.Windows.Forms.Panel();
            this.numEXP = new theme.FlatNumeric();
            this.flatLabel1 = new theme.FlatLabel();
            this.btnEXP = new theme.FlatButton();
            this.pnlSetMoney = new System.Windows.Forms.Panel();
            this.numMoney = new theme.FlatNumeric();
            this.flatLabel3 = new theme.FlatLabel();
            this.btnMoney = new theme.FlatButton();
            this.btnAttach = new theme.FlatButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cmbVersion = new theme.FlatComboBox();
            this.pnlNitrous = new System.Windows.Forms.Panel();
            this.tglNitrous = new theme.FlatToggle();
            this.flatLabel7 = new theme.FlatLabel();
            this.panel1.SuspendLayout();
            this.pnlEXP.SuspendLayout();
            this.pnlTokens.SuspendLayout();
            this.pnlMoney.SuspendLayout();
            this.pnlSetTokens.SuspendLayout();
            this.pnlSetEXP.SuspendLayout();
            this.pnlSetMoney.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlNitrous.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.panel1.Controls.Add(this.pnlNitrous);
            this.panel1.Controls.Add(this.pnlEXP);
            this.panel1.Controls.Add(this.pnlTokens);
            this.panel1.Controls.Add(this.pnlMoney);
            this.panel1.Controls.Add(this.pnlSetTokens);
            this.panel1.Controls.Add(this.pnlSetEXP);
            this.panel1.Controls.Add(this.pnlSetMoney);
            this.panel1.Location = new System.Drawing.Point(0, 106);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(758, 349);
            this.panel1.TabIndex = 88;
            // 
            // pnlEXP
            // 
            this.pnlEXP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlEXP.Controls.Add(this.tglEXP);
            this.pnlEXP.Controls.Add(this.flatLabel8);
            this.pnlEXP.Location = new System.Drawing.Point(382, 240);
            this.pnlEXP.Name = "pnlEXP";
            this.pnlEXP.Size = new System.Drawing.Size(373, 73);
            this.pnlEXP.TabIndex = 50;
            // 
            // tglEXP
            // 
            this.tglEXP.BackColor = System.Drawing.Color.Transparent;
            this.tglEXP.Checked = false;
            this.tglEXP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglEXP.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglEXP.Location = new System.Drawing.Point(290, 21);
            this.tglEXP.Name = "tglEXP";
            this.tglEXP.Options = theme.FlatToggle._Options.Style3;
            this.tglEXP.Size = new System.Drawing.Size(76, 33);
            this.tglEXP.TabIndex = 3;
            this.tglEXP.Text = "flatToggle1";
            this.tglEXP.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglEXP_CheckedChanged);
            // 
            // flatLabel8
            // 
            this.flatLabel8.AutoSize = true;
            this.flatLabel8.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel8.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel8.ForeColor = System.Drawing.Color.White;
            this.flatLabel8.Location = new System.Drawing.Point(13, 24);
            this.flatLabel8.Name = "flatLabel8";
            this.flatLabel8.Size = new System.Drawing.Size(66, 20);
            this.flatLabel8.TabIndex = 2;
            this.flatLabel8.Text = "Max EXP";
            // 
            // pnlTokens
            // 
            this.pnlTokens.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlTokens.Controls.Add(this.tglTokens);
            this.pnlTokens.Controls.Add(this.flatLabel5);
            this.pnlTokens.Location = new System.Drawing.Point(3, 161);
            this.pnlTokens.Name = "pnlTokens";
            this.pnlTokens.Size = new System.Drawing.Size(378, 73);
            this.pnlTokens.TabIndex = 49;
            this.pnlTokens.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlTokens_Paint);
            // 
            // tglTokens
            // 
            this.tglTokens.BackColor = System.Drawing.Color.Transparent;
            this.tglTokens.Checked = false;
            this.tglTokens.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglTokens.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglTokens.Location = new System.Drawing.Point(297, 20);
            this.tglTokens.Name = "tglTokens";
            this.tglTokens.Options = theme.FlatToggle._Options.Style3;
            this.tglTokens.Size = new System.Drawing.Size(76, 33);
            this.tglTokens.TabIndex = 3;
            this.tglTokens.Text = "flatToggle1";
            this.tglTokens.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglTokens_CheckedChanged);
            // 
            // flatLabel5
            // 
            this.flatLabel5.AutoSize = true;
            this.flatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel5.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel5.ForeColor = System.Drawing.Color.White;
            this.flatLabel5.Location = new System.Drawing.Point(13, 24);
            this.flatLabel5.Name = "flatLabel5";
            this.flatLabel5.Size = new System.Drawing.Size(104, 20);
            this.flatLabel5.TabIndex = 2;
            this.flatLabel5.Text = "Infinite Tokens";
            // 
            // pnlMoney
            // 
            this.pnlMoney.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlMoney.Controls.Add(this.tglMoney);
            this.pnlMoney.Controls.Add(this.flatLabel4);
            this.pnlMoney.Location = new System.Drawing.Point(382, 82);
            this.pnlMoney.Name = "pnlMoney";
            this.pnlMoney.Size = new System.Drawing.Size(373, 73);
            this.pnlMoney.TabIndex = 48;
            // 
            // tglMoney
            // 
            this.tglMoney.BackColor = System.Drawing.Color.Transparent;
            this.tglMoney.Checked = false;
            this.tglMoney.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglMoney.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglMoney.Location = new System.Drawing.Point(290, 21);
            this.tglMoney.Name = "tglMoney";
            this.tglMoney.Options = theme.FlatToggle._Options.Style3;
            this.tglMoney.Size = new System.Drawing.Size(76, 33);
            this.tglMoney.TabIndex = 3;
            this.tglMoney.Text = "flatToggle1";
            this.tglMoney.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglMoney_CheckedChanged);
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(13, 24);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(104, 20);
            this.flatLabel4.TabIndex = 2;
            this.flatLabel4.Text = "Infinite Money";
            // 
            // pnlSetTokens
            // 
            this.pnlSetTokens.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlSetTokens.Controls.Add(this.numTokens);
            this.pnlSetTokens.Controls.Add(this.flatLabel2);
            this.pnlSetTokens.Controls.Add(this.btnTokens);
            this.pnlSetTokens.Location = new System.Drawing.Point(3, 82);
            this.pnlSetTokens.Name = "pnlSetTokens";
            this.pnlSetTokens.Size = new System.Drawing.Size(378, 73);
            this.pnlSetTokens.TabIndex = 47;
            // 
            // numTokens
            // 
            this.numTokens.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numTokens.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numTokens.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numTokens.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numTokens.ForeColor = System.Drawing.Color.White;
            this.numTokens.Location = new System.Drawing.Point(83, 20);
            this.numTokens.Maximum = ((long)(9999999));
            this.numTokens.Minimum = ((long)(0));
            this.numTokens.Name = "numTokens";
            this.numTokens.Size = new System.Drawing.Size(145, 30);
            this.numTokens.TabIndex = 3;
            this.numTokens.Text = "flatNumeric2";
            this.numTokens.Value = ((long)(0));
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(13, 24);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(54, 20);
            this.flatLabel2.TabIndex = 2;
            this.flatLabel2.Text = "Tokens";
            // 
            // btnTokens
            // 
            this.btnTokens.BackColor = System.Drawing.Color.Transparent;
            this.btnTokens.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnTokens.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTokens.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnTokens.Location = new System.Drawing.Point(261, 15);
            this.btnTokens.Name = "btnTokens";
            this.btnTokens.Rounded = false;
            this.btnTokens.Size = new System.Drawing.Size(112, 44);
            this.btnTokens.TabIndex = 0;
            this.btnTokens.Text = "Set";
            this.btnTokens.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnTokens.Click += new System.EventHandler(this.btnTokens_Click);
            // 
            // pnlSetEXP
            // 
            this.pnlSetEXP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlSetEXP.Controls.Add(this.numEXP);
            this.pnlSetEXP.Controls.Add(this.flatLabel1);
            this.pnlSetEXP.Controls.Add(this.btnEXP);
            this.pnlSetEXP.Location = new System.Drawing.Point(382, 3);
            this.pnlSetEXP.Name = "pnlSetEXP";
            this.pnlSetEXP.Size = new System.Drawing.Size(373, 73);
            this.pnlSetEXP.TabIndex = 46;
            // 
            // numEXP
            // 
            this.numEXP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numEXP.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numEXP.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numEXP.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numEXP.ForeColor = System.Drawing.Color.White;
            this.numEXP.Location = new System.Drawing.Point(83, 20);
            this.numEXP.Maximum = ((long)(9999999));
            this.numEXP.Minimum = ((long)(0));
            this.numEXP.Name = "numEXP";
            this.numEXP.Size = new System.Drawing.Size(145, 30);
            this.numEXP.TabIndex = 3;
            this.numEXP.Text = "flatNumeric1";
            this.numEXP.Value = ((long)(0));
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(13, 24);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(34, 20);
            this.flatLabel1.TabIndex = 2;
            this.flatLabel1.Text = "EXP";
            // 
            // btnEXP
            // 
            this.btnEXP.BackColor = System.Drawing.Color.Transparent;
            this.btnEXP.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnEXP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEXP.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnEXP.Location = new System.Drawing.Point(254, 14);
            this.btnEXP.Name = "btnEXP";
            this.btnEXP.Rounded = false;
            this.btnEXP.Size = new System.Drawing.Size(112, 44);
            this.btnEXP.TabIndex = 0;
            this.btnEXP.Text = "Set";
            this.btnEXP.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnEXP.Click += new System.EventHandler(this.btnEXP_Click);
            // 
            // pnlSetMoney
            // 
            this.pnlSetMoney.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlSetMoney.Controls.Add(this.numMoney);
            this.pnlSetMoney.Controls.Add(this.flatLabel3);
            this.pnlSetMoney.Controls.Add(this.btnMoney);
            this.pnlSetMoney.Location = new System.Drawing.Point(3, 3);
            this.pnlSetMoney.Name = "pnlSetMoney";
            this.pnlSetMoney.Size = new System.Drawing.Size(378, 73);
            this.pnlSetMoney.TabIndex = 45;
            // 
            // numMoney
            // 
            this.numMoney.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numMoney.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numMoney.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numMoney.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numMoney.ForeColor = System.Drawing.Color.White;
            this.numMoney.Location = new System.Drawing.Point(80, 20);
            this.numMoney.Maximum = ((long)(9999999));
            this.numMoney.Minimum = ((long)(0));
            this.numMoney.Name = "numMoney";
            this.numMoney.Size = new System.Drawing.Size(145, 30);
            this.numMoney.TabIndex = 3;
            this.numMoney.Text = "flatNumeric1";
            this.numMoney.Value = ((long)(0));
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(13, 24);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(54, 20);
            this.flatLabel3.TabIndex = 2;
            this.flatLabel3.Text = "Money";
            // 
            // btnMoney
            // 
            this.btnMoney.BackColor = System.Drawing.Color.Transparent;
            this.btnMoney.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnMoney.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMoney.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnMoney.Location = new System.Drawing.Point(261, 14);
            this.btnMoney.Name = "btnMoney";
            this.btnMoney.Rounded = false;
            this.btnMoney.Size = new System.Drawing.Size(112, 44);
            this.btnMoney.TabIndex = 0;
            this.btnMoney.Text = "Set";
            this.btnMoney.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnMoney.Click += new System.EventHandler(this.btnMoney_Click);
            // 
            // btnAttach
            // 
            this.btnAttach.BackColor = System.Drawing.Color.Transparent;
            this.btnAttach.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAttach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAttach.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAttach.Location = new System.Drawing.Point(394, 3);
            this.btnAttach.Name = "btnAttach";
            this.btnAttach.Rounded = false;
            this.btnAttach.Size = new System.Drawing.Size(118, 44);
            this.btnAttach.TabIndex = 90;
            this.btnAttach.Text = "Attach";
            this.btnAttach.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAttach.Click += new System.EventHandler(this.btnAttach_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(351, 72);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 89;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label4.Location = new System.Drawing.Point(3, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(328, 28);
            this.label4.TabIndex = 87;
            this.label4.Text = "Cheater : Weysincha + TylerMods";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label3.Location = new System.Drawing.Point(389, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 28);
            this.label3.TabIndex = 86;
            this.label3.Text = "CUSA05986";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(518, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 99);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 84;
            this.pictureBox1.TabStop = false;
            // 
            // cmbVersion
            // 
            this.cmbVersion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.cmbVersion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbVersion.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVersion.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cmbVersion.ForeColor = System.Drawing.Color.White;
            this.cmbVersion.FormattingEnabled = true;
            this.cmbVersion.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.cmbVersion.ItemHeight = 18;
            this.cmbVersion.Items.AddRange(new object[] {
            "v1.00",
            "v1.08"});
            this.cmbVersion.Location = new System.Drawing.Point(391, 78);
            this.cmbVersion.Name = "cmbVersion";
            this.cmbVersion.Size = new System.Drawing.Size(121, 24);
            this.cmbVersion.TabIndex = 101;
            this.cmbVersion.SelectedIndexChanged += new System.EventHandler(this.cmbVersion_SelectedIndexChanged);
            // 
            // pnlNitrous
            // 
            this.pnlNitrous.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlNitrous.Controls.Add(this.tglNitrous);
            this.pnlNitrous.Controls.Add(this.flatLabel7);
            this.pnlNitrous.Location = new System.Drawing.Point(382, 161);
            this.pnlNitrous.Name = "pnlNitrous";
            this.pnlNitrous.Size = new System.Drawing.Size(373, 73);
            this.pnlNitrous.TabIndex = 49;
            // 
            // tglNitrous
            // 
            this.tglNitrous.BackColor = System.Drawing.Color.Transparent;
            this.tglNitrous.Checked = false;
            this.tglNitrous.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglNitrous.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglNitrous.Location = new System.Drawing.Point(290, 21);
            this.tglNitrous.Name = "tglNitrous";
            this.tglNitrous.Options = theme.FlatToggle._Options.Style3;
            this.tglNitrous.Size = new System.Drawing.Size(76, 33);
            this.tglNitrous.TabIndex = 3;
            this.tglNitrous.Text = "flatToggle1";
            this.tglNitrous.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglNitrous_CheckedChanged);
            // 
            // flatLabel7
            // 
            this.flatLabel7.AutoSize = true;
            this.flatLabel7.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel7.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel7.ForeColor = System.Drawing.Color.White;
            this.flatLabel7.Location = new System.Drawing.Point(13, 24);
            this.flatLabel7.Name = "flatLabel7";
            this.flatLabel7.Size = new System.Drawing.Size(107, 20);
            this.flatLabel7.TabIndex = 2;
            this.flatLabel7.Text = "Infinite Nitrous";
            // 
            // NFSPayback
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.cmbVersion);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnAttach);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Name = "NFSPayback";
            this.Size = new System.Drawing.Size(758, 455);
            this.Load += new System.EventHandler(this.NFSPayback_Load);
            this.panel1.ResumeLayout(false);
            this.pnlEXP.ResumeLayout(false);
            this.pnlEXP.PerformLayout();
            this.pnlTokens.ResumeLayout(false);
            this.pnlTokens.PerformLayout();
            this.pnlMoney.ResumeLayout(false);
            this.pnlMoney.PerformLayout();
            this.pnlSetTokens.ResumeLayout(false);
            this.pnlSetTokens.PerformLayout();
            this.pnlSetEXP.ResumeLayout(false);
            this.pnlSetEXP.PerformLayout();
            this.pnlSetMoney.ResumeLayout(false);
            this.pnlSetMoney.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlNitrous.ResumeLayout(false);
            this.pnlNitrous.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnlSetEXP;
        private theme.FlatNumeric numEXP;
        private theme.FlatLabel flatLabel1;
        private theme.FlatButton btnEXP;
        private System.Windows.Forms.Panel pnlSetMoney;
        private theme.FlatNumeric numMoney;
        private theme.FlatLabel flatLabel3;
        private theme.FlatButton btnMoney;
        private theme.FlatButton btnAttach;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnlSetTokens;
        private theme.FlatNumeric numTokens;
        private theme.FlatLabel flatLabel2;
        private theme.FlatButton btnTokens;
        private theme.FlatComboBox cmbVersion;
        private System.Windows.Forms.Panel pnlMoney;
        private theme.FlatToggle tglMoney;
        private theme.FlatLabel flatLabel4;
        private System.Windows.Forms.Panel pnlTokens;
        private theme.FlatToggle tglTokens;
        private theme.FlatLabel flatLabel5;
        private System.Windows.Forms.Panel pnlEXP;
        private theme.FlatToggle tglEXP;
        private theme.FlatLabel flatLabel8;
        private System.Windows.Forms.Panel pnlNitrous;
        private theme.FlatToggle tglNitrous;
        private theme.FlatLabel flatLabel7;
    }
}

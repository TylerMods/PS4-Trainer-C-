﻿namespace PS4_Trainer_by_TylerMods.Game_Trainers
{
    partial class HokutoGaGotoku
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HokutoGaGotoku));
            this.btnAttach = new theme.FlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnAura = new theme.FlatButton();
            this.flatLabel5 = new theme.FlatLabel();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnMaxLevel = new theme.FlatButton();
            this.flatLabel1 = new theme.FlatLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.flatLabel3 = new theme.FlatLabel();
            this.tglHealth = new theme.FlatToggle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.flatLabel15 = new theme.FlatLabel();
            this.tglShin = new theme.FlatToggle();
            this.panel17 = new System.Windows.Forms.Panel();
            this.flatLabel16 = new theme.FlatLabel();
            this.tglSouther = new theme.FlatToggle();
            this.panel15 = new System.Windows.Forms.Panel();
            this.flatLabel14 = new theme.FlatLabel();
            this.tglRei = new theme.FlatToggle();
            this.panel14 = new System.Windows.Forms.Panel();
            this.flatLabel13 = new theme.FlatLabel();
            this.tglToki = new theme.FlatToggle();
            this.panel10 = new System.Windows.Forms.Panel();
            this.numBPCarMoney = new theme.FlatNumeric();
            this.btnBPCarMoney = new theme.FlatButton();
            this.flatLabel9 = new theme.FlatLabel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btnBlue = new theme.FlatButton();
            this.flatLabel8 = new theme.FlatLabel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.numMoney = new theme.FlatNumeric();
            this.btnMoney = new theme.FlatButton();
            this.flatLabel10 = new theme.FlatLabel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnOrange = new theme.FlatButton();
            this.flatLabel7 = new theme.FlatLabel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.numArena = new theme.FlatNumeric();
            this.btnArena = new theme.FlatButton();
            this.flatLabel11 = new theme.FlatLabel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.numPoker = new theme.FlatNumeric();
            this.btnPoker = new theme.FlatButton();
            this.flatLabel12 = new theme.FlatLabel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnYellow = new theme.FlatButton();
            this.flatLabel6 = new theme.FlatLabel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnGrey = new theme.FlatButton();
            this.flatLabel4 = new theme.FlatLabel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnGreen = new theme.FlatButton();
            this.flatLabel2 = new theme.FlatLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tmrHealth = new System.Windows.Forms.Timer(this.components);
            this.tmrToki = new System.Windows.Forms.Timer(this.components);
            this.tmrRei = new System.Windows.Forms.Timer(this.components);
            this.tmrSouther = new System.Windows.Forms.Timer(this.components);
            this.tmrShin = new System.Windows.Forms.Timer(this.components);
            this.panel18 = new System.Windows.Forms.Panel();
            this.flatLabel17 = new theme.FlatLabel();
            this.tglVehicle = new theme.FlatToggle();
            this.tmrVehicle = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel18.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAttach
            // 
            this.btnAttach.BackColor = System.Drawing.Color.Transparent;
            this.btnAttach.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAttach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAttach.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAttach.Location = new System.Drawing.Point(395, 3);
            this.btnAttach.Name = "btnAttach";
            this.btnAttach.Rounded = false;
            this.btnAttach.Size = new System.Drawing.Size(118, 44);
            this.btnAttach.TabIndex = 139;
            this.btnAttach.Text = "Attach";
            this.btnAttach.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAttach.Click += new System.EventHandler(this.btnAttach_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(519, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 99);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 133;
            this.pictureBox1.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel6.Controls.Add(this.btnAura);
            this.panel6.Controls.Add(this.flatLabel5);
            this.panel6.Location = new System.Drawing.Point(3, 161);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(375, 73);
            this.panel6.TabIndex = 46;
            // 
            // btnAura
            // 
            this.btnAura.BackColor = System.Drawing.Color.Transparent;
            this.btnAura.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAura.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAura.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAura.Location = new System.Drawing.Point(263, 15);
            this.btnAura.Name = "btnAura";
            this.btnAura.Rounded = false;
            this.btnAura.Size = new System.Drawing.Size(109, 44);
            this.btnAura.TabIndex = 5;
            this.btnAura.Text = "Set";
            this.btnAura.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAura.Click += new System.EventHandler(this.btnAura_Click);
            // 
            // flatLabel5
            // 
            this.flatLabel5.AutoSize = true;
            this.flatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel5.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel5.ForeColor = System.Drawing.Color.White;
            this.flatLabel5.Location = new System.Drawing.Point(13, 24);
            this.flatLabel5.Name = "flatLabel5";
            this.flatLabel5.Size = new System.Drawing.Size(72, 20);
            this.flatLabel5.TabIndex = 2;
            this.flatLabel5.Text = "Max Aura";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label3.Location = new System.Drawing.Point(394, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 28);
            this.label3.TabIndex = 135;
            this.label3.Text = "CUSA10053";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label1.Location = new System.Drawing.Point(317, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 28);
            this.label1.TabIndex = 134;
            this.label1.Text = "Game Version : 1.00";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel3.Controls.Add(this.btnMaxLevel);
            this.panel3.Controls.Add(this.flatLabel1);
            this.panel3.Location = new System.Drawing.Point(384, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(350, 73);
            this.panel3.TabIndex = 46;
            // 
            // btnMaxLevel
            // 
            this.btnMaxLevel.BackColor = System.Drawing.Color.Transparent;
            this.btnMaxLevel.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnMaxLevel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMaxLevel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnMaxLevel.Location = new System.Drawing.Point(237, 14);
            this.btnMaxLevel.Name = "btnMaxLevel";
            this.btnMaxLevel.Rounded = false;
            this.btnMaxLevel.Size = new System.Drawing.Size(109, 44);
            this.btnMaxLevel.TabIndex = 4;
            this.btnMaxLevel.Text = "Set";
            this.btnMaxLevel.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnMaxLevel.Click += new System.EventHandler(this.btnMaxLevel_Click);
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(13, 24);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(98, 20);
            this.flatLabel1.TabIndex = 2;
            this.flatLabel1.Text = "Max Level Up";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label4.Location = new System.Drawing.Point(-1, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(201, 28);
            this.label4.TabIndex = 136;
            this.label4.Text = "Cheater : Vampirexx";
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(13, 24);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(103, 20);
            this.flatLabel3.TabIndex = 2;
            this.flatLabel3.Text = "Infinite Health";
            // 
            // tglHealth
            // 
            this.tglHealth.BackColor = System.Drawing.Color.Transparent;
            this.tglHealth.Checked = false;
            this.tglHealth.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglHealth.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglHealth.Location = new System.Drawing.Point(296, 20);
            this.tglHealth.Name = "tglHealth";
            this.tglHealth.Options = theme.FlatToggle._Options.Style3;
            this.tglHealth.Size = new System.Drawing.Size(76, 33);
            this.tglHealth.TabIndex = 5;
            this.tglHealth.Text = "flatToggle1";
            this.tglHealth.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglHealth_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel2.Controls.Add(this.flatLabel3);
            this.panel2.Controls.Add(this.tglHealth);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(375, 73);
            this.panel2.TabIndex = 45;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.panel1.Controls.Add(this.panel18);
            this.panel1.Controls.Add(this.panel16);
            this.panel1.Controls.Add(this.panel17);
            this.panel1.Controls.Add(this.panel15);
            this.panel1.Controls.Add(this.panel14);
            this.panel1.Controls.Add(this.panel10);
            this.panel1.Controls.Add(this.panel9);
            this.panel1.Controls.Add(this.panel11);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel12);
            this.panel1.Controls.Add(this.panel13);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(1, 106);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(758, 349);
            this.panel1.TabIndex = 137;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel16.Controls.Add(this.flatLabel15);
            this.panel16.Controls.Add(this.tglShin);
            this.panel16.Location = new System.Drawing.Point(384, 556);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(350, 73);
            this.panel16.TabIndex = 49;
            // 
            // flatLabel15
            // 
            this.flatLabel15.AutoSize = true;
            this.flatLabel15.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel15.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel15.ForeColor = System.Drawing.Color.White;
            this.flatLabel15.Location = new System.Drawing.Point(13, 24);
            this.flatLabel15.Name = "flatLabel15";
            this.flatLabel15.Size = new System.Drawing.Size(148, 20);
            this.flatLabel15.TabIndex = 2;
            this.flatLabel15.Text = "Infinite Shin Talisman";
            // 
            // tglShin
            // 
            this.tglShin.BackColor = System.Drawing.Color.Transparent;
            this.tglShin.Checked = false;
            this.tglShin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglShin.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglShin.Location = new System.Drawing.Point(270, 20);
            this.tglShin.Name = "tglShin";
            this.tglShin.Options = theme.FlatToggle._Options.Style3;
            this.tglShin.Size = new System.Drawing.Size(76, 33);
            this.tglShin.TabIndex = 5;
            this.tglShin.Text = "flatToggle3";
            this.tglShin.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglShin_CheckedChanged);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel17.Controls.Add(this.flatLabel16);
            this.panel17.Controls.Add(this.tglSouther);
            this.panel17.Location = new System.Drawing.Point(3, 635);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(375, 73);
            this.panel17.TabIndex = 48;
            // 
            // flatLabel16
            // 
            this.flatLabel16.AutoSize = true;
            this.flatLabel16.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel16.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel16.ForeColor = System.Drawing.Color.White;
            this.flatLabel16.Location = new System.Drawing.Point(13, 24);
            this.flatLabel16.Name = "flatLabel16";
            this.flatLabel16.Size = new System.Drawing.Size(142, 20);
            this.flatLabel16.TabIndex = 2;
            this.flatLabel16.Text = "Inf Souther Talisman";
            // 
            // tglSouther
            // 
            this.tglSouther.BackColor = System.Drawing.Color.Transparent;
            this.tglSouther.Checked = false;
            this.tglSouther.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglSouther.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglSouther.Location = new System.Drawing.Point(296, 20);
            this.tglSouther.Name = "tglSouther";
            this.tglSouther.Options = theme.FlatToggle._Options.Style3;
            this.tglSouther.Size = new System.Drawing.Size(76, 33);
            this.tglSouther.TabIndex = 5;
            this.tglSouther.Text = "flatToggle4";
            this.tglSouther.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglSouther_CheckedChanged);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel15.Controls.Add(this.flatLabel14);
            this.panel15.Controls.Add(this.tglRei);
            this.panel15.Location = new System.Drawing.Point(384, 477);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(350, 73);
            this.panel15.TabIndex = 47;
            // 
            // flatLabel14
            // 
            this.flatLabel14.AutoSize = true;
            this.flatLabel14.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel14.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel14.ForeColor = System.Drawing.Color.White;
            this.flatLabel14.Location = new System.Drawing.Point(13, 24);
            this.flatLabel14.Name = "flatLabel14";
            this.flatLabel14.Size = new System.Drawing.Size(141, 20);
            this.flatLabel14.TabIndex = 2;
            this.flatLabel14.Text = "Infinite Rei Talisman";
            // 
            // tglRei
            // 
            this.tglRei.BackColor = System.Drawing.Color.Transparent;
            this.tglRei.Checked = false;
            this.tglRei.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglRei.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglRei.Location = new System.Drawing.Point(270, 20);
            this.tglRei.Name = "tglRei";
            this.tglRei.Options = theme.FlatToggle._Options.Style3;
            this.tglRei.Size = new System.Drawing.Size(76, 33);
            this.tglRei.TabIndex = 5;
            this.tglRei.Text = "flatToggle2";
            this.tglRei.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglRei_CheckedChanged);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel14.Controls.Add(this.flatLabel13);
            this.panel14.Controls.Add(this.tglToki);
            this.panel14.Location = new System.Drawing.Point(3, 556);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(375, 73);
            this.panel14.TabIndex = 46;
            // 
            // flatLabel13
            // 
            this.flatLabel13.AutoSize = true;
            this.flatLabel13.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel13.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel13.ForeColor = System.Drawing.Color.White;
            this.flatLabel13.Location = new System.Drawing.Point(13, 24);
            this.flatLabel13.Name = "flatLabel13";
            this.flatLabel13.Size = new System.Drawing.Size(147, 20);
            this.flatLabel13.TabIndex = 2;
            this.flatLabel13.Text = "Infinite Toki Talisman";
            // 
            // tglToki
            // 
            this.tglToki.BackColor = System.Drawing.Color.Transparent;
            this.tglToki.Checked = false;
            this.tglToki.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglToki.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglToki.Location = new System.Drawing.Point(296, 20);
            this.tglToki.Name = "tglToki";
            this.tglToki.Options = theme.FlatToggle._Options.Style3;
            this.tglToki.Size = new System.Drawing.Size(76, 33);
            this.tglToki.TabIndex = 5;
            this.tglToki.Text = "flatToggle1";
            this.tglToki.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglToki_CheckedChanged);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel10.Controls.Add(this.numBPCarMoney);
            this.panel10.Controls.Add(this.btnBPCarMoney);
            this.panel10.Controls.Add(this.flatLabel9);
            this.panel10.Location = new System.Drawing.Point(384, 398);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(350, 73);
            this.panel10.TabIndex = 50;
            // 
            // numBPCarMoney
            // 
            this.numBPCarMoney.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numBPCarMoney.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numBPCarMoney.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numBPCarMoney.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numBPCarMoney.ForeColor = System.Drawing.Color.White;
            this.numBPCarMoney.Location = new System.Drawing.Point(95, 22);
            this.numBPCarMoney.Maximum = ((long)(9999999));
            this.numBPCarMoney.Minimum = ((long)(0));
            this.numBPCarMoney.Name = "numBPCarMoney";
            this.numBPCarMoney.Size = new System.Drawing.Size(136, 30);
            this.numBPCarMoney.TabIndex = 11;
            this.numBPCarMoney.Text = "flatNumeric3";
            this.numBPCarMoney.Value = ((long)(0));
            // 
            // btnBPCarMoney
            // 
            this.btnBPCarMoney.BackColor = System.Drawing.Color.Transparent;
            this.btnBPCarMoney.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnBPCarMoney.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBPCarMoney.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnBPCarMoney.Location = new System.Drawing.Point(237, 15);
            this.btnBPCarMoney.Name = "btnBPCarMoney";
            this.btnBPCarMoney.Rounded = false;
            this.btnBPCarMoney.Size = new System.Drawing.Size(109, 44);
            this.btnBPCarMoney.TabIndex = 10;
            this.btnBPCarMoney.Text = "Set";
            this.btnBPCarMoney.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnBPCarMoney.Click += new System.EventHandler(this.btnBPCarMoney_Click);
            // 
            // flatLabel9
            // 
            this.flatLabel9.AutoSize = true;
            this.flatLabel9.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel9.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel9.ForeColor = System.Drawing.Color.White;
            this.flatLabel9.Location = new System.Drawing.Point(13, 19);
            this.flatLabel9.Name = "flatLabel9";
            this.flatLabel9.Size = new System.Drawing.Size(54, 40);
            this.flatLabel9.TabIndex = 2;
            this.flatLabel9.Text = "BP Car\r\nMoney";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel9.Controls.Add(this.btnBlue);
            this.panel9.Controls.Add(this.flatLabel8);
            this.panel9.Location = new System.Drawing.Point(384, 240);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(350, 73);
            this.panel9.TabIndex = 47;
            // 
            // btnBlue
            // 
            this.btnBlue.BackColor = System.Drawing.Color.Transparent;
            this.btnBlue.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnBlue.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBlue.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnBlue.Location = new System.Drawing.Point(237, 15);
            this.btnBlue.Name = "btnBlue";
            this.btnBlue.Rounded = false;
            this.btnBlue.Size = new System.Drawing.Size(109, 44);
            this.btnBlue.TabIndex = 10;
            this.btnBlue.Text = "Set";
            this.btnBlue.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnBlue.Click += new System.EventHandler(this.btnBlue_Click);
            // 
            // flatLabel8
            // 
            this.flatLabel8.AutoSize = true;
            this.flatLabel8.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel8.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel8.ForeColor = System.Drawing.Color.White;
            this.flatLabel8.Location = new System.Drawing.Point(13, 24);
            this.flatLabel8.Name = "flatLabel8";
            this.flatLabel8.Size = new System.Drawing.Size(113, 20);
            this.flatLabel8.TabIndex = 2;
            this.flatLabel8.Text = "Max Blue Points";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel11.Controls.Add(this.numMoney);
            this.panel11.Controls.Add(this.btnMoney);
            this.panel11.Controls.Add(this.flatLabel10);
            this.panel11.Location = new System.Drawing.Point(3, 477);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(375, 73);
            this.panel11.TabIndex = 53;
            // 
            // numMoney
            // 
            this.numMoney.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numMoney.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numMoney.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numMoney.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numMoney.ForeColor = System.Drawing.Color.White;
            this.numMoney.Location = new System.Drawing.Point(121, 22);
            this.numMoney.Maximum = ((long)(9999999));
            this.numMoney.Minimum = ((long)(0));
            this.numMoney.Name = "numMoney";
            this.numMoney.Size = new System.Drawing.Size(136, 30);
            this.numMoney.TabIndex = 10;
            this.numMoney.Text = "flatNumeric2";
            this.numMoney.Value = ((long)(0));
            // 
            // btnMoney
            // 
            this.btnMoney.BackColor = System.Drawing.Color.Transparent;
            this.btnMoney.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnMoney.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMoney.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnMoney.Location = new System.Drawing.Point(263, 15);
            this.btnMoney.Name = "btnMoney";
            this.btnMoney.Rounded = false;
            this.btnMoney.Size = new System.Drawing.Size(109, 44);
            this.btnMoney.TabIndex = 9;
            this.btnMoney.Text = "Set";
            this.btnMoney.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnMoney.Click += new System.EventHandler(this.btnMoney_Click);
            // 
            // flatLabel10
            // 
            this.flatLabel10.AutoSize = true;
            this.flatLabel10.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel10.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel10.ForeColor = System.Drawing.Color.White;
            this.flatLabel10.Location = new System.Drawing.Point(13, 24);
            this.flatLabel10.Name = "flatLabel10";
            this.flatLabel10.Size = new System.Drawing.Size(54, 20);
            this.flatLabel10.TabIndex = 2;
            this.flatLabel10.Text = "Money";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel8.Controls.Add(this.btnOrange);
            this.panel8.Controls.Add(this.flatLabel7);
            this.panel8.Location = new System.Drawing.Point(3, 319);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(375, 73);
            this.panel8.TabIndex = 49;
            // 
            // btnOrange
            // 
            this.btnOrange.BackColor = System.Drawing.Color.Transparent;
            this.btnOrange.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnOrange.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOrange.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnOrange.Location = new System.Drawing.Point(263, 15);
            this.btnOrange.Name = "btnOrange";
            this.btnOrange.Rounded = false;
            this.btnOrange.Size = new System.Drawing.Size(109, 44);
            this.btnOrange.TabIndex = 9;
            this.btnOrange.Text = "Set";
            this.btnOrange.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnOrange.Click += new System.EventHandler(this.btnOrange_Click);
            // 
            // flatLabel7
            // 
            this.flatLabel7.AutoSize = true;
            this.flatLabel7.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel7.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel7.ForeColor = System.Drawing.Color.White;
            this.flatLabel7.Location = new System.Drawing.Point(13, 24);
            this.flatLabel7.Name = "flatLabel7";
            this.flatLabel7.Size = new System.Drawing.Size(133, 20);
            this.flatLabel7.TabIndex = 2;
            this.flatLabel7.Text = "Max Orange Points";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel12.Controls.Add(this.numArena);
            this.panel12.Controls.Add(this.btnArena);
            this.panel12.Controls.Add(this.flatLabel11);
            this.panel12.Location = new System.Drawing.Point(384, 319);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(350, 73);
            this.panel12.TabIndex = 52;
            // 
            // numArena
            // 
            this.numArena.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numArena.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numArena.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numArena.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numArena.ForeColor = System.Drawing.Color.White;
            this.numArena.Location = new System.Drawing.Point(95, 21);
            this.numArena.Maximum = ((long)(9999999));
            this.numArena.Minimum = ((long)(0));
            this.numArena.Name = "numArena";
            this.numArena.Size = new System.Drawing.Size(136, 30);
            this.numArena.TabIndex = 12;
            this.numArena.Text = "flatNumeric4";
            this.numArena.Value = ((long)(0));
            // 
            // btnArena
            // 
            this.btnArena.BackColor = System.Drawing.Color.Transparent;
            this.btnArena.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnArena.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnArena.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnArena.Location = new System.Drawing.Point(237, 14);
            this.btnArena.Name = "btnArena";
            this.btnArena.Rounded = false;
            this.btnArena.Size = new System.Drawing.Size(109, 44);
            this.btnArena.TabIndex = 7;
            this.btnArena.Text = "Set";
            this.btnArena.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnArena.Click += new System.EventHandler(this.btnArena_Click);
            // 
            // flatLabel11
            // 
            this.flatLabel11.AutoSize = true;
            this.flatLabel11.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel11.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel11.ForeColor = System.Drawing.Color.White;
            this.flatLabel11.Location = new System.Drawing.Point(13, 18);
            this.flatLabel11.Name = "flatLabel11";
            this.flatLabel11.Size = new System.Drawing.Size(48, 40);
            this.flatLabel11.TabIndex = 2;
            this.flatLabel11.Text = "Arena\r\nPoints";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel13.Controls.Add(this.numPoker);
            this.panel13.Controls.Add(this.btnPoker);
            this.panel13.Controls.Add(this.flatLabel12);
            this.panel13.Location = new System.Drawing.Point(3, 398);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(375, 73);
            this.panel13.TabIndex = 51;
            // 
            // numPoker
            // 
            this.numPoker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numPoker.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numPoker.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numPoker.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numPoker.ForeColor = System.Drawing.Color.White;
            this.numPoker.Location = new System.Drawing.Point(122, 21);
            this.numPoker.Maximum = ((long)(9999999));
            this.numPoker.Minimum = ((long)(0));
            this.numPoker.Name = "numPoker";
            this.numPoker.Size = new System.Drawing.Size(136, 30);
            this.numPoker.TabIndex = 9;
            this.numPoker.Text = "flatNumeric1";
            this.numPoker.Value = ((long)(0));
            // 
            // btnPoker
            // 
            this.btnPoker.BackColor = System.Drawing.Color.Transparent;
            this.btnPoker.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnPoker.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPoker.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnPoker.Location = new System.Drawing.Point(263, 14);
            this.btnPoker.Name = "btnPoker";
            this.btnPoker.Rounded = false;
            this.btnPoker.Size = new System.Drawing.Size(109, 44);
            this.btnPoker.TabIndex = 8;
            this.btnPoker.Text = "Set";
            this.btnPoker.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnPoker.Click += new System.EventHandler(this.btnPoker_Click);
            // 
            // flatLabel12
            // 
            this.flatLabel12.AutoSize = true;
            this.flatLabel12.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel12.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel12.ForeColor = System.Drawing.Color.White;
            this.flatLabel12.Location = new System.Drawing.Point(13, 24);
            this.flatLabel12.Name = "flatLabel12";
            this.flatLabel12.Size = new System.Drawing.Size(89, 20);
            this.flatLabel12.TabIndex = 2;
            this.flatLabel12.Text = "Poker Fiches";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel7.Controls.Add(this.btnYellow);
            this.panel7.Controls.Add(this.flatLabel6);
            this.panel7.Location = new System.Drawing.Point(384, 161);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(350, 73);
            this.panel7.TabIndex = 48;
            // 
            // btnYellow
            // 
            this.btnYellow.BackColor = System.Drawing.Color.Transparent;
            this.btnYellow.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnYellow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnYellow.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnYellow.Location = new System.Drawing.Point(237, 14);
            this.btnYellow.Name = "btnYellow";
            this.btnYellow.Rounded = false;
            this.btnYellow.Size = new System.Drawing.Size(109, 44);
            this.btnYellow.TabIndex = 7;
            this.btnYellow.Text = "Set";
            this.btnYellow.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnYellow.Click += new System.EventHandler(this.btnYellow_Click);
            // 
            // flatLabel6
            // 
            this.flatLabel6.AutoSize = true;
            this.flatLabel6.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel6.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel6.ForeColor = System.Drawing.Color.White;
            this.flatLabel6.Location = new System.Drawing.Point(13, 24);
            this.flatLabel6.Name = "flatLabel6";
            this.flatLabel6.Size = new System.Drawing.Size(127, 20);
            this.flatLabel6.TabIndex = 2;
            this.flatLabel6.Text = "Max Yellow Points";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel5.Controls.Add(this.btnGrey);
            this.panel5.Controls.Add(this.flatLabel4);
            this.panel5.Location = new System.Drawing.Point(384, 82);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(350, 73);
            this.panel5.TabIndex = 47;
            // 
            // btnGrey
            // 
            this.btnGrey.BackColor = System.Drawing.Color.Transparent;
            this.btnGrey.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnGrey.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGrey.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnGrey.Location = new System.Drawing.Point(237, 15);
            this.btnGrey.Name = "btnGrey";
            this.btnGrey.Rounded = false;
            this.btnGrey.Size = new System.Drawing.Size(109, 44);
            this.btnGrey.TabIndex = 6;
            this.btnGrey.Text = "Set";
            this.btnGrey.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnGrey.Click += new System.EventHandler(this.btnGrey_Click);
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(13, 24);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(114, 20);
            this.flatLabel4.TabIndex = 2;
            this.flatLabel4.Text = "Max Grey Points";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel4.Controls.Add(this.btnGreen);
            this.panel4.Controls.Add(this.flatLabel2);
            this.panel4.Location = new System.Drawing.Point(3, 240);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(375, 73);
            this.panel4.TabIndex = 47;
            // 
            // btnGreen
            // 
            this.btnGreen.BackColor = System.Drawing.Color.Transparent;
            this.btnGreen.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnGreen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGreen.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnGreen.Location = new System.Drawing.Point(263, 14);
            this.btnGreen.Name = "btnGreen";
            this.btnGreen.Rounded = false;
            this.btnGreen.Size = new System.Drawing.Size(109, 44);
            this.btnGreen.TabIndex = 8;
            this.btnGreen.Text = "Set";
            this.btnGreen.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnGreen.Click += new System.EventHandler(this.btnGreen_Click);
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(13, 24);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(123, 20);
            this.flatLabel2.TabIndex = 2;
            this.flatLabel2.Text = "Max Green Points";
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(351, 72);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 138;
            this.pictureBox2.TabStop = false;
            // 
            // tmrHealth
            // 
            this.tmrHealth.Interval = 500;
            this.tmrHealth.Tick += new System.EventHandler(this.tmrHealth_Tick);
            // 
            // tmrToki
            // 
            this.tmrToki.Interval = 500;
            this.tmrToki.Tick += new System.EventHandler(this.tmrToki_Tick);
            // 
            // tmrRei
            // 
            this.tmrRei.Interval = 500;
            this.tmrRei.Tick += new System.EventHandler(this.tmrRei_Tick);
            // 
            // tmrSouther
            // 
            this.tmrSouther.Interval = 500;
            this.tmrSouther.Tick += new System.EventHandler(this.tmrSouther_Tick);
            // 
            // tmrShin
            // 
            this.tmrShin.Interval = 500;
            this.tmrShin.Tick += new System.EventHandler(this.tmrShin_Tick);
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel18.Controls.Add(this.flatLabel17);
            this.panel18.Controls.Add(this.tglVehicle);
            this.panel18.Location = new System.Drawing.Point(3, 82);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(375, 73);
            this.panel18.TabIndex = 46;
            // 
            // flatLabel17
            // 
            this.flatLabel17.AutoSize = true;
            this.flatLabel17.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel17.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel17.ForeColor = System.Drawing.Color.White;
            this.flatLabel17.Location = new System.Drawing.Point(13, 24);
            this.flatLabel17.Name = "flatLabel17";
            this.flatLabel17.Size = new System.Drawing.Size(202, 20);
            this.flatLabel17.TabIndex = 2;
            this.flatLabel17.Text = "Inf Vehicle Boost + Durability";
            // 
            // tglVehicle
            // 
            this.tglVehicle.BackColor = System.Drawing.Color.Transparent;
            this.tglVehicle.Checked = false;
            this.tglVehicle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglVehicle.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglVehicle.Location = new System.Drawing.Point(296, 20);
            this.tglVehicle.Name = "tglVehicle";
            this.tglVehicle.Options = theme.FlatToggle._Options.Style3;
            this.tglVehicle.Size = new System.Drawing.Size(76, 33);
            this.tglVehicle.TabIndex = 5;
            this.tglVehicle.Text = "flatToggle1";
            this.tglVehicle.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglVehicle_CheckedChanged);
            // 
            // tmrVehicle
            // 
            this.tmrVehicle.Interval = 500;
            this.tmrVehicle.Tick += new System.EventHandler(this.tmrVehicle_Tick);
            // 
            // HokutoGaGotoku
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.btnAttach);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox2);
            this.Name = "HokutoGaGotoku";
            this.Size = new System.Drawing.Size(758, 455);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private theme.FlatButton btnAttach;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel6;
        private theme.FlatLabel flatLabel5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private theme.FlatButton btnMaxLevel;
        private theme.FlatLabel flatLabel1;
        private System.Windows.Forms.Label label4;
        private theme.FlatLabel flatLabel3;
        private theme.FlatToggle tglHealth;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Timer tmrHealth;
        private System.Windows.Forms.Panel panel9;
        private theme.FlatLabel flatLabel8;
        private System.Windows.Forms.Panel panel8;
        private theme.FlatLabel flatLabel7;
        private System.Windows.Forms.Panel panel7;
        private theme.FlatLabel flatLabel6;
        private System.Windows.Forms.Panel panel5;
        private theme.FlatLabel flatLabel4;
        private System.Windows.Forms.Panel panel4;
        private theme.FlatLabel flatLabel2;
        private theme.FlatButton btnAura;
        private theme.FlatButton btnBlue;
        private theme.FlatButton btnOrange;
        private theme.FlatButton btnYellow;
        private theme.FlatButton btnGrey;
        private theme.FlatButton btnGreen;
        private System.Windows.Forms.Panel panel10;
        private theme.FlatNumeric numBPCarMoney;
        private theme.FlatButton btnBPCarMoney;
        private theme.FlatLabel flatLabel9;
        private System.Windows.Forms.Panel panel11;
        private theme.FlatNumeric numMoney;
        private theme.FlatButton btnMoney;
        private theme.FlatLabel flatLabel10;
        private System.Windows.Forms.Panel panel12;
        private theme.FlatNumeric numArena;
        private theme.FlatButton btnArena;
        private theme.FlatLabel flatLabel11;
        private System.Windows.Forms.Panel panel13;
        private theme.FlatNumeric numPoker;
        private theme.FlatButton btnPoker;
        private theme.FlatLabel flatLabel12;
        private System.Windows.Forms.Panel panel16;
        private theme.FlatLabel flatLabel15;
        private theme.FlatToggle tglShin;
        private System.Windows.Forms.Panel panel17;
        private theme.FlatLabel flatLabel16;
        private theme.FlatToggle tglSouther;
        private System.Windows.Forms.Panel panel15;
        private theme.FlatLabel flatLabel14;
        private theme.FlatToggle tglRei;
        private System.Windows.Forms.Panel panel14;
        private theme.FlatLabel flatLabel13;
        private theme.FlatToggle tglToki;
        private System.Windows.Forms.Timer tmrToki;
        private System.Windows.Forms.Timer tmrRei;
        private System.Windows.Forms.Timer tmrSouther;
        private System.Windows.Forms.Timer tmrShin;
        private System.Windows.Forms.Panel panel18;
        private theme.FlatLabel flatLabel17;
        private theme.FlatToggle tglVehicle;
        private System.Windows.Forms.Timer tmrVehicle;
    }
}

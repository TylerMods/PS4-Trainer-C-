﻿namespace PS4_Trainer_by_TylerMods.Game_Trainers
{
    partial class RE7
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RE7));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCUSA = new System.Windows.Forms.Label();
            this.btnAttach = new theme.FlatButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnl2xItems = new System.Windows.Forms.Panel();
            this.tgl2xItems = new theme.FlatToggle();
            this.flatLabel1 = new theme.FlatLabel();
            this.pnlItems106 = new System.Windows.Forms.Panel();
            this.tglItems106 = new theme.FlatToggle();
            this.flatLabel7 = new theme.FlatLabel();
            this.pnlAmmo106 = new System.Windows.Forms.Panel();
            this.tglAmmo106 = new theme.FlatToggle();
            this.flatLabel8 = new theme.FlatLabel();
            this.pnlItems100 = new System.Windows.Forms.Panel();
            this.tglItems = new theme.FlatToggle();
            this.flatLabel2 = new theme.FlatLabel();
            this.pnlHealth100 = new System.Windows.Forms.Panel();
            this.tglHealth = new theme.FlatToggle();
            this.flatLabel6 = new theme.FlatLabel();
            this.cmbVersion = new theme.FlatComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnl2xItems.SuspendLayout();
            this.pnlItems106.SuspendLayout();
            this.pnlAmmo106.SuspendLayout();
            this.pnlItems100.SuspendLayout();
            this.pnlHealth100.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(518, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 99);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 91;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(351, 72);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 96;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label4.Location = new System.Drawing.Point(3, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(278, 28);
            this.label4.TabIndex = 94;
            this.label4.Text = "Cheater : Cain532 + Talixme";
            // 
            // lblCUSA
            // 
            this.lblCUSA.AutoSize = true;
            this.lblCUSA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.lblCUSA.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCUSA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.lblCUSA.Location = new System.Drawing.Point(389, 47);
            this.lblCUSA.Name = "lblCUSA";
            this.lblCUSA.Size = new System.Drawing.Size(123, 28);
            this.lblCUSA.TabIndex = 93;
            this.lblCUSA.Text = "CUSA03842";
            // 
            // btnAttach
            // 
            this.btnAttach.BackColor = System.Drawing.Color.Transparent;
            this.btnAttach.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAttach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAttach.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAttach.Location = new System.Drawing.Point(394, 3);
            this.btnAttach.Name = "btnAttach";
            this.btnAttach.Rounded = false;
            this.btnAttach.Size = new System.Drawing.Size(118, 44);
            this.btnAttach.TabIndex = 97;
            this.btnAttach.Text = "Attach";
            this.btnAttach.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAttach.Click += new System.EventHandler(this.btnAttach_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.panel1.Controls.Add(this.pnl2xItems);
            this.panel1.Controls.Add(this.pnlItems106);
            this.panel1.Controls.Add(this.pnlAmmo106);
            this.panel1.Controls.Add(this.pnlItems100);
            this.panel1.Controls.Add(this.pnlHealth100);
            this.panel1.Location = new System.Drawing.Point(0, 106);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(758, 349);
            this.panel1.TabIndex = 95;
            // 
            // pnl2xItems
            // 
            this.pnl2xItems.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnl2xItems.Controls.Add(this.tgl2xItems);
            this.pnl2xItems.Controls.Add(this.flatLabel1);
            this.pnl2xItems.Location = new System.Drawing.Point(3, 161);
            this.pnl2xItems.Name = "pnl2xItems";
            this.pnl2xItems.Size = new System.Drawing.Size(375, 73);
            this.pnl2xItems.TabIndex = 49;
            // 
            // tgl2xItems
            // 
            this.tgl2xItems.BackColor = System.Drawing.Color.Transparent;
            this.tgl2xItems.Checked = false;
            this.tgl2xItems.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tgl2xItems.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tgl2xItems.Location = new System.Drawing.Point(296, 19);
            this.tgl2xItems.Name = "tgl2xItems";
            this.tgl2xItems.Options = theme.FlatToggle._Options.Style3;
            this.tgl2xItems.Size = new System.Drawing.Size(76, 33);
            this.tgl2xItems.TabIndex = 4;
            this.tgl2xItems.Text = "flatToggle1";
            this.tgl2xItems.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tgl2xItems_CheckedChanged);
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(13, 25);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(64, 20);
            this.flatLabel1.TabIndex = 2;
            this.flatLabel1.Text = "x2 Items";
            // 
            // pnlItems106
            // 
            this.pnlItems106.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlItems106.Controls.Add(this.tglItems106);
            this.pnlItems106.Controls.Add(this.flatLabel7);
            this.pnlItems106.Location = new System.Drawing.Point(380, 82);
            this.pnlItems106.Name = "pnlItems106";
            this.pnlItems106.Size = new System.Drawing.Size(375, 73);
            this.pnlItems106.TabIndex = 49;
            // 
            // tglItems106
            // 
            this.tglItems106.BackColor = System.Drawing.Color.Transparent;
            this.tglItems106.Checked = false;
            this.tglItems106.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglItems106.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglItems106.Location = new System.Drawing.Point(296, 19);
            this.tglItems106.Name = "tglItems106";
            this.tglItems106.Options = theme.FlatToggle._Options.Style3;
            this.tglItems106.Size = new System.Drawing.Size(76, 33);
            this.tglItems106.TabIndex = 4;
            this.tglItems106.Text = "flatToggle1";
            this.tglItems106.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglItems106_CheckedChanged);
            // 
            // flatLabel7
            // 
            this.flatLabel7.AutoSize = true;
            this.flatLabel7.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel7.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel7.ForeColor = System.Drawing.Color.White;
            this.flatLabel7.Location = new System.Drawing.Point(13, 25);
            this.flatLabel7.Name = "flatLabel7";
            this.flatLabel7.Size = new System.Drawing.Size(95, 20);
            this.flatLabel7.TabIndex = 2;
            this.flatLabel7.Text = "Infinite Items";
            // 
            // pnlAmmo106
            // 
            this.pnlAmmo106.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlAmmo106.Controls.Add(this.tglAmmo106);
            this.pnlAmmo106.Controls.Add(this.flatLabel8);
            this.pnlAmmo106.Location = new System.Drawing.Point(3, 82);
            this.pnlAmmo106.Name = "pnlAmmo106";
            this.pnlAmmo106.Size = new System.Drawing.Size(375, 73);
            this.pnlAmmo106.TabIndex = 48;
            // 
            // tglAmmo106
            // 
            this.tglAmmo106.BackColor = System.Drawing.Color.Transparent;
            this.tglAmmo106.Checked = false;
            this.tglAmmo106.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglAmmo106.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglAmmo106.Location = new System.Drawing.Point(296, 19);
            this.tglAmmo106.Name = "tglAmmo106";
            this.tglAmmo106.Options = theme.FlatToggle._Options.Style3;
            this.tglAmmo106.Size = new System.Drawing.Size(76, 33);
            this.tglAmmo106.TabIndex = 4;
            this.tglAmmo106.Text = "flatToggle1";
            this.tglAmmo106.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglAmmo106_CheckedChanged);
            // 
            // flatLabel8
            // 
            this.flatLabel8.AutoSize = true;
            this.flatLabel8.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel8.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel8.ForeColor = System.Drawing.Color.White;
            this.flatLabel8.Location = new System.Drawing.Point(13, 25);
            this.flatLabel8.Name = "flatLabel8";
            this.flatLabel8.Size = new System.Drawing.Size(104, 20);
            this.flatLabel8.TabIndex = 2;
            this.flatLabel8.Text = "Infinite Ammo";
            // 
            // pnlItems100
            // 
            this.pnlItems100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlItems100.Controls.Add(this.tglItems);
            this.pnlItems100.Controls.Add(this.flatLabel2);
            this.pnlItems100.Location = new System.Drawing.Point(380, 3);
            this.pnlItems100.Name = "pnlItems100";
            this.pnlItems100.Size = new System.Drawing.Size(375, 73);
            this.pnlItems100.TabIndex = 47;
            // 
            // tglItems
            // 
            this.tglItems.BackColor = System.Drawing.Color.Transparent;
            this.tglItems.Checked = false;
            this.tglItems.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglItems.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglItems.Location = new System.Drawing.Point(296, 19);
            this.tglItems.Name = "tglItems";
            this.tglItems.Options = theme.FlatToggle._Options.Style3;
            this.tglItems.Size = new System.Drawing.Size(76, 33);
            this.tglItems.TabIndex = 4;
            this.tglItems.Text = "flatToggle1";
            this.tglItems.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglItems_CheckedChanged);
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(13, 25);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(95, 20);
            this.flatLabel2.TabIndex = 2;
            this.flatLabel2.Text = "Infinite Items";
            // 
            // pnlHealth100
            // 
            this.pnlHealth100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlHealth100.Controls.Add(this.tglHealth);
            this.pnlHealth100.Controls.Add(this.flatLabel6);
            this.pnlHealth100.Location = new System.Drawing.Point(3, 3);
            this.pnlHealth100.Name = "pnlHealth100";
            this.pnlHealth100.Size = new System.Drawing.Size(375, 73);
            this.pnlHealth100.TabIndex = 46;
            // 
            // tglHealth
            // 
            this.tglHealth.BackColor = System.Drawing.Color.Transparent;
            this.tglHealth.Checked = false;
            this.tglHealth.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglHealth.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglHealth.Location = new System.Drawing.Point(296, 19);
            this.tglHealth.Name = "tglHealth";
            this.tglHealth.Options = theme.FlatToggle._Options.Style3;
            this.tglHealth.Size = new System.Drawing.Size(76, 33);
            this.tglHealth.TabIndex = 4;
            this.tglHealth.Text = "flatToggle1";
            this.tglHealth.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglHealth_CheckedChanged);
            // 
            // flatLabel6
            // 
            this.flatLabel6.AutoSize = true;
            this.flatLabel6.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel6.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel6.ForeColor = System.Drawing.Color.White;
            this.flatLabel6.Location = new System.Drawing.Point(13, 25);
            this.flatLabel6.Name = "flatLabel6";
            this.flatLabel6.Size = new System.Drawing.Size(103, 20);
            this.flatLabel6.TabIndex = 2;
            this.flatLabel6.Text = "Infinite Health";
            // 
            // cmbVersion
            // 
            this.cmbVersion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.cmbVersion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbVersion.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVersion.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cmbVersion.ForeColor = System.Drawing.Color.White;
            this.cmbVersion.FormattingEnabled = true;
            this.cmbVersion.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.cmbVersion.ItemHeight = 18;
            this.cmbVersion.Items.AddRange(new object[] {
            "v1.00",
            "v1.06",
            "Gold Edition v1.00"});
            this.cmbVersion.Location = new System.Drawing.Point(380, 79);
            this.cmbVersion.Name = "cmbVersion";
            this.cmbVersion.Size = new System.Drawing.Size(132, 24);
            this.cmbVersion.TabIndex = 100;
            this.cmbVersion.SelectedIndexChanged += new System.EventHandler(this.cmbVersion_SelectedIndexChanged);
            // 
            // RE7
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.cmbVersion);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblCUSA);
            this.Controls.Add(this.btnAttach);
            this.Controls.Add(this.panel1);
            this.Name = "RE7";
            this.Size = new System.Drawing.Size(758, 455);
            this.Load += new System.EventHandler(this.RE7_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.pnl2xItems.ResumeLayout(false);
            this.pnl2xItems.PerformLayout();
            this.pnlItems106.ResumeLayout(false);
            this.pnlItems106.PerformLayout();
            this.pnlAmmo106.ResumeLayout(false);
            this.pnlAmmo106.PerformLayout();
            this.pnlItems100.ResumeLayout(false);
            this.pnlItems100.PerformLayout();
            this.pnlHealth100.ResumeLayout(false);
            this.pnlHealth100.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblCUSA;
        private theme.FlatButton btnAttach;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnlHealth100;
        private theme.FlatToggle tglHealth;
        private theme.FlatLabel flatLabel6;
        private System.Windows.Forms.Panel pnlItems100;
        private theme.FlatToggle tglItems;
        private theme.FlatLabel flatLabel2;
        private System.Windows.Forms.Panel pnlItems106;
        private theme.FlatToggle tglItems106;
        private theme.FlatLabel flatLabel7;
        private System.Windows.Forms.Panel pnlAmmo106;
        private theme.FlatToggle tglAmmo106;
        private theme.FlatLabel flatLabel8;
        private theme.FlatComboBox cmbVersion;
        private System.Windows.Forms.Panel pnl2xItems;
        private theme.FlatToggle tgl2xItems;
        private theme.FlatLabel flatLabel1;
    }
}

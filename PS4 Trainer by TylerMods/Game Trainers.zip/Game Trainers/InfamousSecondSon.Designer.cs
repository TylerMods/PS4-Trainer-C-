﻿namespace PS4_Trainer_by_TylerMods.Game_Trainers
{
    partial class InfamousSecondSon
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InfamousSecondSon));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlInfamous = new System.Windows.Forms.Panel();
            this.btnInfamous = new theme.FlatButton();
            this.flatLabel3 = new theme.FlatLabel();
            this.pnlHero = new System.Windows.Forms.Panel();
            this.btnHero = new theme.FlatButton();
            this.flatLabel5 = new theme.FlatLabel();
            this.pnlBombs = new System.Windows.Forms.Panel();
            this.tglBombs = new theme.FlatToggle();
            this.flatLabel1 = new theme.FlatLabel();
            this.pnlSP = new System.Windows.Forms.Panel();
            this.tglSP = new theme.FlatToggle();
            this.flatLabel2 = new theme.FlatLabel();
            this.pnlSmoke = new System.Windows.Forms.Panel();
            this.tglEnergy = new theme.FlatToggle();
            this.flatLabel4 = new theme.FlatLabel();
            this.pnlHealth = new System.Windows.Forms.Panel();
            this.tglHealth = new theme.FlatToggle();
            this.lblHealth = new theme.FlatLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnAttach = new theme.FlatButton();
            this.cmbVersion = new theme.FlatComboBox();
            this.panel1.SuspendLayout();
            this.pnlInfamous.SuspendLayout();
            this.pnlHero.SuspendLayout();
            this.pnlBombs.SuspendLayout();
            this.pnlSP.SuspendLayout();
            this.pnlSmoke.SuspendLayout();
            this.pnlHealth.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.panel1.Controls.Add(this.pnlInfamous);
            this.panel1.Controls.Add(this.pnlHero);
            this.panel1.Controls.Add(this.pnlBombs);
            this.panel1.Controls.Add(this.pnlSP);
            this.panel1.Controls.Add(this.pnlSmoke);
            this.panel1.Controls.Add(this.pnlHealth);
            this.panel1.Location = new System.Drawing.Point(1, 106);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(758, 349);
            this.panel1.TabIndex = 116;
            // 
            // pnlInfamous
            // 
            this.pnlInfamous.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlInfamous.Controls.Add(this.btnInfamous);
            this.pnlInfamous.Controls.Add(this.flatLabel3);
            this.pnlInfamous.Location = new System.Drawing.Point(381, 161);
            this.pnlInfamous.Name = "pnlInfamous";
            this.pnlInfamous.Size = new System.Drawing.Size(374, 73);
            this.pnlInfamous.TabIndex = 53;
            // 
            // btnInfamous
            // 
            this.btnInfamous.BackColor = System.Drawing.Color.Transparent;
            this.btnInfamous.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnInfamous.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInfamous.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnInfamous.Location = new System.Drawing.Point(271, 14);
            this.btnInfamous.Name = "btnInfamous";
            this.btnInfamous.Rounded = false;
            this.btnInfamous.Size = new System.Drawing.Size(100, 44);
            this.btnInfamous.TabIndex = 120;
            this.btnInfamous.Text = "Set";
            this.btnInfamous.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnInfamous.Click += new System.EventHandler(this.btnInfamous_Click);
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(13, 24);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(140, 20);
            this.flatLabel3.TabIndex = 2;
            this.flatLabel3.Text = "Max Level Infamous";
            // 
            // pnlHero
            // 
            this.pnlHero.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlHero.Controls.Add(this.btnHero);
            this.pnlHero.Controls.Add(this.flatLabel5);
            this.pnlHero.Location = new System.Drawing.Point(3, 161);
            this.pnlHero.Name = "pnlHero";
            this.pnlHero.Size = new System.Drawing.Size(375, 73);
            this.pnlHero.TabIndex = 54;
            // 
            // btnHero
            // 
            this.btnHero.BackColor = System.Drawing.Color.Transparent;
            this.btnHero.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnHero.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHero.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnHero.Location = new System.Drawing.Point(272, 14);
            this.btnHero.Name = "btnHero";
            this.btnHero.Rounded = false;
            this.btnHero.Size = new System.Drawing.Size(100, 44);
            this.btnHero.TabIndex = 119;
            this.btnHero.Text = "Set";
            this.btnHero.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnHero.Click += new System.EventHandler(this.btnHero_Click);
            // 
            // flatLabel5
            // 
            this.flatLabel5.AutoSize = true;
            this.flatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel5.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel5.ForeColor = System.Drawing.Color.White;
            this.flatLabel5.Location = new System.Drawing.Point(13, 24);
            this.flatLabel5.Name = "flatLabel5";
            this.flatLabel5.Size = new System.Drawing.Size(144, 20);
            this.flatLabel5.TabIndex = 2;
            this.flatLabel5.Text = "Max Level True Hero";
            // 
            // pnlBombs
            // 
            this.pnlBombs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlBombs.Controls.Add(this.tglBombs);
            this.pnlBombs.Controls.Add(this.flatLabel1);
            this.pnlBombs.Location = new System.Drawing.Point(381, 82);
            this.pnlBombs.Name = "pnlBombs";
            this.pnlBombs.Size = new System.Drawing.Size(374, 73);
            this.pnlBombs.TabIndex = 51;
            // 
            // tglBombs
            // 
            this.tglBombs.BackColor = System.Drawing.Color.Transparent;
            this.tglBombs.Checked = false;
            this.tglBombs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglBombs.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglBombs.Location = new System.Drawing.Point(295, 19);
            this.tglBombs.Name = "tglBombs";
            this.tglBombs.Options = theme.FlatToggle._Options.Style3;
            this.tglBombs.Size = new System.Drawing.Size(76, 33);
            this.tglBombs.TabIndex = 6;
            this.tglBombs.Text = "flatToggle1";
            this.tglBombs.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglBombs_CheckedChanged);
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(13, 24);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(170, 20);
            this.flatLabel1.TabIndex = 2;
            this.flatLabel1.Text = "Infinite Bombs / Rockets";
            // 
            // pnlSP
            // 
            this.pnlSP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlSP.Controls.Add(this.tglSP);
            this.pnlSP.Controls.Add(this.flatLabel2);
            this.pnlSP.Location = new System.Drawing.Point(3, 82);
            this.pnlSP.Name = "pnlSP";
            this.pnlSP.Size = new System.Drawing.Size(375, 73);
            this.pnlSP.TabIndex = 52;
            // 
            // tglSP
            // 
            this.tglSP.BackColor = System.Drawing.Color.Transparent;
            this.tglSP.Checked = false;
            this.tglSP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglSP.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglSP.Location = new System.Drawing.Point(287, 19);
            this.tglSP.Name = "tglSP";
            this.tglSP.Options = theme.FlatToggle._Options.Style3;
            this.tglSP.Size = new System.Drawing.Size(76, 33);
            this.tglSP.TabIndex = 5;
            this.tglSP.Text = "flatToggle1";
            this.tglSP.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglSP_CheckedChanged);
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(13, 24);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(185, 20);
            this.flatLabel2.TabIndex = 2;
            this.flatLabel2.Text = "Infinite Skillpoints / Shards";
            // 
            // pnlSmoke
            // 
            this.pnlSmoke.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlSmoke.Controls.Add(this.tglEnergy);
            this.pnlSmoke.Controls.Add(this.flatLabel4);
            this.pnlSmoke.Location = new System.Drawing.Point(381, 3);
            this.pnlSmoke.Name = "pnlSmoke";
            this.pnlSmoke.Size = new System.Drawing.Size(374, 73);
            this.pnlSmoke.TabIndex = 49;
            // 
            // tglEnergy
            // 
            this.tglEnergy.BackColor = System.Drawing.Color.Transparent;
            this.tglEnergy.Checked = false;
            this.tglEnergy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglEnergy.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglEnergy.Location = new System.Drawing.Point(295, 19);
            this.tglEnergy.Name = "tglEnergy";
            this.tglEnergy.Options = theme.FlatToggle._Options.Style3;
            this.tglEnergy.Size = new System.Drawing.Size(76, 33);
            this.tglEnergy.TabIndex = 6;
            this.tglEnergy.Text = "flatToggle1";
            this.tglEnergy.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglEnergy_CheckedChanged);
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(13, 24);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(104, 20);
            this.flatLabel4.TabIndex = 2;
            this.flatLabel4.Text = "Infinite Smoke";
            // 
            // pnlHealth
            // 
            this.pnlHealth.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlHealth.Controls.Add(this.tglHealth);
            this.pnlHealth.Controls.Add(this.lblHealth);
            this.pnlHealth.Location = new System.Drawing.Point(3, 3);
            this.pnlHealth.Name = "pnlHealth";
            this.pnlHealth.Size = new System.Drawing.Size(375, 73);
            this.pnlHealth.TabIndex = 50;
            // 
            // tglHealth
            // 
            this.tglHealth.BackColor = System.Drawing.Color.Transparent;
            this.tglHealth.Checked = false;
            this.tglHealth.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglHealth.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglHealth.Location = new System.Drawing.Point(287, 19);
            this.tglHealth.Name = "tglHealth";
            this.tglHealth.Options = theme.FlatToggle._Options.Style3;
            this.tglHealth.Size = new System.Drawing.Size(76, 33);
            this.tglHealth.TabIndex = 5;
            this.tglHealth.Text = "flatToggle1";
            this.tglHealth.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglHealth_CheckedChanged_1);
            // 
            // lblHealth
            // 
            this.lblHealth.AutoSize = true;
            this.lblHealth.BackColor = System.Drawing.Color.Transparent;
            this.lblHealth.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblHealth.ForeColor = System.Drawing.Color.White;
            this.lblHealth.Location = new System.Drawing.Point(13, 24);
            this.lblHealth.Name = "lblHealth";
            this.lblHealth.Size = new System.Drawing.Size(103, 20);
            this.lblHealth.TabIndex = 2;
            this.lblHealth.Text = "Infinite Health";
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(351, 72);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 117;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label4.Location = new System.Drawing.Point(-1, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(276, 28);
            this.label4.TabIndex = 115;
            this.label4.Text = "Cheater : Weysincha + Belle";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label3.Location = new System.Drawing.Point(394, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 28);
            this.label3.TabIndex = 114;
            this.label3.Text = "CUSA00223";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(519, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 99);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 112;
            this.pictureBox1.TabStop = false;
            // 
            // btnAttach
            // 
            this.btnAttach.BackColor = System.Drawing.Color.Transparent;
            this.btnAttach.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAttach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAttach.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAttach.Location = new System.Drawing.Point(395, 3);
            this.btnAttach.Name = "btnAttach";
            this.btnAttach.Rounded = false;
            this.btnAttach.Size = new System.Drawing.Size(118, 44);
            this.btnAttach.TabIndex = 118;
            this.btnAttach.Text = "Attach";
            this.btnAttach.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAttach.Click += new System.EventHandler(this.btnAttach_Click);
            // 
            // cmbVersion
            // 
            this.cmbVersion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.cmbVersion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbVersion.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVersion.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cmbVersion.ForeColor = System.Drawing.Color.White;
            this.cmbVersion.FormattingEnabled = true;
            this.cmbVersion.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.cmbVersion.ItemHeight = 18;
            this.cmbVersion.Items.AddRange(new object[] {
            "v1.00",
            "v1.04"});
            this.cmbVersion.Location = new System.Drawing.Point(392, 79);
            this.cmbVersion.Name = "cmbVersion";
            this.cmbVersion.Size = new System.Drawing.Size(121, 24);
            this.cmbVersion.TabIndex = 102;
            this.cmbVersion.SelectedIndexChanged += new System.EventHandler(this.cmbVersion_SelectedIndexChanged);
            // 
            // InfamousSecondSon
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.cmbVersion);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnAttach);
            this.Name = "InfamousSecondSon";
            this.Size = new System.Drawing.Size(758, 455);
            this.Load += new System.EventHandler(this.InfamousSecondSon_Load);
            this.panel1.ResumeLayout(false);
            this.pnlInfamous.ResumeLayout(false);
            this.pnlInfamous.PerformLayout();
            this.pnlHero.ResumeLayout(false);
            this.pnlHero.PerformLayout();
            this.pnlBombs.ResumeLayout(false);
            this.pnlBombs.PerformLayout();
            this.pnlSP.ResumeLayout(false);
            this.pnlSP.PerformLayout();
            this.pnlSmoke.ResumeLayout(false);
            this.pnlSmoke.PerformLayout();
            this.pnlHealth.ResumeLayout(false);
            this.pnlHealth.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private theme.FlatButton btnAttach;
        private System.Windows.Forms.Panel pnlInfamous;
        private theme.FlatLabel flatLabel3;
        private System.Windows.Forms.Panel pnlHero;
        private theme.FlatLabel flatLabel5;
        private System.Windows.Forms.Panel pnlBombs;
        private theme.FlatToggle tglBombs;
        private theme.FlatLabel flatLabel1;
        private System.Windows.Forms.Panel pnlSP;
        private theme.FlatToggle tglSP;
        private theme.FlatLabel flatLabel2;
        private System.Windows.Forms.Panel pnlSmoke;
        private theme.FlatToggle tglEnergy;
        private theme.FlatLabel flatLabel4;
        private System.Windows.Forms.Panel pnlHealth;
        private theme.FlatToggle tglHealth;
        private theme.FlatLabel lblHealth;
        private theme.FlatButton btnInfamous;
        private theme.FlatButton btnHero;
        private theme.FlatComboBox cmbVersion;
    }
}

﻿namespace PS4_Trainer_by_TylerMods.Game_Trainers
{
    partial class DyingLightEE
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DyingLightEE));
            this.pnlFuel = new System.Windows.Forms.Panel();
            this.flatLabel13 = new theme.FlatLabel();
            this.tglFuel = new theme.FlatToggle();
            this.pnlNitrous = new System.Windows.Forms.Panel();
            this.flatLabel11 = new theme.FlatLabel();
            this.tglNitrous = new theme.FlatToggle();
            this.pnlVehicleUpgrade = new System.Windows.Forms.Panel();
            this.tglVehicleUpgrade = new theme.FlatToggle();
            this.flatLabel14 = new theme.FlatLabel();
            this.pnlWallHack = new System.Windows.Forms.Panel();
            this.flatLabel10 = new theme.FlatLabel();
            this.tglWallhack = new theme.FlatToggle();
            this.pnlUV = new System.Windows.Forms.Panel();
            this.tglUV = new theme.FlatToggle();
            this.flatLabel12 = new theme.FlatLabel();
            this.pnlScramble = new System.Windows.Forms.Panel();
            this.tglText = new theme.FlatToggle();
            this.flatLabel9 = new theme.FlatLabel();
            this.pnlWeather = new System.Windows.Forms.Panel();
            this.flatLabel8 = new theme.FlatLabel();
            this.tglWeather = new theme.FlatToggle();
            this.pnlGrappling = new System.Windows.Forms.Panel();
            this.tglGrappling = new theme.FlatToggle();
            this.flatLabel7 = new theme.FlatLabel();
            this.pnlNoItemDecrease = new System.Windows.Forms.Panel();
            this.flatLabel6 = new theme.FlatLabel();
            this.tglItems = new theme.FlatToggle();
            this.pnlAmmo = new System.Windows.Forms.Panel();
            this.flatToggle4 = new theme.FlatToggle();
            this.flatLabel5 = new theme.FlatLabel();
            this.pnlWeaponDur = new System.Windows.Forms.Panel();
            this.flatLabel2 = new theme.FlatLabel();
            this.flatToggle2 = new theme.FlatToggle();
            this.pnlHealth = new System.Windows.Forms.Panel();
            this.flatToggle3 = new theme.FlatToggle();
            this.flatLabel4 = new theme.FlatLabel();
            this.pnlBuyToEarn = new System.Windows.Forms.Panel();
            this.flatLabel1 = new theme.FlatLabel();
            this.tglHealth = new theme.FlatToggle();
            this.pnlSkills = new System.Windows.Forms.Panel();
            this.btnSkills = new theme.FlatButton();
            this.flatLabel3 = new theme.FlatLabel();
            this.btnAttach = new theme.FlatButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cmbVersion = new theme.FlatComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlFuel.SuspendLayout();
            this.pnlNitrous.SuspendLayout();
            this.pnlVehicleUpgrade.SuspendLayout();
            this.pnlWallHack.SuspendLayout();
            this.pnlUV.SuspendLayout();
            this.pnlScramble.SuspendLayout();
            this.pnlWeather.SuspendLayout();
            this.pnlGrappling.SuspendLayout();
            this.pnlNoItemDecrease.SuspendLayout();
            this.pnlAmmo.SuspendLayout();
            this.pnlWeaponDur.SuspendLayout();
            this.pnlHealth.SuspendLayout();
            this.pnlBuyToEarn.SuspendLayout();
            this.pnlSkills.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlFuel
            // 
            this.pnlFuel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlFuel.Controls.Add(this.flatLabel13);
            this.pnlFuel.Controls.Add(this.tglFuel);
            this.pnlFuel.Location = new System.Drawing.Point(381, 477);
            this.pnlFuel.Name = "pnlFuel";
            this.pnlFuel.Size = new System.Drawing.Size(359, 73);
            this.pnlFuel.TabIndex = 53;
            // 
            // flatLabel13
            // 
            this.flatLabel13.AutoSize = true;
            this.flatLabel13.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel13.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel13.ForeColor = System.Drawing.Color.White;
            this.flatLabel13.Location = new System.Drawing.Point(13, 24);
            this.flatLabel13.Name = "flatLabel13";
            this.flatLabel13.Size = new System.Drawing.Size(86, 20);
            this.flatLabel13.TabIndex = 2;
            this.flatLabel13.Text = "Infinite Fuel";
            // 
            // tglFuel
            // 
            this.tglFuel.BackColor = System.Drawing.Color.Transparent;
            this.tglFuel.Checked = false;
            this.tglFuel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglFuel.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglFuel.Location = new System.Drawing.Point(275, 20);
            this.tglFuel.Name = "tglFuel";
            this.tglFuel.Options = theme.FlatToggle._Options.Style3;
            this.tglFuel.Size = new System.Drawing.Size(76, 33);
            this.tglFuel.TabIndex = 5;
            this.tglFuel.Text = "flatToggle1";
            this.tglFuel.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglFuel_CheckedChanged);
            // 
            // pnlNitrous
            // 
            this.pnlNitrous.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlNitrous.Controls.Add(this.flatLabel11);
            this.pnlNitrous.Controls.Add(this.tglNitrous);
            this.pnlNitrous.Location = new System.Drawing.Point(381, 398);
            this.pnlNitrous.Name = "pnlNitrous";
            this.pnlNitrous.Size = new System.Drawing.Size(359, 73);
            this.pnlNitrous.TabIndex = 53;
            // 
            // flatLabel11
            // 
            this.flatLabel11.AutoSize = true;
            this.flatLabel11.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel11.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel11.ForeColor = System.Drawing.Color.White;
            this.flatLabel11.Location = new System.Drawing.Point(13, 24);
            this.flatLabel11.Name = "flatLabel11";
            this.flatLabel11.Size = new System.Drawing.Size(107, 20);
            this.flatLabel11.TabIndex = 2;
            this.flatLabel11.Text = "Infinite Nitrous";
            // 
            // tglNitrous
            // 
            this.tglNitrous.BackColor = System.Drawing.Color.Transparent;
            this.tglNitrous.Checked = false;
            this.tglNitrous.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglNitrous.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglNitrous.Location = new System.Drawing.Point(275, 20);
            this.tglNitrous.Name = "tglNitrous";
            this.tglNitrous.Options = theme.FlatToggle._Options.Style3;
            this.tglNitrous.Size = new System.Drawing.Size(76, 33);
            this.tglNitrous.TabIndex = 5;
            this.tglNitrous.Text = "flatToggle1";
            this.tglNitrous.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglNitrous_CheckedChanged);
            // 
            // pnlVehicleUpgrade
            // 
            this.pnlVehicleUpgrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlVehicleUpgrade.Controls.Add(this.tglVehicleUpgrade);
            this.pnlVehicleUpgrade.Controls.Add(this.flatLabel14);
            this.pnlVehicleUpgrade.Location = new System.Drawing.Point(3, 477);
            this.pnlVehicleUpgrade.Name = "pnlVehicleUpgrade";
            this.pnlVehicleUpgrade.Size = new System.Drawing.Size(377, 73);
            this.pnlVehicleUpgrade.TabIndex = 52;
            // 
            // tglVehicleUpgrade
            // 
            this.tglVehicleUpgrade.BackColor = System.Drawing.Color.Transparent;
            this.tglVehicleUpgrade.Checked = false;
            this.tglVehicleUpgrade.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglVehicleUpgrade.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglVehicleUpgrade.Location = new System.Drawing.Point(296, 20);
            this.tglVehicleUpgrade.Name = "tglVehicleUpgrade";
            this.tglVehicleUpgrade.Options = theme.FlatToggle._Options.Style3;
            this.tglVehicleUpgrade.Size = new System.Drawing.Size(76, 33);
            this.tglVehicleUpgrade.TabIndex = 6;
            this.tglVehicleUpgrade.Text = "flatToggle1";
            this.tglVehicleUpgrade.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglVehicleUpgrade_CheckedChanged);
            // 
            // flatLabel14
            // 
            this.flatLabel14.AutoSize = true;
            this.flatLabel14.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel14.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel14.ForeColor = System.Drawing.Color.White;
            this.flatLabel14.Location = new System.Drawing.Point(13, 24);
            this.flatLabel14.Name = "flatLabel14";
            this.flatLabel14.Size = new System.Drawing.Size(213, 20);
            this.flatLabel14.TabIndex = 2;
            this.flatLabel14.Text = "Infinite Vehicle Upgrade Usage";
            // 
            // pnlWallHack
            // 
            this.pnlWallHack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlWallHack.Controls.Add(this.flatLabel10);
            this.pnlWallHack.Controls.Add(this.tglWallhack);
            this.pnlWallHack.Location = new System.Drawing.Point(381, 319);
            this.pnlWallHack.Name = "pnlWallHack";
            this.pnlWallHack.Size = new System.Drawing.Size(359, 73);
            this.pnlWallHack.TabIndex = 51;
            // 
            // flatLabel10
            // 
            this.flatLabel10.AutoSize = true;
            this.flatLabel10.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel10.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel10.ForeColor = System.Drawing.Color.White;
            this.flatLabel10.Location = new System.Drawing.Point(13, 24);
            this.flatLabel10.Name = "flatLabel10";
            this.flatLabel10.Size = new System.Drawing.Size(75, 20);
            this.flatLabel10.TabIndex = 2;
            this.flatLabel10.Text = "Wall Hack";
            // 
            // tglWallhack
            // 
            this.tglWallhack.BackColor = System.Drawing.Color.Transparent;
            this.tglWallhack.Checked = false;
            this.tglWallhack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglWallhack.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglWallhack.Location = new System.Drawing.Point(275, 20);
            this.tglWallhack.Name = "tglWallhack";
            this.tglWallhack.Options = theme.FlatToggle._Options.Style3;
            this.tglWallhack.Size = new System.Drawing.Size(76, 33);
            this.tglWallhack.TabIndex = 5;
            this.tglWallhack.Text = "flatToggle1";
            this.tglWallhack.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglWallhack_CheckedChanged);
            // 
            // pnlUV
            // 
            this.pnlUV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlUV.Controls.Add(this.tglUV);
            this.pnlUV.Controls.Add(this.flatLabel12);
            this.pnlUV.Location = new System.Drawing.Point(3, 398);
            this.pnlUV.Name = "pnlUV";
            this.pnlUV.Size = new System.Drawing.Size(377, 73);
            this.pnlUV.TabIndex = 52;
            // 
            // tglUV
            // 
            this.tglUV.BackColor = System.Drawing.Color.Transparent;
            this.tglUV.Checked = false;
            this.tglUV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglUV.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglUV.Location = new System.Drawing.Point(296, 20);
            this.tglUV.Name = "tglUV";
            this.tglUV.Options = theme.FlatToggle._Options.Style3;
            this.tglUV.Size = new System.Drawing.Size(76, 33);
            this.tglUV.TabIndex = 6;
            this.tglUV.Text = "flatToggle1";
            this.tglUV.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglUV_CheckedChanged);
            // 
            // flatLabel12
            // 
            this.flatLabel12.AutoSize = true;
            this.flatLabel12.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel12.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel12.ForeColor = System.Drawing.Color.White;
            this.flatLabel12.Location = new System.Drawing.Point(13, 24);
            this.flatLabel12.Name = "flatLabel12";
            this.flatLabel12.Size = new System.Drawing.Size(115, 20);
            this.flatLabel12.TabIndex = 2;
            this.flatLabel12.Text = "Infinite UV Light";
            // 
            // pnlScramble
            // 
            this.pnlScramble.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlScramble.Controls.Add(this.tglText);
            this.pnlScramble.Controls.Add(this.flatLabel9);
            this.pnlScramble.Location = new System.Drawing.Point(3, 319);
            this.pnlScramble.Name = "pnlScramble";
            this.pnlScramble.Size = new System.Drawing.Size(377, 73);
            this.pnlScramble.TabIndex = 50;
            // 
            // tglText
            // 
            this.tglText.BackColor = System.Drawing.Color.Transparent;
            this.tglText.Checked = false;
            this.tglText.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglText.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglText.Location = new System.Drawing.Point(296, 20);
            this.tglText.Name = "tglText";
            this.tglText.Options = theme.FlatToggle._Options.Style3;
            this.tglText.Size = new System.Drawing.Size(76, 33);
            this.tglText.TabIndex = 6;
            this.tglText.Text = "flatToggle1";
            this.tglText.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglText_CheckedChanged);
            // 
            // flatLabel9
            // 
            this.flatLabel9.AutoSize = true;
            this.flatLabel9.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel9.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel9.ForeColor = System.Drawing.Color.White;
            this.flatLabel9.Location = new System.Drawing.Point(13, 24);
            this.flatLabel9.Name = "flatLabel9";
            this.flatLabel9.Size = new System.Drawing.Size(143, 20);
            this.flatLabel9.TabIndex = 2;
            this.flatLabel9.Text = "Scramble Menu Text";
            // 
            // pnlWeather
            // 
            this.pnlWeather.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlWeather.Controls.Add(this.flatLabel8);
            this.pnlWeather.Controls.Add(this.tglWeather);
            this.pnlWeather.Location = new System.Drawing.Point(381, 240);
            this.pnlWeather.Name = "pnlWeather";
            this.pnlWeather.Size = new System.Drawing.Size(359, 73);
            this.pnlWeather.TabIndex = 50;
            // 
            // flatLabel8
            // 
            this.flatLabel8.AutoSize = true;
            this.flatLabel8.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel8.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel8.ForeColor = System.Drawing.Color.White;
            this.flatLabel8.Location = new System.Drawing.Point(13, 24);
            this.flatLabel8.Name = "flatLabel8";
            this.flatLabel8.Size = new System.Drawing.Size(94, 20);
            this.flatLabel8.TabIndex = 2;
            this.flatLabel8.Text = "Bad Weather";
            // 
            // tglWeather
            // 
            this.tglWeather.BackColor = System.Drawing.Color.Transparent;
            this.tglWeather.Checked = false;
            this.tglWeather.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglWeather.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglWeather.Location = new System.Drawing.Point(275, 20);
            this.tglWeather.Name = "tglWeather";
            this.tglWeather.Options = theme.FlatToggle._Options.Style3;
            this.tglWeather.Size = new System.Drawing.Size(76, 33);
            this.tglWeather.TabIndex = 5;
            this.tglWeather.Text = "flatToggle1";
            this.tglWeather.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglWeather_CheckedChanged);
            // 
            // pnlGrappling
            // 
            this.pnlGrappling.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlGrappling.Controls.Add(this.tglGrappling);
            this.pnlGrappling.Controls.Add(this.flatLabel7);
            this.pnlGrappling.Location = new System.Drawing.Point(3, 240);
            this.pnlGrappling.Name = "pnlGrappling";
            this.pnlGrappling.Size = new System.Drawing.Size(377, 73);
            this.pnlGrappling.TabIndex = 49;
            // 
            // tglGrappling
            // 
            this.tglGrappling.BackColor = System.Drawing.Color.Transparent;
            this.tglGrappling.Checked = false;
            this.tglGrappling.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglGrappling.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglGrappling.Location = new System.Drawing.Point(296, 20);
            this.tglGrappling.Name = "tglGrappling";
            this.tglGrappling.Options = theme.FlatToggle._Options.Style3;
            this.tglGrappling.Size = new System.Drawing.Size(76, 33);
            this.tglGrappling.TabIndex = 6;
            this.tglGrappling.Text = "flatToggle1";
            this.tglGrappling.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglGrappling_CheckedChanged);
            // 
            // flatLabel7
            // 
            this.flatLabel7.AutoSize = true;
            this.flatLabel7.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel7.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel7.ForeColor = System.Drawing.Color.White;
            this.flatLabel7.Location = new System.Drawing.Point(13, 24);
            this.flatLabel7.Name = "flatLabel7";
            this.flatLabel7.Size = new System.Drawing.Size(183, 20);
            this.flatLabel7.TabIndex = 2;
            this.flatLabel7.Text = "Infinite Grappling Stamina";
            // 
            // pnlNoItemDecrease
            // 
            this.pnlNoItemDecrease.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlNoItemDecrease.Controls.Add(this.flatLabel6);
            this.pnlNoItemDecrease.Controls.Add(this.tglItems);
            this.pnlNoItemDecrease.Location = new System.Drawing.Point(381, 161);
            this.pnlNoItemDecrease.Name = "pnlNoItemDecrease";
            this.pnlNoItemDecrease.Size = new System.Drawing.Size(359, 73);
            this.pnlNoItemDecrease.TabIndex = 49;
            // 
            // flatLabel6
            // 
            this.flatLabel6.AutoSize = true;
            this.flatLabel6.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel6.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel6.ForeColor = System.Drawing.Color.White;
            this.flatLabel6.Location = new System.Drawing.Point(13, 24);
            this.flatLabel6.Name = "flatLabel6";
            this.flatLabel6.Size = new System.Drawing.Size(128, 20);
            this.flatLabel6.TabIndex = 2;
            this.flatLabel6.Text = "No Item Decrease";
            // 
            // tglItems
            // 
            this.tglItems.BackColor = System.Drawing.Color.Transparent;
            this.tglItems.Checked = false;
            this.tglItems.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglItems.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglItems.Location = new System.Drawing.Point(275, 20);
            this.tglItems.Name = "tglItems";
            this.tglItems.Options = theme.FlatToggle._Options.Style3;
            this.tglItems.Size = new System.Drawing.Size(76, 33);
            this.tglItems.TabIndex = 5;
            this.tglItems.Text = "flatToggle1";
            this.tglItems.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglItems_CheckedChanged);
            // 
            // pnlAmmo
            // 
            this.pnlAmmo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlAmmo.Controls.Add(this.flatToggle4);
            this.pnlAmmo.Controls.Add(this.flatLabel5);
            this.pnlAmmo.Location = new System.Drawing.Point(3, 161);
            this.pnlAmmo.Name = "pnlAmmo";
            this.pnlAmmo.Size = new System.Drawing.Size(377, 73);
            this.pnlAmmo.TabIndex = 48;
            // 
            // flatToggle4
            // 
            this.flatToggle4.BackColor = System.Drawing.Color.Transparent;
            this.flatToggle4.Checked = false;
            this.flatToggle4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatToggle4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.flatToggle4.Location = new System.Drawing.Point(296, 20);
            this.flatToggle4.Name = "flatToggle4";
            this.flatToggle4.Options = theme.FlatToggle._Options.Style3;
            this.flatToggle4.Size = new System.Drawing.Size(76, 33);
            this.flatToggle4.TabIndex = 6;
            this.flatToggle4.Text = "flatToggle4";
            this.flatToggle4.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.flatToggle4_CheckedChanged);
            // 
            // flatLabel5
            // 
            this.flatLabel5.AutoSize = true;
            this.flatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel5.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel5.ForeColor = System.Drawing.Color.White;
            this.flatLabel5.Location = new System.Drawing.Point(13, 24);
            this.flatLabel5.Name = "flatLabel5";
            this.flatLabel5.Size = new System.Drawing.Size(104, 20);
            this.flatLabel5.TabIndex = 2;
            this.flatLabel5.Text = "Infinite Ammo";
            // 
            // pnlWeaponDur
            // 
            this.pnlWeaponDur.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlWeaponDur.Controls.Add(this.flatLabel2);
            this.pnlWeaponDur.Controls.Add(this.flatToggle2);
            this.pnlWeaponDur.Location = new System.Drawing.Point(381, 82);
            this.pnlWeaponDur.Name = "pnlWeaponDur";
            this.pnlWeaponDur.Size = new System.Drawing.Size(359, 73);
            this.pnlWeaponDur.TabIndex = 48;
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(13, 24);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(183, 20);
            this.flatLabel2.TabIndex = 2;
            this.flatLabel2.Text = "Infinite Weapon Durability";
            // 
            // flatToggle2
            // 
            this.flatToggle2.BackColor = System.Drawing.Color.Transparent;
            this.flatToggle2.Checked = false;
            this.flatToggle2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatToggle2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.flatToggle2.Location = new System.Drawing.Point(275, 20);
            this.flatToggle2.Name = "flatToggle2";
            this.flatToggle2.Options = theme.FlatToggle._Options.Style3;
            this.flatToggle2.Size = new System.Drawing.Size(76, 33);
            this.flatToggle2.TabIndex = 5;
            this.flatToggle2.Text = "flatToggle1";
            this.flatToggle2.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.flatToggle2_CheckedChanged);
            // 
            // pnlHealth
            // 
            this.pnlHealth.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlHealth.Controls.Add(this.flatToggle3);
            this.pnlHealth.Controls.Add(this.flatLabel4);
            this.pnlHealth.Location = new System.Drawing.Point(3, 82);
            this.pnlHealth.Name = "pnlHealth";
            this.pnlHealth.Size = new System.Drawing.Size(377, 73);
            this.pnlHealth.TabIndex = 47;
            // 
            // flatToggle3
            // 
            this.flatToggle3.BackColor = System.Drawing.Color.Transparent;
            this.flatToggle3.Checked = false;
            this.flatToggle3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatToggle3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.flatToggle3.Location = new System.Drawing.Point(296, 20);
            this.flatToggle3.Name = "flatToggle3";
            this.flatToggle3.Options = theme.FlatToggle._Options.Style3;
            this.flatToggle3.Size = new System.Drawing.Size(76, 33);
            this.flatToggle3.TabIndex = 6;
            this.flatToggle3.Text = "flatToggle3";
            this.flatToggle3.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.flatToggle3_CheckedChanged);
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(13, 24);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(103, 20);
            this.flatLabel4.TabIndex = 2;
            this.flatLabel4.Text = "Infinite Health";
            // 
            // pnlBuyToEarn
            // 
            this.pnlBuyToEarn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlBuyToEarn.Controls.Add(this.flatLabel1);
            this.pnlBuyToEarn.Controls.Add(this.tglHealth);
            this.pnlBuyToEarn.Location = new System.Drawing.Point(381, 3);
            this.pnlBuyToEarn.Name = "pnlBuyToEarn";
            this.pnlBuyToEarn.Size = new System.Drawing.Size(359, 73);
            this.pnlBuyToEarn.TabIndex = 46;
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(13, 24);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(135, 20);
            this.flatLabel1.TabIndex = 2;
            this.flatLabel1.Text = "Buy To Earn Money";
            // 
            // tglHealth
            // 
            this.tglHealth.BackColor = System.Drawing.Color.Transparent;
            this.tglHealth.Checked = false;
            this.tglHealth.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglHealth.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglHealth.Location = new System.Drawing.Point(275, 20);
            this.tglHealth.Name = "tglHealth";
            this.tglHealth.Options = theme.FlatToggle._Options.Style3;
            this.tglHealth.Size = new System.Drawing.Size(76, 33);
            this.tglHealth.TabIndex = 5;
            this.tglHealth.Text = "flatToggle1";
            this.tglHealth.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglHealth_CheckedChanged);
            // 
            // pnlSkills
            // 
            this.pnlSkills.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.pnlSkills.Controls.Add(this.btnSkills);
            this.pnlSkills.Controls.Add(this.flatLabel3);
            this.pnlSkills.Location = new System.Drawing.Point(3, 3);
            this.pnlSkills.Name = "pnlSkills";
            this.pnlSkills.Size = new System.Drawing.Size(377, 73);
            this.pnlSkills.TabIndex = 45;
            // 
            // btnSkills
            // 
            this.btnSkills.BackColor = System.Drawing.Color.Transparent;
            this.btnSkills.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnSkills.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSkills.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnSkills.Location = new System.Drawing.Point(254, 15);
            this.btnSkills.Name = "btnSkills";
            this.btnSkills.Rounded = false;
            this.btnSkills.Size = new System.Drawing.Size(118, 44);
            this.btnSkills.TabIndex = 112;
            this.btnSkills.Text = "Max";
            this.btnSkills.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnSkills.Click += new System.EventHandler(this.btnSkills_Click);
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(13, 24);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(96, 20);
            this.flatLabel3.TabIndex = 2;
            this.flatLabel3.Text = "Max All Skills";
            // 
            // btnAttach
            // 
            this.btnAttach.BackColor = System.Drawing.Color.Transparent;
            this.btnAttach.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAttach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAttach.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAttach.Location = new System.Drawing.Point(395, 3);
            this.btnAttach.Name = "btnAttach";
            this.btnAttach.Rounded = false;
            this.btnAttach.Size = new System.Drawing.Size(118, 44);
            this.btnAttach.TabIndex = 111;
            this.btnAttach.Text = "Attach";
            this.btnAttach.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAttach.Click += new System.EventHandler(this.btnAttach_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(351, 72);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 110;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label4.Location = new System.Drawing.Point(-1, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(273, 28);
            this.label4.TabIndex = 108;
            this.label4.Text = "Cheater : Rizla + TylerMods";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label3.Location = new System.Drawing.Point(394, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 28);
            this.label3.TabIndex = 107;
            this.label3.Text = "CUSA03991";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(519, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 99);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 105;
            this.pictureBox1.TabStop = false;
            // 
            // cmbVersion
            // 
            this.cmbVersion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.cmbVersion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbVersion.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVersion.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cmbVersion.ForeColor = System.Drawing.Color.White;
            this.cmbVersion.FormattingEnabled = true;
            this.cmbVersion.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.cmbVersion.ItemHeight = 18;
            this.cmbVersion.Items.AddRange(new object[] {
            "v1.00",
            "v1.06"});
            this.cmbVersion.Location = new System.Drawing.Point(392, 79);
            this.cmbVersion.Name = "cmbVersion";
            this.cmbVersion.Size = new System.Drawing.Size(121, 24);
            this.cmbVersion.TabIndex = 100;
            this.cmbVersion.SelectedIndexChanged += new System.EventHandler(this.cmbVersion_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.panel1.Controls.Add(this.pnlFuel);
            this.panel1.Controls.Add(this.pnlNitrous);
            this.panel1.Controls.Add(this.pnlVehicleUpgrade);
            this.panel1.Controls.Add(this.pnlWallHack);
            this.panel1.Controls.Add(this.pnlUV);
            this.panel1.Controls.Add(this.pnlScramble);
            this.panel1.Controls.Add(this.pnlWeather);
            this.panel1.Controls.Add(this.pnlGrappling);
            this.panel1.Controls.Add(this.pnlNoItemDecrease);
            this.panel1.Controls.Add(this.pnlAmmo);
            this.panel1.Controls.Add(this.pnlWeaponDur);
            this.panel1.Controls.Add(this.pnlHealth);
            this.panel1.Controls.Add(this.pnlBuyToEarn);
            this.panel1.Controls.Add(this.pnlSkills);
            this.panel1.Location = new System.Drawing.Point(1, 106);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(758, 349);
            this.panel1.TabIndex = 109;
            // 
            // DyingLightEE
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.cmbVersion);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnAttach);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Name = "DyingLightEE";
            this.Size = new System.Drawing.Size(758, 455);
            this.Load += new System.EventHandler(this.DyingLightEE_Load);
            this.pnlFuel.ResumeLayout(false);
            this.pnlFuel.PerformLayout();
            this.pnlNitrous.ResumeLayout(false);
            this.pnlNitrous.PerformLayout();
            this.pnlVehicleUpgrade.ResumeLayout(false);
            this.pnlVehicleUpgrade.PerformLayout();
            this.pnlWallHack.ResumeLayout(false);
            this.pnlWallHack.PerformLayout();
            this.pnlUV.ResumeLayout(false);
            this.pnlUV.PerformLayout();
            this.pnlScramble.ResumeLayout(false);
            this.pnlScramble.PerformLayout();
            this.pnlWeather.ResumeLayout(false);
            this.pnlWeather.PerformLayout();
            this.pnlGrappling.ResumeLayout(false);
            this.pnlGrappling.PerformLayout();
            this.pnlNoItemDecrease.ResumeLayout(false);
            this.pnlNoItemDecrease.PerformLayout();
            this.pnlAmmo.ResumeLayout(false);
            this.pnlAmmo.PerformLayout();
            this.pnlWeaponDur.ResumeLayout(false);
            this.pnlWeaponDur.PerformLayout();
            this.pnlHealth.ResumeLayout(false);
            this.pnlHealth.PerformLayout();
            this.pnlBuyToEarn.ResumeLayout(false);
            this.pnlBuyToEarn.PerformLayout();
            this.pnlSkills.ResumeLayout(false);
            this.pnlSkills.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel pnlBuyToEarn;
        private theme.FlatToggle tglHealth;
        private theme.FlatLabel flatLabel1;
        private System.Windows.Forms.Panel pnlSkills;
        private theme.FlatLabel flatLabel3;
        private theme.FlatButton btnAttach;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnlAmmo;
        private theme.FlatToggle flatToggle4;
        private theme.FlatLabel flatLabel5;
        private System.Windows.Forms.Panel pnlWeaponDur;
        private theme.FlatLabel flatLabel2;
        private theme.FlatToggle flatToggle2;
        private System.Windows.Forms.Panel pnlHealth;
        private theme.FlatToggle flatToggle3;
        private theme.FlatLabel flatLabel4;
        private theme.FlatButton btnSkills;
        private System.Windows.Forms.Panel pnlNoItemDecrease;
        private theme.FlatLabel flatLabel6;
        private theme.FlatToggle tglItems;
        private System.Windows.Forms.Panel pnlGrappling;
        private theme.FlatToggle tglGrappling;
        private theme.FlatLabel flatLabel7;
        private System.Windows.Forms.Panel pnlWeather;
        private theme.FlatLabel flatLabel8;
        private theme.FlatToggle tglWeather;
        private System.Windows.Forms.Panel pnlScramble;
        private theme.FlatToggle tglText;
        private theme.FlatLabel flatLabel9;
        private System.Windows.Forms.Panel pnlWallHack;
        private theme.FlatLabel flatLabel10;
        private theme.FlatToggle tglWallhack;
        private theme.FlatComboBox cmbVersion;
        private System.Windows.Forms.Panel pnlFuel;
        private theme.FlatLabel flatLabel13;
        private theme.FlatToggle tglFuel;
        private System.Windows.Forms.Panel pnlNitrous;
        private theme.FlatLabel flatLabel11;
        private theme.FlatToggle tglNitrous;
        private System.Windows.Forms.Panel pnlVehicleUpgrade;
        private theme.FlatToggle tglVehicleUpgrade;
        private theme.FlatLabel flatLabel14;
        private System.Windows.Forms.Panel pnlUV;
        private theme.FlatToggle tglUV;
        private theme.FlatLabel flatLabel12;
        private System.Windows.Forms.Panel panel1;
    }
}

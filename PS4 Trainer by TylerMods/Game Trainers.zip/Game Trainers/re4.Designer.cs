﻿namespace PS4_Trainer_by_TylerMods
{
    partial class re4
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(re4));
            this.label4 = new System.Windows.Forms.Label();
            this.flatLabel3 = new theme.FlatLabel();
            this.tglGodMode = new theme.FlatToggle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.numCurrency = new theme.FlatNumeric();
            this.flatLabel2 = new theme.FlatLabel();
            this.btnSetCurrency = new theme.FlatButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnFAQ = new theme.FlatButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.flatLabel6 = new theme.FlatLabel();
            this.tglInvAmmo = new theme.FlatToggle();
            this.panel8 = new System.Windows.Forms.Panel();
            this.flatLabel7 = new theme.FlatLabel();
            this.tglMatrix = new theme.FlatToggle();
            this.panel6 = new System.Windows.Forms.Panel();
            this.flatLabel5 = new theme.FlatLabel();
            this.tglAmmo = new theme.FlatToggle();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnResetGun = new theme.FlatButton();
            this.cmbChangeHandgun = new theme.FlatComboBox();
            this.flatLabel4 = new theme.FlatLabel();
            this.btnChangeHandgun = new theme.FlatButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cmb999Ammo = new theme.FlatComboBox();
            this.flatLabel1 = new theme.FlatLabel();
            this.btnSetAmmo = new theme.FlatButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnAttach = new theme.FlatButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.tglElevation = new theme.FlatToggle();
            this.cmbElevation = new theme.FlatComboBox();
            this.flatLabel8 = new theme.FlatLabel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label4.Location = new System.Drawing.Point(6, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(201, 28);
            this.label4.TabIndex = 52;
            this.label4.Text = "Cheater : TylerMods";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(24, 25);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(122, 20);
            this.flatLabel3.TabIndex = 2;
            this.flatLabel3.Text = "Unlimited Health";
            this.flatLabel3.Click += new System.EventHandler(this.flatLabel3_Click);
            // 
            // tglGodMode
            // 
            this.tglGodMode.BackColor = System.Drawing.Color.Transparent;
            this.tglGodMode.Checked = false;
            this.tglGodMode.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglGodMode.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglGodMode.Location = new System.Drawing.Point(290, 21);
            this.tglGodMode.Name = "tglGodMode";
            this.tglGodMode.Options = theme.FlatToggle._Options.Style3;
            this.tglGodMode.Size = new System.Drawing.Size(76, 33);
            this.tglGodMode.TabIndex = 1;
            this.tglGodMode.Text = "flatToggle1";
            this.tglGodMode.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglGodMode_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel1.Controls.Add(this.flatLabel3);
            this.panel1.Controls.Add(this.tglGodMode);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(374, 73);
            this.panel1.TabIndex = 44;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // numCurrency
            // 
            this.numCurrency.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.numCurrency.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.numCurrency.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.numCurrency.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numCurrency.ForeColor = System.Drawing.Color.White;
            this.numCurrency.Location = new System.Drawing.Point(118, 21);
            this.numCurrency.Maximum = ((long)(99999999));
            this.numCurrency.Minimum = ((long)(0));
            this.numCurrency.Name = "numCurrency";
            this.numCurrency.Size = new System.Drawing.Size(129, 30);
            this.numCurrency.TabIndex = 3;
            this.numCurrency.Text = "flatNumeric1";
            this.numCurrency.Value = ((long)(0));
            this.numCurrency.Click += new System.EventHandler(this.numCurrency_Click);
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(27, 25);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(66, 20);
            this.flatLabel2.TabIndex = 2;
            this.flatLabel2.Text = "Currency";
            this.flatLabel2.Click += new System.EventHandler(this.flatLabel2_Click);
            // 
            // btnSetCurrency
            // 
            this.btnSetCurrency.BackColor = System.Drawing.Color.Transparent;
            this.btnSetCurrency.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnSetCurrency.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSetCurrency.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnSetCurrency.Location = new System.Drawing.Point(269, 14);
            this.btnSetCurrency.Name = "btnSetCurrency";
            this.btnSetCurrency.Rounded = false;
            this.btnSetCurrency.Size = new System.Drawing.Size(102, 44);
            this.btnSetCurrency.TabIndex = 0;
            this.btnSetCurrency.Text = "Set Currency";
            this.btnSetCurrency.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnSetCurrency.Click += new System.EventHandler(this.btnSetCurrency_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel2.Controls.Add(this.numCurrency);
            this.panel2.Controls.Add(this.flatLabel2);
            this.panel2.Controls.Add(this.btnSetCurrency);
            this.panel2.Location = new System.Drawing.Point(379, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(376, 73);
            this.panel2.TabIndex = 46;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // btnFAQ
            // 
            this.btnFAQ.BackColor = System.Drawing.Color.Transparent;
            this.btnFAQ.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnFAQ.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFAQ.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnFAQ.Location = new System.Drawing.Point(348, 3);
            this.btnFAQ.Name = "btnFAQ";
            this.btnFAQ.Rounded = false;
            this.btnFAQ.Size = new System.Drawing.Size(21, 25);
            this.btnFAQ.TabIndex = 46;
            this.btnFAQ.Text = "?";
            this.btnFAQ.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnFAQ.Click += new System.EventHandler(this.btnFAQ_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label3.Location = new System.Drawing.Point(389, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 28);
            this.label3.TabIndex = 50;
            this.label3.Text = "CUSA04885";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.label1.Location = new System.Drawing.Point(312, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 28);
            this.label1.TabIndex = 48;
            this.label1.Text = "Game Version : 1.00";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(518, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 99);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 47;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel5
            // 
            this.panel5.AutoScroll = true;
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.panel4);
            this.panel5.Controls.Add(this.panel3);
            this.panel5.Controls.Add(this.panel2);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Location = new System.Drawing.Point(0, 108);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(758, 344);
            this.panel5.TabIndex = 51;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel7.Controls.Add(this.flatLabel6);
            this.panel7.Controls.Add(this.tglInvAmmo);
            this.panel7.Location = new System.Drawing.Point(3, 162);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(374, 73);
            this.panel7.TabIndex = 46;
            // 
            // flatLabel6
            // 
            this.flatLabel6.AutoSize = true;
            this.flatLabel6.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel6.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel6.ForeColor = System.Drawing.Color.White;
            this.flatLabel6.Location = new System.Drawing.Point(24, 24);
            this.flatLabel6.Name = "flatLabel6";
            this.flatLabel6.Size = new System.Drawing.Size(188, 20);
            this.flatLabel6.TabIndex = 2;
            this.flatLabel6.Text = "Unlimited Inventory Ammo";
            // 
            // tglInvAmmo
            // 
            this.tglInvAmmo.BackColor = System.Drawing.Color.Transparent;
            this.tglInvAmmo.Checked = false;
            this.tglInvAmmo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglInvAmmo.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglInvAmmo.Location = new System.Drawing.Point(290, 19);
            this.tglInvAmmo.Name = "tglInvAmmo";
            this.tglInvAmmo.Options = theme.FlatToggle._Options.Style3;
            this.tglInvAmmo.Size = new System.Drawing.Size(76, 33);
            this.tglInvAmmo.TabIndex = 1;
            this.tglInvAmmo.Text = "flatToggle1";
            this.tglInvAmmo.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglInvAmmo_CheckedChanged);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel8.Controls.Add(this.flatLabel7);
            this.panel8.Controls.Add(this.tglMatrix);
            this.panel8.Location = new System.Drawing.Point(379, 82);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(376, 73);
            this.panel8.TabIndex = 47;
            // 
            // flatLabel7
            // 
            this.flatLabel7.AutoSize = true;
            this.flatLabel7.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel7.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel7.ForeColor = System.Drawing.Color.White;
            this.flatLabel7.Location = new System.Drawing.Point(24, 24);
            this.flatLabel7.Name = "flatLabel7";
            this.flatLabel7.Size = new System.Drawing.Size(51, 20);
            this.flatLabel7.TabIndex = 2;
            this.flatLabel7.Text = "Matrix";
            // 
            // tglMatrix
            // 
            this.tglMatrix.BackColor = System.Drawing.Color.Transparent;
            this.tglMatrix.Checked = false;
            this.tglMatrix.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglMatrix.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglMatrix.Location = new System.Drawing.Point(290, 19);
            this.tglMatrix.Name = "tglMatrix";
            this.tglMatrix.Options = theme.FlatToggle._Options.Style3;
            this.tglMatrix.Size = new System.Drawing.Size(76, 33);
            this.tglMatrix.TabIndex = 1;
            this.tglMatrix.Text = "flatToggle1";
            this.tglMatrix.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglMatrix_CheckedChanged);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel6.Controls.Add(this.flatLabel5);
            this.panel6.Controls.Add(this.tglAmmo);
            this.panel6.Location = new System.Drawing.Point(3, 82);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(374, 73);
            this.panel6.TabIndex = 45;
            // 
            // flatLabel5
            // 
            this.flatLabel5.AutoSize = true;
            this.flatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel5.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel5.ForeColor = System.Drawing.Color.White;
            this.flatLabel5.Location = new System.Drawing.Point(24, 24);
            this.flatLabel5.Name = "flatLabel5";
            this.flatLabel5.Size = new System.Drawing.Size(123, 20);
            this.flatLabel5.TabIndex = 2;
            this.flatLabel5.Text = "Unlimited Ammo";
            // 
            // tglAmmo
            // 
            this.tglAmmo.BackColor = System.Drawing.Color.Transparent;
            this.tglAmmo.Checked = false;
            this.tglAmmo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglAmmo.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglAmmo.Location = new System.Drawing.Point(290, 19);
            this.tglAmmo.Name = "tglAmmo";
            this.tglAmmo.Options = theme.FlatToggle._Options.Style3;
            this.tglAmmo.Size = new System.Drawing.Size(76, 33);
            this.tglAmmo.TabIndex = 1;
            this.tglAmmo.Text = "flatToggle1";
            this.tglAmmo.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.tglAmmo_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel4.Controls.Add(this.btnResetGun);
            this.panel4.Controls.Add(this.cmbChangeHandgun);
            this.panel4.Controls.Add(this.flatLabel4);
            this.panel4.Controls.Add(this.btnChangeHandgun);
            this.panel4.Location = new System.Drawing.Point(379, 161);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(376, 74);
            this.panel4.TabIndex = 47;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // btnResetGun
            // 
            this.btnResetGun.BackColor = System.Drawing.Color.Transparent;
            this.btnResetGun.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnResetGun.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnResetGun.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnResetGun.Location = new System.Drawing.Point(299, 3);
            this.btnResetGun.Name = "btnResetGun";
            this.btnResetGun.Rounded = false;
            this.btnResetGun.Size = new System.Drawing.Size(72, 68);
            this.btnResetGun.TabIndex = 4;
            this.btnResetGun.Text = "Reset";
            this.btnResetGun.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnResetGun.Click += new System.EventHandler(this.btnResetGun_Click);
            // 
            // cmbChangeHandgun
            // 
            this.cmbChangeHandgun.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.cmbChangeHandgun.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbChangeHandgun.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbChangeHandgun.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChangeHandgun.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cmbChangeHandgun.ForeColor = System.Drawing.Color.White;
            this.cmbChangeHandgun.FormattingEnabled = true;
            this.cmbChangeHandgun.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.cmbChangeHandgun.ItemHeight = 18;
            this.cmbChangeHandgun.Items.AddRange(new object[] {
            "Activation Key (blue) (Key Item)",
            "Activation Key (red) (Key Item)",
            "Attach Case (L) (Case)",
            "Attach Case (M) (Case)",
            "Attach Case (S) (Case)",
            "Attach Case (XL) (Case)",
            "Black Bass (Item)",
            "Black Bass (L) (Item)",
            "Blacktail (Weapon)",
            "Blacktail w/Silencer (Weapon)",
            "Bow Gun (Weapon)",
            "Broken Butterfly (Weapon)",
            "Brown Chicken Egg (Item)",
            "Camp Key (Key Item)",
            "Castle Gate Key (Key Item)",
            "Chicago Typewriter (Weapon)",
            "Chicago Typewriter Ammo (Item)",
            "Chicken Egg (Item)",
            "Combat Knife (Weapon)",
            "Custom TMP (Weapon)",
            "Dynamite (Key Item)",
            "Emblem (Left half) (Key Item)",
            "Emblem (Right half) (Key Item)",
            "Emergency Lock Card Key (Key Item)",
            "False Eye (Key Item)",
            "First Aid Spray (Item)",
            "Flash Grenade (Item)",
            "Freezer Card Key (Key Item)",
            "Gallery Key (Key Item)",
            "Goat Ornament (Key Item)",
            "Gold Chicken Egg (Item)",
            "Golden Sword (Key Item)",
            "Green Herb (Item)",
            "Green Herb(2x) (Item)",
            "Green Herb(3x) (Item)",
            "Hand Grenade (Item)",
            "Handcannon (Weapon)",
            "Handcannon Ammo (Item)",
            "Handgun (Weapon)",
            "Handgun Ammo (Item)",
            "Handgun w/Silencer (Weapon)",
            "Hexagonal Emblem (Key Item)",
            "Incendiary Grenade (Item)",
            "Infinite Launcher (Weapon)",
            "Infrared Scope (Item)",
            "Insignia Key (Key Item)",
            "Iron Key (Key Item)",
            "Jet-ski Key (Key Item)",
            "Key to the Mine (Key Item)",
            "Killer7 (Weapon)",
            "Killer7 w/Silencer (Weapon)",
            "King\'s Grail (Key Item)",
            "Krauser\'s Bow (Weapon)",
            "Krauser\'s Knife (Weapon)",
            "Lift Activation Key (Key Item)",
            "Lion Ornament (Key Item)",
            "Matilda (Weapon)",
            "Mine Thrower (Weapon)",
            "Mine Thrower + Scope (Weapon)",
            "Mine-Darts (Item)",
            "Mixed Herb (G+R) (Item)",
            "Mixed Herb (G+R+Y) (Item)",
            "Mixed Herb (G+Y) (Item)",
            "Mixed Herbs (R+Y) (Item)",
            "Moonstone (Left half) (Key Item)",
            "Moonstone (Right half) (Key Item)",
            "Old Key (Key Item)",
            "P.R.L. 412 (Weapon)",
            "Piece of the Holy Beast, Eagle (Key Item)",
            "Piece of the Holy Beast, Panther (Key Item)",
            "Piece of the Holy Beast, Serpent (Key Item)",
            "Plaga Sample (Item)",
            "Platinum Sword (Key Item)",
            "Prison Key (Key Item)",
            "Punisher (Weapon)",
            "Punisher w/Silencer (Weapon)",
            "Queen\'s Grail (Key Item)",
            "Red Herb (Item)",
            "Red9 (Weapon)",
            "Red9 w/Stock (Weapon)",
            "Rifle Ammo (Infrared) (Unsure)",
            "Rifle (Weapon)",
            "Rifle (semi-auto) (Weapon)",
            "Rifle (semi-auto) w/Infrared Scope (Weapon)",
            "Rifle (semi-auto) w/Scope (Weapon)",
            "Rifle + Scope (Weapon)",
            "Rifle Ammo (Item)",
            "Rifle w/Infrared Scope (Weapon)",
            "Riot Gun (Weapon)",
            "Rocket Launcher (Weapon)",
            "Rocket Launcher(Special) (Weapon)",
            "Round Insignia (Key Item)",
            "Salazar Family Insignia (Key Item)",
            "Scope (Mine Thrower) (Item)",
            "Scope (Rifle) (Item)",
            "Scope (semi-auto rifle) (Item)",
            "Serpent Ornament (Key Item)",
            "Shotgun (Weapon)",
            "Shotgun Ammo (Item)",
            "Silencer (Hangun) (Item)",
            "Stock (Red9) (Item)",
            "Stock (TMP) (Item)",
            "Stone Tablet (Key Item)",
            "Stone of Sacrifice (Unsure)",
            "Storage Room Card Key (Key Item)",
            "Striker (Weapon)",
            "TMP (Weapon)",
            "TMP Ammo (Item)",
            "TMP w/Stock (Weapon)",
            "Tactical Vest (Item)",
            "Waste Disposal Card Key (Key Item)",
            "Yellow Herb (Item)"});
            this.cmbChangeHandgun.Location = new System.Drawing.Point(8, 35);
            this.cmbChangeHandgun.Name = "cmbChangeHandgun";
            this.cmbChangeHandgun.Size = new System.Drawing.Size(206, 24);
            this.cmbChangeHandgun.TabIndex = 3;
            this.cmbChangeHandgun.SelectedIndexChanged += new System.EventHandler(this.cmbChangeHandgun_SelectedIndexChanged);
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(24, 3);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(115, 20);
            this.flatLabel4.TabIndex = 2;
            this.flatLabel4.Text = "Change Hangun";
            this.flatLabel4.Click += new System.EventHandler(this.flatLabel4_Click);
            // 
            // btnChangeHandgun
            // 
            this.btnChangeHandgun.BackColor = System.Drawing.Color.Transparent;
            this.btnChangeHandgun.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnChangeHandgun.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChangeHandgun.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnChangeHandgun.Location = new System.Drawing.Point(225, 3);
            this.btnChangeHandgun.Name = "btnChangeHandgun";
            this.btnChangeHandgun.Rounded = false;
            this.btnChangeHandgun.Size = new System.Drawing.Size(68, 67);
            this.btnChangeHandgun.TabIndex = 0;
            this.btnChangeHandgun.Text = "Change";
            this.btnChangeHandgun.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnChangeHandgun.Click += new System.EventHandler(this.btnChangeHandgun_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel3.Controls.Add(this.cmb999Ammo);
            this.panel3.Controls.Add(this.flatLabel1);
            this.panel3.Controls.Add(this.btnSetAmmo);
            this.panel3.Location = new System.Drawing.Point(388, 268);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(370, 73);
            this.panel3.TabIndex = 45;
            this.panel3.Visible = false;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // cmb999Ammo
            // 
            this.cmb999Ammo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.cmb999Ammo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmb999Ammo.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb999Ammo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb999Ammo.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cmb999Ammo.ForeColor = System.Drawing.Color.White;
            this.cmb999Ammo.FormattingEnabled = true;
            this.cmb999Ammo.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.cmb999Ammo.ItemHeight = 18;
            this.cmb999Ammo.Items.AddRange(new object[] {
            "Handgun"});
            this.cmb999Ammo.Location = new System.Drawing.Point(8, 35);
            this.cmb999Ammo.Name = "cmb999Ammo";
            this.cmb999Ammo.Size = new System.Drawing.Size(169, 24);
            this.cmb999Ammo.TabIndex = 3;
            this.cmb999Ammo.SelectedIndexChanged += new System.EventHandler(this.cmb999Ammo_SelectedIndexChanged);
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(41, 6);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(82, 20);
            this.flatLabel1.TabIndex = 2;
            this.flatLabel1.Text = "999 Ammo";
            this.flatLabel1.Click += new System.EventHandler(this.flatLabel1_Click);
            // 
            // btnSetAmmo
            // 
            this.btnSetAmmo.BackColor = System.Drawing.Color.Transparent;
            this.btnSetAmmo.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnSetAmmo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSetAmmo.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnSetAmmo.Location = new System.Drawing.Point(244, 15);
            this.btnSetAmmo.Name = "btnSetAmmo";
            this.btnSetAmmo.Rounded = false;
            this.btnSetAmmo.Size = new System.Drawing.Size(122, 44);
            this.btnSetAmmo.TabIndex = 0;
            this.btnSetAmmo.Text = "Set Ammo";
            this.btnSetAmmo.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnSetAmmo.Click += new System.EventHandler(this.btnSetAmmo_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(342, 74);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 53;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // btnAttach
            // 
            this.btnAttach.BackColor = System.Drawing.Color.Transparent;
            this.btnAttach.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.btnAttach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAttach.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnAttach.Location = new System.Drawing.Point(394, 3);
            this.btnAttach.Name = "btnAttach";
            this.btnAttach.Rounded = false;
            this.btnAttach.Size = new System.Drawing.Size(118, 44);
            this.btnAttach.TabIndex = 5;
            this.btnAttach.Text = "Attach";
            this.btnAttach.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnAttach.Click += new System.EventHandler(this.btnAttach_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(24)))), ((int)(((byte)(31)))));
            this.panel9.Controls.Add(this.flatLabel8);
            this.panel9.Controls.Add(this.cmbElevation);
            this.panel9.Controls.Add(this.tglElevation);
            this.panel9.Location = new System.Drawing.Point(3, 241);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(374, 73);
            this.panel9.TabIndex = 47;
            // 
            // tglElevation
            // 
            this.tglElevation.BackColor = System.Drawing.Color.Transparent;
            this.tglElevation.Checked = false;
            this.tglElevation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tglElevation.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tglElevation.Location = new System.Drawing.Point(290, 19);
            this.tglElevation.Name = "tglElevation";
            this.tglElevation.Options = theme.FlatToggle._Options.Style3;
            this.tglElevation.Size = new System.Drawing.Size(76, 33);
            this.tglElevation.TabIndex = 1;
            this.tglElevation.Text = "flatToggle1";
            this.tglElevation.CheckedChanged += new theme.FlatToggle.CheckedChangedEventHandler(this.flatToggle1_CheckedChanged);
            // 
            // cmbElevation
            // 
            this.cmbElevation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.cmbElevation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbElevation.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbElevation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbElevation.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cmbElevation.ForeColor = System.Drawing.Color.White;
            this.cmbElevation.FormattingEnabled = true;
            this.cmbElevation.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(137)))), ((int)(((byte)(234)))));
            this.cmbElevation.ItemHeight = 18;
            this.cmbElevation.Items.AddRange(new object[] {
            "Walk and elevate",
            "No elevation or de-elevation"});
            this.cmbElevation.Location = new System.Drawing.Point(8, 27);
            this.cmbElevation.Name = "cmbElevation";
            this.cmbElevation.Size = new System.Drawing.Size(255, 24);
            this.cmbElevation.TabIndex = 4;
            this.cmbElevation.SelectedIndexChanged += new System.EventHandler(this.cmbElevation_SelectedIndexChanged);
            // 
            // flatLabel8
            // 
            this.flatLabel8.AutoSize = true;
            this.flatLabel8.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel8.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.flatLabel8.ForeColor = System.Drawing.Color.White;
            this.flatLabel8.Location = new System.Drawing.Point(36, 4);
            this.flatLabel8.Name = "flatLabel8";
            this.flatLabel8.Size = new System.Drawing.Size(218, 20);
            this.flatLabel8.TabIndex = 3;
            this.flatLabel8.Text = "Walk Through Walls + Elevation";
            // 
            // re4
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.btnAttach);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnFAQ);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel5);
            this.Name = "re4";
            this.Size = new System.Drawing.Size(758, 455);
            this.Load += new System.EventHandler(this.re4_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label4;
        private theme.FlatLabel flatLabel3;
        private theme.FlatToggle tglGodMode;
        private System.Windows.Forms.Panel panel1;
        private theme.FlatNumeric numCurrency;
        private theme.FlatLabel flatLabel2;
        private theme.FlatButton btnSetCurrency;
        private System.Windows.Forms.Panel panel2;
        private theme.FlatButton btnFAQ;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private theme.FlatButton btnAttach;
        private System.Windows.Forms.Panel panel4;
        private theme.FlatButton btnResetGun;
        private theme.FlatComboBox cmbChangeHandgun;
        private theme.FlatLabel flatLabel4;
        private theme.FlatButton btnChangeHandgun;
        private System.Windows.Forms.Panel panel3;
        private theme.FlatComboBox cmb999Ammo;
        private theme.FlatLabel flatLabel1;
        private theme.FlatButton btnSetAmmo;
        private System.Windows.Forms.Panel panel8;
        private theme.FlatLabel flatLabel7;
        private theme.FlatToggle tglMatrix;
        private System.Windows.Forms.Panel panel7;
        private theme.FlatLabel flatLabel6;
        private theme.FlatToggle tglInvAmmo;
        private System.Windows.Forms.Panel panel6;
        private theme.FlatLabel flatLabel5;
        private theme.FlatToggle tglAmmo;
        private System.Windows.Forms.Panel panel9;
        private theme.FlatLabel flatLabel8;
        private theme.FlatComboBox cmbElevation;
        private theme.FlatToggle tglElevation;
    }
}
